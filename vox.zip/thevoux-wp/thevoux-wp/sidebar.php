<aside class="sidebar small-12 medium-4 columns" role="complementary">
	<div class="sidebar_inner">
		<?php 
		
			##############################################################################
			# Display the asigned sidebar
			##############################################################################
	
		?>
		<?php dynamic_sidebar('blog'); ?>
   	</div>
</aside>