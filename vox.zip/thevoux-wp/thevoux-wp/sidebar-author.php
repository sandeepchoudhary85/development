<aside class="sidebar small-12 medium-4 columns">
	<div class="sidebar_inner">
	<?php 
	
		##############################################################################
		# Single Sidebar
		##############################################################################
	
	 	?>
	<?php dynamic_sidebar('author'); ?>
	</div>
</aside>