<?php
add_action("wp_ajax_nopriv_thb_infinite_ajax", "thb_infinite_ajax");
add_action("wp_ajax_thb_infinite_ajax", "thb_infinite_ajax");
function thb_infinite_ajax() {
	global $post;
	$id = isset($_POST['post_id']) ? $_POST['post_id'] : false;
	
    $post = get_post( $id );
	$previous_post = get_previous_post();
	if ($id) {
		$args = array(
		    'p' => $previous_post->ID,
		    'no_found_rows' => true,
		    'posts_per_page' => 1
		);
		$query = new WP_Query($args);
		if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
			$style = get_post_meta($post->ID, 'post-style', true) ? get_post_meta($post->ID, 'post-style', true) : 'style1';
			$ajax = 1; include(locate_template( 'inc/loop/single-'.$style.'.php' ) );
		endwhile; else : endif;
	}
	die();
}
 ?>