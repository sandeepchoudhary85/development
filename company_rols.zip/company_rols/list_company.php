<?php
function fwds_display_settings() {
    global $wpdb;
    //edit Adds Records
    if(!empty($_REQUEST['status_id']))
    {
       $id = $_REQUEST['status_id'];
       $chngd = $_REQUEST['change_status'];
       $wpdb->query("update company set status='$chngd' where id='$id' ");
   }
   //delete adds Records
  if(!empty($_REQUEST['delete_id']))
    {
       $id = $_REQUEST['delete_id'];
       $wpdb->query("delete from wp_company where id='$id' ");
    }
    $i=1;
    echo"<h2>Company Manager</h2>";
    echo"<h4><a href='?page=new_company'>Adds New </a></h4>";
    $mydatas = $wpdb->get_results("SELECT * FROM wp_company");

    echo"<table width='100%' cellspacing='1' cellpadding='3'>";
    echo"<tr style='background-color:#DFDFDF;height:30px'>

     <th style='width:70px;text-align:left;'>company_name</th>
     <th style='width:100px;text-align:left;'>company_user_name</th>
     <th style='width:180px;text-align:left;'>account_number</th>
     <th style='width:200px;text-align:left;'>address</th>
     <th style='width:70px;text-align:left;'>Status</th>
     <th style='width:70px;text-align:left;'>Edit</th>
     <th style='width:70px;text-align:left;'>Delete</th>

     </tr>";

       global $wpdb;
   $mydatas = $wpdb->get_results("SELECT  *  FROM wp_company where company_type='1'");
   foreach($mydatas as $data)
   {
      echo"<tr>";
      echo "<td>".$i."</td>";
      echo"<td>$data->company_name</td>";
      echo"<td>$data->company_user_name</td>";
      echo"<td>$data->account_number</td>";
      echo"<td>$data->address</td>";
                echo "<td><a href='?page=edit_company&edit_id=".$data->id."'>Edit</a></td>";
          echo "<td><a href='?page=company_manager&delete_id=".$data->id."'>Delete</a></td>";
echo "</tr>";
          $i++;
   }
// }
// add_shortcode('rightsidebar_company','right_sidebar_add');

// function bottom_area()
// {
//    global $wpdb;
   $mydatas = $wpdb->get_results("SELECT * FROM wp_company where company_type='2'");
   foreach($mydatas as $data)
   {
      echo"<tr>";
      echo "<td>".$i."</td>";
          echo"<td>$data->company_name</td>";
          echo"<td>$data->company_user_name</td>";
          echo"<td>$data->account_number</td>";
          echo"<td>$data->address</td>";
                    echo "<td><a href='?page=edit_company&edit_id=".$data->id."'>Edit</a></td>";
          echo "<td><a href='?page=company_manager&delete_id=".$data->id."'>Delete</a></td>";
echo "</tr>";
          $i++;


 }
// }
// add_shortcode('bottom_company','bottom_area');

  $mydatas = $wpdb->get_results("SELECT * FROM wp_company where company_type='3'");
   foreach($mydatas as $data)
   {
      echo"<tr>";
      echo "<td>".$i."</td>";
          echo"<td>$data->company_name</td>";
          echo"<td>$data->company_user_name</td>";
          echo"<td>$data->account_number</td>";
          echo"<td>$data->address</td>";
          echo "<td><a href='?page=edit_company&edit_id=".$data->id."'>Edit</a></td>";
          echo "<td><a href='?page=company_manager&delete_id=".$data->id."'>Delete</a></td>";
echo "</tr>";
          $i++;


 }

    echo"</table>";
}
?>
