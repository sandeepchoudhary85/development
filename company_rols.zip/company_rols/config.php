<?php
register_activation_hook(__FILE__,'pro_install');
register_deactivation_hook(__FILE__ , 'pro_uninstall' );
function pro_install()
 {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table = $wpdb->prefix . "company";
    $structure = "CREATE TABLE IF NOT EXISTS ".$table ." (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) NOT NULL,
  `company_user_name` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `company_type` varchar(5) NOT NULL,
  `status` varchar(5) NOT NULL,
   PRIMARY KEY (`id`)
) $charset_collate;";
  require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
  dbDelta($structure);

}

add_action('admin_menu', 'fwds_plugin_settings');
function fwds_plugin_settings() {
    add_menu_page('company Manager', 'company Manager', 'administrator', 'company_manager', 'fwds_display_settings');
    add_submenu_page('company_manager', __('Edit company Page'), __(''), 'edit_themes', 'edit_company', 'edit_company_manager');
    add_submenu_page('company_manager', __('company New Add'), __('Add New'), 'edit_themes', 'new_company', 'new_company_manager');
}


// function fwds_display_settings(){

//                $myposts = $wpdb->get_results("SELECT  *  FROM wp_company where company_type='2'");
//                  foreach($myposts as $data)
//                  {
//                           echo"<li>$data->company_name</li>";
//                           echo"<li>$data->company_user_name</li>";
//                           echo"<li>$data->account_number</li>";
//                           echo"<li>$data->address</li>";
//                  }
// }

// function right_sidebar_add()
// {
//    global $wpdb;
//    $myposts = $wpdb->get_results("SELECT  *  FROM wp_company where company_type='2'");
//    foreach($myposts as $data)
//    {
//       echo"<li>$data->company_name</li>";
//       echo"<li>$data->company_user_name</li>";
//       echo"<li>$data->account_number</li>";
//       echo"<li>$data->address</li>";
//    }
// // }
// // add_shortcode('rightsidebar_company','right_sidebar_add');

// // function bottom_area()
// // {
// //    global $wpdb;
//    $myposts = $wpdb->get_results("SELECT * FROM wp_company where company_type='2'");
//    foreach($myposts as $data)
//    {

//           echo"<li>$data->company_name</li>";
//           echo"<li>$data->company_user_name</li>";
//           echo"<li>$data->account_number</li>";
//           echo"<li>$data->address</li>";


//  }
// // }
// // add_shortcode('bottom_company','bottom_area');

//   $myposts = $wpdb->get_results("SELECT * FROM wp_company where company_type='2'");
//    foreach($myposts as $data)
//    {

//           echo"<li>$data->company_name</li>";
//           echo"<li>$data->company_user_name</li>";
//           echo"<li>$data->account_number</li>";
//           echo"<li>$data->address</li>";


//  }

?>
