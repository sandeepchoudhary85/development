<?php
function edit_company_manager() {
   global $wpdb;
   if(!empty($_REQUEST['edit_id']))
    {?>
     <?php
    if(!empty($_REQUEST['edit_add']))
    {



          $company_name = $_POST['company_name'];
            $company_user_name = $_POST['company_user_name'];
             $account_number = $_POST['account_number'];
             $password  = $_POST['password'];
             $address = $_POST['address'];
             $company_type = $_POST['company_type'];
             $status = 1;


          $id = $_REQUEST['edit_id'];
          $wpdb->query("update wp_company set company_name='$company_name',company_user_name='$company_user_name',password='$password',company_type='$company_type',account_number='$account_number', address='$address' where id='$id' ");
    }
     $edit_id =  $_REQUEST['edit_id'];
     $thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_company WHERE ID = $edit_id " ) );
     ?>
    <h1>Edit Advertisement</h1>
    <h3><a href='?page=adds_manager'>Adds Manager</a></h3>
 <form action="" method="post" enctype="multipart/form-data">
        <table width="800" border="0" cellpadding="5">
         <tr>
         <td>company_name</td>
         <td>:</td>
         <td><input type="text" name="company_name" value="<?php echo $thepost->company_name; ?>"></td>
         </tr>
          <tr>
         <td>company_user_name</td>
         <td>:</td>
         <td><input type="text" name="company_user_name" value="<?php echo $thepost->company_user_name; ?>"></td>
         </tr>
          <tr>
         <td>Image</td>
         <td>:<input type="text" name="account_number" value="<?php echo $thepost->account_number; ?>"></td>

          <tr>
         <td valign="top">password</td>
         <td valign="top">:</td>
         <td><textarea name="password" cols="50" rows="5"><?php echo $thepost->password; ?></textarea></td>
         </tr>

  <tr>
         <td valign="top">address</td>
         <td valign="top">:</td>
         <td><textarea name="address" cols="50" rows="5"><?php echo $thepost->address; ?></textarea></td>
         </tr>

         <tr>
         <td>company_type</td>
         <td>:</td>
         <td>
         <select name="company_type">
         <option value="1" <?php if($thepost->company_type=='1'){echo"selected='selected'";}?>>company_type1</option>
         <option value="2" <?php if($thepost->company_type=='2'){echo"selected='selected'";}?>>company_type2</option>
          <option value="2" <?php if($thepost->company_type=='3'){echo"selected='selected'";}?>>company_type3</option>
         </select>
         </td>
         </tr>

         <tr>
         <td>&nbsp;</td>
         <td>&nbsp; <input type="hidden" name="edit_id" value="<?php echo $thepost->id; ?>"></td>
         <td><input type="submit" value="Edit" name="edit_add"></td>
         </tr>

      </table>
<?php } } ?>
