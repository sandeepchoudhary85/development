<?php
/**
 * @package Maya user role plugin
 * @version 1.6
 */
/*
Plugin Name: Maya user role plugin
Plugin URI: http://wordpress.org/plugins/adds/
Description: This Plugin is used for add user role
Author: Php Team
Version: 1.6
Author URI: http://www.kindlebit.com
*/
include_once('config.php');
include_once('edit_company.php');
include_once('list_company.php');
//include_once('view_adds.php');
include_once('add_new_company.php');
?>