<?php
function new_company_manager() {
    if(isset($_POST['add']))
         {
            global $wpdb;
	         $mess="";
            $user_id = get_current_user_id();
            $current_user = wp_get_current_user();
            $loginuser = $current_user->user_login;
            $useremailid =  $current_user->user_email;

            $company_name = $_POST['company_name'];
            $company_user_name = $_POST['company_user_name'];
             $account_number = $_POST['account_number'];
             $password  = $_POST['password'];
             $address = $_POST['address'];
             $company_type = $_POST['company_type'];
             $status = 1;

    $table_name = $wpdb->prefix . "company";

            $wpdb->query("INSERT INTO $table_name (id,company_name,company_user_name, account_number,password,address,company_type,status) VALUES
            ('','$company_name','$company_user_name','$account_number','$password','$address','$company_type' ,'1')");


            $mess="<font color='#298A08'>Advertisement submitted successfully! Adverstsement will be published on website after administrator's approval.</font>";

      }?>

   	<h2 class="page_heading">Add New Company</h2>
      <form action="" method="post" enctype="multipart/form-data" >

      <?php if(!empty($mess)){echo $mess;}?>
       <table width="70%" border="0" cellspacing="5" cellpadding="5">
		   <tr><span>* (denotes required field)</span></tr>
         <tr>
         <td width="16%">company_name*</td>
         <td width="7%">:</td>
         <td width="77%"><input type="text" name="company_name" required></td>
         </tr>
          <tr>
         <td>company_user_name*</td>
         <td>:</td>
         <td><input type="text" name="company_user_name" required></td>
         </tr>
          <tr>
         <td>account_number*</td>
         <td>:</td>
         <td><input type="text" name="account_number" id="file" required></td>
         </tr>
          <tr>
         <td valign="top">password*</td>
         <td valign="top">:</td>
          <td><input type="text" name="password" id="file" required></td>
         </tr>

         <tr>
         <td>address </td>
         <td>:</td>

         <td>  <td><input type="text" name="address" id="file" required></td>
         </td>
         </tr>

         <tr>
         <td>company_type*</td>
         <td>:</td>

         <td>
         <select name="company_type" required>
		 <option value="">--Select Area--</option>
         <option value="1">company 1</option>
         <option value="2">company 2</option>
         <option value="3">company 3 </option>
         </select>
         </td>
         </tr>

         <tr>
         <td>&nbsp;</td>
         <td>&nbsp;</td>
         <td><input type="submit" value="Publish" name="add"></td>
         </tr>

      </table>

   </form>
<?php }?>
