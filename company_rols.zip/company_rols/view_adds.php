<?php
function display_form()
    {
       if(isset($_POST['add']))
         {
            global $wpdb;
	         $mess="";
            $user_id = get_current_user_id();
            $current_user = wp_get_current_user();
            $loginuser = $current_user->user_login;
            
            $useremailid =  $current_user->user_email;
            
            $table_name = $wpdb->prefix . "adds";
            $lable = $_POST['lable'];
            $link = $_POST['link'];
            
            $slug = str_replace(" ","-",$lable);
            
            $description = $_POST['description'];          
            $home_adds_chk= $_POST['home_adds_chk']; 
            if(!empty($home_adds_chk)){
               $home_adds= $_POST['home_adds'];    
            }
          if(!empty($user_id)){
            if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );
            $uploadedfile = $_FILES['file'];
            $upload_overrides = array( 'test_form' => false );
            $movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
	         $image = $movefile['url'];   
            $wpdb->query("INSERT INTO $table_name (user_id,user_name,lable, link,description,image,home_adds,status,email_id,add_slug) VALUES
            ('$user_id','$loginuser','$lable','$link','$description','$image','$home_adds','0','$useremailid','$slug')"); 
            $mess="<font color='#298A08'>Advertisement submitted successfully! Adverstsement will be published on website after administrator's approval.</font>";
	    }else {$mess="<font color='#FE2E2E'>Please login!</font>";}
            
      }?>
  

   <div class="full">
	   
   	<h2 class="page_heading">Add advertisement</h2>
      <form action="" method="post" enctype="multipart/form-data">
      <div class="add_adv">
      <?php if(!empty($mess)){echo $mess;}?>
       <table width="100%" border="0" cellspacing="25" cellpadding="0">
		   <tr><span>* (denotes required field)</span></tr>
         <tr>
         <td width="16%">Tittle *</td>
         <td width="7%">:</td>
         <td width="77%"><input type="text" name="lable" required /></td>
         </tr>
          <tr>
         <td>Link *</td>
         <td>:</td>
         <td><input type="text" name="link" required /></td>
         </tr>
          <tr>
         <td>Image *</td>
         <td>:</td>
         <td><input type="file" name="file" id="file" required /></td>
         </tr>
          <tr>
         <td>Description *</td>
         <td>:</td>
         <td><textarea name="description" required ></textarea></td>
         </tr>
         
         <tr>
         <td>On Home Page </td>
         <td>:</td>
         
         <td><input type="checkbox" name="home_adds_chk" value="1">
         </td>
         </tr>
         
         <tr>
         <td>Display Area *</td>
         <td>:</td>
         
         <td>
         <select name="home_adds" required>
	     <option value="">--Select Area--</option>
         <option value="1">Right Sidebar</option>
         <option value="2">Bottom Area</option>
         </select>
         </td>
         </tr>
         
         <tr>
         <td>&nbsp;</td>
         <td>&nbsp;</td>
         <td><input type="submit" value="Publish" name="add"></td>
         </tr>
         
      </table>
      </div>
   </form>
   </div>
   
<?php }
add_shortcode( 'adds_form', 'display_form' );
?>
