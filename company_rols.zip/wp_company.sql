-- Adminer 4.2.4 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `wp_company`;
CREATE TABLE `wp_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) NOT NULL,
  `company_user_name` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `company_type` varchar(5) NOT NULL,
  `status` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `wp_company` (`id`, `company_name`, `company_user_name`, `account_number`, `password`, `address`, `company_type`, `status`) VALUES
(2,	'test company',	'sandeep',	'00100010010010',	'admin',	'#12121211000',	'2',	'1');

-- 2016-05-03 12:06:34
