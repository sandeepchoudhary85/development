<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_VC_Gitem_Post_Meta extends WPBakeryShortCode {
}
